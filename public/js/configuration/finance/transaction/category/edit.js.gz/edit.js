webpackJsonp([115],{

/***/ 1075:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _form = __webpack_require__(565);

var _form2 = _interopRequireDefault(_form);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: { transactionCategoryForm: _form2.default },
    data: function data() {
        return {
            id: this.$route.params.id
        };
    },
    mounted: function mounted() {
        if (!helper.hasPermission('access-configuration')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1076:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-titles" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("h3", { staticClass: "text-themecolor" }, [
            _vm._v(_vm._s(_vm.trans("finance.edit_transaction_category")))
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("div", { staticClass: "action-buttons pull-right" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-info btn-sm",
                on: {
                  click: function($event) {
                    _vm.$router.push(
                      "/configuration/finance/transaction/category"
                    )
                  }
                }
              },
              [
                _c("i", { staticClass: "fas fa-list" }),
                _vm._v(" "),
                _c("span", { staticClass: "d-none d-sm-inline" }, [
                  _vm._v(_vm._s(_vm.trans("finance.transaction_category")))
                ])
              ]
            )
          ])
        ])
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "container-fluid" }, [
      _c("div", { staticClass: "card card-form" }, [
        _c(
          "div",
          { staticClass: "card-body p-t-20" },
          [_c("transaction-category-form", { attrs: { id: _vm.id } })],
          1
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-48d988e6", module.exports)
  }
}

/***/ }),

/***/ 291:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1075)
/* template */
var __vue_template__ = __webpack_require__(1076)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/configuration/finance/transaction/category/edit.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-48d988e6", Component.options)
  } else {
    hotAPI.reload("data-v-48d988e6", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 565:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(566)
}
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(568)
/* template */
var __vue_template__ = __webpack_require__(569)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/configuration/finance/transaction/category/form.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-cf5c2572", Component.options)
  } else {
    hotAPI.reload("data-v-cf5c2572", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 566:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(567);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(14)("55a9495e", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-cf5c2572\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./form.vue", function() {
     var newContent = require("!!../../../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-cf5c2572\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./form.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 567:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(8)(true);
// imports


// module
exports.push([module.i, "\n.loading-overlay.is-full-page{\r\n    z-index: 1060;\n}\r\n", "", {"version":3,"sources":["D:/Projects/jacob/resources/js/views/configuration/finance/transaction/category/resources/js/views/configuration/finance/transaction/category/form.vue"],"names":[],"mappings":";AA0HA;IACA,cAAA;CACA","file":"form.vue","sourcesContent":["<template>\r\n    <form @submit.prevent=\"proceed\" @keydown=\"transactionCategoryForm.errors.clear($event.target.name)\">\r\n        <div class=\"row\">\r\n            <div class=\"col-12 col-sm-4\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"\">{{trans('finance.transaction_category_name')}}</label>\r\n                    <input class=\"form-control\" type=\"text\" v-model=\"transactionCategoryForm.name\" name=\"name\" :placeholder=\"trans('finance.transaction_category_name')\">\r\n                    <show-error :form-name=\"transactionCategoryForm\" prop-name=\"name\"></show-error>\r\n                </div>\r\n            </div>\r\n            <div class=\"col-12 col-sm-4\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"\">{{trans('finance.transaction_category_type')}}</label>\r\n                    <select v-model=\"transactionCategoryForm.type\" class=\"col-12 custom-select\" @change=\"transactionCategoryForm.errors.clear('type')\" name=\"type\">\r\n                      <option value=null selected>{{trans('general.select_one')}}</option>\r\n                      <option v-for=\"type in types\" v-bind:value=\"type.value\">\r\n                        {{ type.text }}\r\n                      </option>\r\n                    </select>\r\n                    <show-error :form-name=\"transactionCategoryForm\" prop-name=\"type\"></show-error>\r\n                </div>\r\n            </div>\r\n            <div class=\"col-12 col-sm-4\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"\">{{trans('finance.transaction_category_description')}}</label>\r\n                    <input class=\"form-control\" type=\"text\" v-model=\"transactionCategoryForm.description\" name=\"description\" :placeholder=\"trans('finance.transaction_category_description')\">\r\n                    <show-error :form-name=\"transactionCategoryForm\" prop-name=\"description\"></show-error>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"card-footer text-right\">\r\n            <button v-if=\"!id\" type=\"button\" class=\"btn btn-danger waves-effect waves-light \" @click=\"$emit('cancel')\">{{trans('general.cancel')}}</button>\r\n            <router-link to=\"/configuration/finance/transaction/category\" class=\"btn btn-danger waves-effect waves-light \" v-show=\"id\">{{trans('general.cancel')}}</router-link>\r\n            <button type=\"submit\" class=\"btn btn-info waves-effect waves-light\">\r\n                <span v-if=\"id\">{{trans('general.update')}}</span>\r\n                <span v-else>{{trans('general.save')}}</span>\r\n            </button>\r\n        </div>\r\n    </form>\r\n</template>\r\n\r\n\r\n<script>\r\n    export default {\r\n        data() {\r\n            return {\r\n                transactionCategoryForm: new Form({\r\n                    name : '',\r\n                    type: '',\r\n                    description : ''\r\n                }),\r\n                types: [\r\n                    {\r\n                        text: i18n.finance.income,\r\n                        value: 'income'\r\n                    },\r\n                    {\r\n                        text: i18n.finance.expense,\r\n                        value: 'expense'\r\n                    }\r\n                ]\r\n            };\r\n        },\r\n        props: ['id'],\r\n        mounted() {\r\n            if(this.id)\r\n                this.get();\r\n        },\r\n        methods: {\r\n            proceed(){\r\n                if(this.id)\r\n                    this.update();\r\n                else\r\n                    this.store();\r\n            },\r\n            store(){\r\n                let loader = this.$loading.show();\r\n                this.transactionCategoryForm.post('/api/finance/transaction/category')\r\n                    .then(response => {\r\n                        toastr.success(response.message);\r\n                        this.$emit('completed');\r\n                        loader.hide();\r\n                    })\r\n                    .catch(error => {\r\n                        loader.hide();\r\n                        helper.showErrorMsg(error);\r\n                    });\r\n            },\r\n            get(){\r\n                let loader = this.$loading.show();\r\n                axios.get('/api/finance/transaction/category/'+this.id)\r\n                    .then(response => {\r\n                        this.transactionCategoryForm.name = response.name;\r\n                        this.transactionCategoryForm.type = response.type;\r\n                        this.transactionCategoryForm.description = response.description;\r\n                        loader.hide();\r\n                    })\r\n                    .catch(error => {\r\n                        loader.hide();\r\n                        helper.showErrorMsg(error);\r\n                        this.$router.push('/configuration/finance/transaction/category');\r\n                    });\r\n            },\r\n            update(){\r\n                let loader = this.$loading.show();\r\n                this.transactionCategoryForm.patch('/api/finance/transaction/category/'+this.id)\r\n                    .then(response => {\r\n                        toastr.success(response.message);\r\n                        loader.hide();\r\n                        this.$router.push('/configuration/finance/transaction/category');\r\n                    })\r\n                    .catch(error => {\r\n                        loader.hide();\r\n                        helper.showErrorMsg(error);\r\n                    });\r\n            }\r\n        }\r\n    }\r\n</script>\r\n\r\n<style>\r\n.loading-overlay.is-full-page{\r\n    z-index: 1060;\r\n}\r\n</style>\r\n"],"sourceRoot":""}]);

// exports


/***/ }),

/***/ 568:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    data: function data() {
        return {
            transactionCategoryForm: new Form({
                name: '',
                type: '',
                description: ''
            }),
            types: [{
                text: i18n.finance.income,
                value: 'income'
            }, {
                text: i18n.finance.expense,
                value: 'expense'
            }]
        };
    },

    props: ['id'],
    mounted: function mounted() {
        if (this.id) this.get();
    },

    methods: {
        proceed: function proceed() {
            if (this.id) this.update();else this.store();
        },
        store: function store() {
            var _this = this;

            var loader = this.$loading.show();
            this.transactionCategoryForm.post('/api/finance/transaction/category').then(function (response) {
                toastr.success(response.message);
                _this.$emit('completed');
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        get: function get() {
            var _this2 = this;

            var loader = this.$loading.show();
            axios.get('/api/finance/transaction/category/' + this.id).then(function (response) {
                _this2.transactionCategoryForm.name = response.name;
                _this2.transactionCategoryForm.type = response.type;
                _this2.transactionCategoryForm.description = response.description;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
                _this2.$router.push('/configuration/finance/transaction/category');
            });
        },
        update: function update() {
            var _this3 = this;

            var loader = this.$loading.show();
            this.transactionCategoryForm.patch('/api/finance/transaction/category/' + this.id).then(function (response) {
                toastr.success(response.message);
                loader.hide();
                _this3.$router.push('/configuration/finance/transaction/category');
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    }
};

/***/ }),

/***/ 569:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "form",
    {
      on: {
        submit: function($event) {
          $event.preventDefault()
          return _vm.proceed($event)
        },
        keydown: function($event) {
          _vm.transactionCategoryForm.errors.clear($event.target.name)
        }
      }
    },
    [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(_vm._s(_vm.trans("finance.transaction_category_name")))
              ]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.transactionCategoryForm.name,
                    expression: "transactionCategoryForm.name"
                  }
                ],
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  name: "name",
                  placeholder: _vm.trans("finance.transaction_category_name")
                },
                domProps: { value: _vm.transactionCategoryForm.name },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.transactionCategoryForm,
                      "name",
                      $event.target.value
                    )
                  }
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: {
                  "form-name": _vm.transactionCategoryForm,
                  "prop-name": "name"
                }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(_vm._s(_vm.trans("finance.transaction_category_type")))
              ]),
              _vm._v(" "),
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.transactionCategoryForm.type,
                      expression: "transactionCategoryForm.type"
                    }
                  ],
                  staticClass: "col-12 custom-select",
                  attrs: { name: "type" },
                  on: {
                    change: [
                      function($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function(o) {
                            return o.selected
                          })
                          .map(function(o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.transactionCategoryForm,
                          "type",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                      function($event) {
                        _vm.transactionCategoryForm.errors.clear("type")
                      }
                    ]
                  }
                },
                [
                  _c("option", { attrs: { value: "null", selected: "" } }, [
                    _vm._v(_vm._s(_vm.trans("general.select_one")))
                  ]),
                  _vm._v(" "),
                  _vm._l(_vm.types, function(type) {
                    return _c("option", { domProps: { value: type.value } }, [
                      _vm._v(
                        "\n                    " +
                          _vm._s(type.text) +
                          "\n                  "
                      )
                    ])
                  })
                ],
                2
              ),
              _vm._v(" "),
              _c("show-error", {
                attrs: {
                  "form-name": _vm.transactionCategoryForm,
                  "prop-name": "type"
                }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(
                  _vm._s(_vm.trans("finance.transaction_category_description"))
                )
              ]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.transactionCategoryForm.description,
                    expression: "transactionCategoryForm.description"
                  }
                ],
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  name: "description",
                  placeholder: _vm.trans(
                    "finance.transaction_category_description"
                  )
                },
                domProps: { value: _vm.transactionCategoryForm.description },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.transactionCategoryForm,
                      "description",
                      $event.target.value
                    )
                  }
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: {
                  "form-name": _vm.transactionCategoryForm,
                  "prop-name": "description"
                }
              })
            ],
            1
          )
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "card-footer text-right" },
        [
          !_vm.id
            ? _c(
                "button",
                {
                  staticClass: "btn btn-danger waves-effect waves-light ",
                  attrs: { type: "button" },
                  on: {
                    click: function($event) {
                      _vm.$emit("cancel")
                    }
                  }
                },
                [_vm._v(_vm._s(_vm.trans("general.cancel")))]
              )
            : _vm._e(),
          _vm._v(" "),
          _c(
            "router-link",
            {
              directives: [
                {
                  name: "show",
                  rawName: "v-show",
                  value: _vm.id,
                  expression: "id"
                }
              ],
              staticClass: "btn btn-danger waves-effect waves-light ",
              attrs: { to: "/configuration/finance/transaction/category" }
            },
            [_vm._v(_vm._s(_vm.trans("general.cancel")))]
          ),
          _vm._v(" "),
          _c(
            "button",
            {
              staticClass: "btn btn-info waves-effect waves-light",
              attrs: { type: "submit" }
            },
            [
              _vm.id
                ? _c("span", [_vm._v(_vm._s(_vm.trans("general.update")))])
                : _c("span", [_vm._v(_vm._s(_vm.trans("general.save")))])
            ]
          )
        ],
        1
      )
    ]
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-cf5c2572", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=edit.js.map