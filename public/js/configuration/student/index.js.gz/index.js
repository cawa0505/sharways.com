webpackJsonp([291],{

/***/ 1083:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    data: function data() {
        return {
            configForm: new Form({
                admission_number_prefix: '',
                admission_number_digit: '',
                allow_to_modify_student_attendance: '',
                days_allowed_to_modify_student_attendance: '',
                allow_to_mark_student_advance_attendance: '',
                days_allowed_to_mark_student_advance_attendance: '',
                config_type: ''
            }, false)
        };
    },
    mounted: function mounted() {
        if (!helper.hasPermission('access-configuration')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }

        this.getConfiguration();
    },

    methods: {
        getConfiguration: function getConfiguration() {
            var _this = this;

            var loader = this.$loading.show();
            axios.get('/api/configuration').then(function (response) {
                _this.configForm = helper.formAssign(_this.configForm, response);
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        submit: function submit() {
            var _this2 = this;

            var loader = this.$loading.show();
            this.configForm.config_type = 'student';
            this.configForm.post('/api/configuration').then(function (response) {
                _this2.$store.dispatch('setConfig', { loaded: false });
                toastr.success(response.message);
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    }
};

/***/ }),

/***/ 1084:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-titles" }, [
      _c("h3", { staticClass: "text-themecolor" }, [
        _vm._v(_vm._s(_vm.trans("student.student_configuration")))
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "container-fluid" }, [
      _c("div", { staticClass: "card" }, [
        _c("div", { staticClass: "card-body p-4" }, [
          _c(
            "form",
            {
              on: {
                submit: function($event) {
                  $event.preventDefault()
                  return _vm.submit($event)
                },
                keydown: function($event) {
                  _vm.configForm.errors.clear($event.target.name)
                }
              }
            },
            [
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-12 col-sm-3" }, [
                  _c(
                    "div",
                    { staticClass: "form-group" },
                    [
                      _c("label", { attrs: { for: "" } }, [
                        _vm._v(
                          _vm._s(_vm.trans("student.admission_number_prefix"))
                        )
                      ]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.configForm.admission_number_prefix,
                            expression: "configForm.admission_number_prefix"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "admission_number_prefix",
                          placeholder: _vm.trans(
                            "student.admission_number_prefix"
                          )
                        },
                        domProps: {
                          value: _vm.configForm.admission_number_prefix
                        },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.configForm,
                              "admission_number_prefix",
                              $event.target.value
                            )
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.configForm,
                          "prop-name": "admission_number_prefix"
                        }
                      })
                    ],
                    1
                  )
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-12 col-sm-3" }, [
                  _c(
                    "div",
                    { staticClass: "form-group" },
                    [
                      _c("label", { attrs: { for: "" } }, [
                        _vm._v(
                          _vm._s(_vm.trans("student.admission_number_digit"))
                        )
                      ]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.configForm.admission_number_digit,
                            expression: "configForm.admission_number_digit"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "number",
                          name: "admission_number_digit",
                          placeholder: _vm.trans(
                            "student.admission_number_digit"
                          )
                        },
                        domProps: {
                          value: _vm.configForm.admission_number_digit
                        },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.configForm,
                              "admission_number_digit",
                              $event.target.value
                            )
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.configForm,
                          "prop-name": "admission_number_digit"
                        }
                      })
                    ],
                    1
                  )
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-12 col-sm-3" }, [
                  _c(
                    "div",
                    { staticClass: "form-group" },
                    [
                      _c(
                        "label",
                        {
                          staticClass: "custom-control custom-checkbox m-t-20"
                        },
                        [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value:
                                  _vm.configForm
                                    .allow_to_modify_student_attendance,
                                expression:
                                  "configForm.allow_to_modify_student_attendance"
                              }
                            ],
                            staticClass: "custom-control-input",
                            attrs: {
                              type: "checkbox",
                              value: "1",
                              name: "allow_to_modify_student_attendance"
                            },
                            domProps: {
                              checked: Array.isArray(
                                _vm.configForm
                                  .allow_to_modify_student_attendance
                              )
                                ? _vm._i(
                                    _vm.configForm
                                      .allow_to_modify_student_attendance,
                                    "1"
                                  ) > -1
                                : _vm.configForm
                                    .allow_to_modify_student_attendance
                            },
                            on: {
                              change: function($event) {
                                var $$a =
                                    _vm.configForm
                                      .allow_to_modify_student_attendance,
                                  $$el = $event.target,
                                  $$c = $$el.checked ? true : false
                                if (Array.isArray($$a)) {
                                  var $$v = "1",
                                    $$i = _vm._i($$a, $$v)
                                  if ($$el.checked) {
                                    $$i < 0 &&
                                      _vm.$set(
                                        _vm.configForm,
                                        "allow_to_modify_student_attendance",
                                        $$a.concat([$$v])
                                      )
                                  } else {
                                    $$i > -1 &&
                                      _vm.$set(
                                        _vm.configForm,
                                        "allow_to_modify_student_attendance",
                                        $$a
                                          .slice(0, $$i)
                                          .concat($$a.slice($$i + 1))
                                      )
                                  }
                                } else {
                                  _vm.$set(
                                    _vm.configForm,
                                    "allow_to_modify_student_attendance",
                                    $$c
                                  )
                                }
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c("span", { staticClass: "custom-control-label" }, [
                            _vm._v(
                              _vm._s(
                                _vm.trans(
                                  "student.allow_to_modify_student_attendance"
                                )
                              )
                            )
                          ])
                        ]
                      ),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.configForm,
                          "prop-name": "allow_to_modify_student_attendance"
                        }
                      })
                    ],
                    1
                  )
                ]),
                _vm._v(" "),
                _vm.configForm.allow_to_modify_student_attendance
                  ? _c("div", { staticClass: "col-12 col-sm-3" }, [
                      _c(
                        "div",
                        { staticClass: "form-group" },
                        [
                          _c("label", { attrs: { for: "" } }, [
                            _vm._v(
                              _vm._s(
                                _vm.trans(
                                  "student.days_allowed_to_modify_student_attendance"
                                )
                              )
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "input-group" }, [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value:
                                    _vm.configForm
                                      .days_allowed_to_modify_student_attendance,
                                  expression:
                                    "configForm.days_allowed_to_modify_student_attendance"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "text",
                                name:
                                  "days_allowed_to_modify_student_attendance",
                                placeholder: _vm.trans(
                                  "student.days_allowed_to_modify_student_attendance"
                                )
                              },
                              domProps: {
                                value:
                                  _vm.configForm
                                    .days_allowed_to_modify_student_attendance
                              },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.configForm,
                                    "days_allowed_to_modify_student_attendance",
                                    $event.target.value
                                  )
                                }
                              }
                            }),
                            _vm._v(" "),
                            _c("div", { staticClass: "input-group-append" }, [
                              _c("span", { staticClass: "input-group-text" }, [
                                _vm._v(_vm._s(_vm.trans("general.days")))
                              ])
                            ])
                          ]),
                          _vm._v(" "),
                          _c("show-error", {
                            attrs: {
                              "form-name": _vm.configForm,
                              "prop-name":
                                "days_allowed_to_modify_student_attendance"
                            }
                          })
                        ],
                        1
                      )
                    ])
                  : _vm._e(),
                _vm._v(" "),
                _c("div", { staticClass: "col-12 col-sm-3" }, [
                  _c(
                    "div",
                    { staticClass: "form-group" },
                    [
                      _c(
                        "label",
                        {
                          staticClass: "custom-control custom-checkbox m-t-20"
                        },
                        [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value:
                                  _vm.configForm
                                    .allow_to_mark_student_advance_attendance,
                                expression:
                                  "configForm.allow_to_mark_student_advance_attendance"
                              }
                            ],
                            staticClass: "custom-control-input",
                            attrs: {
                              type: "checkbox",
                              value: "1",
                              name: "allow_to_mark_student_advance_attendance"
                            },
                            domProps: {
                              checked: Array.isArray(
                                _vm.configForm
                                  .allow_to_mark_student_advance_attendance
                              )
                                ? _vm._i(
                                    _vm.configForm
                                      .allow_to_mark_student_advance_attendance,
                                    "1"
                                  ) > -1
                                : _vm.configForm
                                    .allow_to_mark_student_advance_attendance
                            },
                            on: {
                              change: function($event) {
                                var $$a =
                                    _vm.configForm
                                      .allow_to_mark_student_advance_attendance,
                                  $$el = $event.target,
                                  $$c = $$el.checked ? true : false
                                if (Array.isArray($$a)) {
                                  var $$v = "1",
                                    $$i = _vm._i($$a, $$v)
                                  if ($$el.checked) {
                                    $$i < 0 &&
                                      _vm.$set(
                                        _vm.configForm,
                                        "allow_to_mark_student_advance_attendance",
                                        $$a.concat([$$v])
                                      )
                                  } else {
                                    $$i > -1 &&
                                      _vm.$set(
                                        _vm.configForm,
                                        "allow_to_mark_student_advance_attendance",
                                        $$a
                                          .slice(0, $$i)
                                          .concat($$a.slice($$i + 1))
                                      )
                                  }
                                } else {
                                  _vm.$set(
                                    _vm.configForm,
                                    "allow_to_mark_student_advance_attendance",
                                    $$c
                                  )
                                }
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c("span", { staticClass: "custom-control-label" }, [
                            _vm._v(
                              _vm._s(
                                _vm.trans(
                                  "student.allow_to_mark_student_advance_attendance"
                                )
                              )
                            )
                          ])
                        ]
                      ),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.configForm,
                          "prop-name":
                            "allow_to_mark_student_advance_attendance"
                        }
                      })
                    ],
                    1
                  )
                ]),
                _vm._v(" "),
                _vm.configForm.allow_to_mark_student_advance_attendance
                  ? _c("div", { staticClass: "col-12 col-sm-3" }, [
                      _c(
                        "div",
                        { staticClass: "form-group" },
                        [
                          _c("label", { attrs: { for: "" } }, [
                            _vm._v(
                              _vm._s(
                                _vm.trans(
                                  "student.days_allowed_to_mark_student_advance_attendance"
                                )
                              )
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "input-group" }, [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value:
                                    _vm.configForm
                                      .days_allowed_to_mark_student_advance_attendance,
                                  expression:
                                    "configForm.days_allowed_to_mark_student_advance_attendance"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "text",
                                name:
                                  "days_allowed_to_mark_student_advance_attendance",
                                placeholder: _vm.trans(
                                  "student.days_allowed_to_mark_student_advance_attendance"
                                )
                              },
                              domProps: {
                                value:
                                  _vm.configForm
                                    .days_allowed_to_mark_student_advance_attendance
                              },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.configForm,
                                    "days_allowed_to_mark_student_advance_attendance",
                                    $event.target.value
                                  )
                                }
                              }
                            }),
                            _vm._v(" "),
                            _c("div", { staticClass: "input-group-append" }, [
                              _c("span", { staticClass: "input-group-text" }, [
                                _vm._v(_vm._s(_vm.trans("general.days")))
                              ])
                            ])
                          ]),
                          _vm._v(" "),
                          _c("show-error", {
                            attrs: {
                              "form-name": _vm.configForm,
                              "prop-name":
                                "days_allowed_to_mark_student_advance_attendance"
                            }
                          })
                        ],
                        1
                      )
                    ])
                  : _vm._e()
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "form-group text-right" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info waves-effect waves-light",
                    attrs: { type: "submit" }
                  },
                  [_vm._v(_vm._s(_vm.trans("general.save")))]
                )
              ])
            ]
          )
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-fa01b414", module.exports)
  }
}

/***/ }),

/***/ 295:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1083)
/* template */
var __vue_template__ = __webpack_require__(1084)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/configuration/student/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-fa01b414", Component.options)
  } else {
    hotAPI.reload("data-v-fa01b414", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ })

});
//# sourceMappingURL=index.js.map