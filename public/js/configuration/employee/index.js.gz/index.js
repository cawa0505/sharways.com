webpackJsonp([301],{

/***/ 1119:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    data: function data() {
        return {
            configForm: new Form({
                employee_code_prefix: '',
                employee_code_digit: '',
                leave_holiday_calculation_mode: '',
                per_day_salary_calculation_basis: '',
                user_defined_per_day_salary_calculation_basis: '',
                config_type: ''
            }, false),
            leave_holiday_calculation_modes: [{
                text: i18n.employee.leave_holiday_calculation_mode_ignore,
                value: 'ignore'
            }, {
                text: i18n.employee.leave_holiday_calculation_mode_include,
                value: 'include'
            }, {
                text: i18n.employee.leave_holiday_calculation_mode_include_if_enclosed,
                value: 'include_if_enclosed'
            }],
            per_day_salary_calculation_basis_options: [{
                text: i18n.employee.salary_structure_calendar_period,
                value: 'calendar_period'
            }, {
                text: i18n.employee.salary_structure_user_defined,
                value: 'user_defined'
            }]
        };
    },
    mounted: function mounted() {
        if (!helper.hasPermission('access-configuration')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }

        this.getConfiguration();
    },

    methods: {
        getConfiguration: function getConfiguration() {
            var _this = this;

            var loader = this.$loading.show();
            axios.get('/api/configuration').then(function (response) {
                _this.configForm = helper.formAssign(_this.configForm, response);
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        submit: function submit() {
            var _this2 = this;

            var loader = this.$loading.show();
            this.configForm.config_type = 'employee';
            this.configForm.post('/api/configuration').then(function (response) {
                _this2.$store.dispatch('setConfig', { loaded: false });
                toastr.success(response.message);
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    }
};

/***/ }),

/***/ 1120:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-titles" }, [
      _c("h3", { staticClass: "text-themecolor" }, [
        _vm._v(_vm._s(_vm.trans("employee.employee_configuration")))
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "container-fluid" }, [
      _c("div", { staticClass: "card" }, [
        _c("div", { staticClass: "card-body p-4" }, [
          _c(
            "form",
            {
              on: {
                submit: function($event) {
                  $event.preventDefault()
                  return _vm.submit($event)
                },
                keydown: function($event) {
                  _vm.configForm.errors.clear($event.target.name)
                }
              }
            },
            [
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-12 col-sm-3" }, [
                  _c(
                    "div",
                    { staticClass: "form-group" },
                    [
                      _c("label", { attrs: { for: "" } }, [
                        _vm._v(
                          _vm._s(_vm.trans("employee.employee_code_prefix"))
                        )
                      ]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.configForm.employee_code_prefix,
                            expression: "configForm.employee_code_prefix"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "employee_code_prefix",
                          placeholder: _vm.trans(
                            "employee.employee_code_prefix"
                          )
                        },
                        domProps: {
                          value: _vm.configForm.employee_code_prefix
                        },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.configForm,
                              "employee_code_prefix",
                              $event.target.value
                            )
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.configForm,
                          "prop-name": "employee_code_prefix"
                        }
                      })
                    ],
                    1
                  )
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-12 col-sm-3" }, [
                  _c(
                    "div",
                    { staticClass: "form-group" },
                    [
                      _c("label", { attrs: { for: "" } }, [
                        _vm._v(
                          _vm._s(_vm.trans("employee.employee_code_digit"))
                        )
                      ]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.configForm.employee_code_digit,
                            expression: "configForm.employee_code_digit"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "number",
                          name: "employee_code_digit",
                          placeholder: _vm.trans("employee.employee_code_digit")
                        },
                        domProps: { value: _vm.configForm.employee_code_digit },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.configForm,
                              "employee_code_digit",
                              $event.target.value
                            )
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.configForm,
                          "prop-name": "employee_code_digit"
                        }
                      })
                    ],
                    1
                  )
                ])
              ]),
              _vm._v(" "),
              _c("h4", { staticClass: "card-title" }, [
                _vm._v(_vm._s(_vm.trans("employee.leave_configuration")))
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-12 col-sm-3" }, [
                  _c(
                    "div",
                    { staticClass: "form-group" },
                    [
                      _c("label", { attrs: { for: "" } }, [
                        _vm._v(
                          _vm._s(
                            _vm.trans("employee.leave_holiday_calculation_mode")
                          )
                        )
                      ]),
                      _vm._v(" "),
                      _c(
                        "select",
                        {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value:
                                _vm.configForm.leave_holiday_calculation_mode,
                              expression:
                                "configForm.leave_holiday_calculation_mode"
                            }
                          ],
                          staticClass: "custom-select col-12",
                          attrs: { name: "leave_holiday_calculation_mode" },
                          on: {
                            change: [
                              function($event) {
                                var $$selectedVal = Array.prototype.filter
                                  .call($event.target.options, function(o) {
                                    return o.selected
                                  })
                                  .map(function(o) {
                                    var val = "_value" in o ? o._value : o.value
                                    return val
                                  })
                                _vm.$set(
                                  _vm.configForm,
                                  "leave_holiday_calculation_mode",
                                  $event.target.multiple
                                    ? $$selectedVal
                                    : $$selectedVal[0]
                                )
                              },
                              function($event) {
                                _vm.configForm.errors.clear(
                                  "leave_holiday_calculation_mode"
                                )
                              }
                            ]
                          }
                        },
                        _vm._l(_vm.leave_holiday_calculation_modes, function(
                          option
                        ) {
                          return _c(
                            "option",
                            { domProps: { value: option.value } },
                            [
                              _vm._v(
                                "\n                                    " +
                                  _vm._s(option.text) +
                                  "\n                                  "
                              )
                            ]
                          )
                        })
                      ),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.configForm,
                          "prop-name": "leave_holiday_calculation_mode"
                        }
                      })
                    ],
                    1
                  )
                ])
              ]),
              _vm._v(" "),
              _c("h4", { staticClass: "card-title" }, [
                _vm._v(_vm._s(_vm.trans("employee.payroll_configuration")))
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-12 col-sm-3" }, [
                  _c(
                    "div",
                    { staticClass: "form-group" },
                    [
                      _c("label", { attrs: { for: "" } }, [
                        _vm._v(
                          _vm._s(
                            _vm.trans(
                              "employee.per_day_salary_calculation_basis"
                            )
                          )
                        )
                      ]),
                      _vm._v(" "),
                      _c(
                        "select",
                        {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value:
                                _vm.configForm.per_day_salary_calculation_basis,
                              expression:
                                "configForm.per_day_salary_calculation_basis"
                            }
                          ],
                          staticClass: "custom-select col-12",
                          attrs: { name: "per_day_salary_calculation_basis" },
                          on: {
                            change: [
                              function($event) {
                                var $$selectedVal = Array.prototype.filter
                                  .call($event.target.options, function(o) {
                                    return o.selected
                                  })
                                  .map(function(o) {
                                    var val = "_value" in o ? o._value : o.value
                                    return val
                                  })
                                _vm.$set(
                                  _vm.configForm,
                                  "per_day_salary_calculation_basis",
                                  $event.target.multiple
                                    ? $$selectedVal
                                    : $$selectedVal[0]
                                )
                              },
                              function($event) {
                                _vm.configForm.errors.clear(
                                  "per_day_salary_calculation_basis"
                                )
                              }
                            ]
                          }
                        },
                        _vm._l(
                          _vm.per_day_salary_calculation_basis_options,
                          function(option) {
                            return _c(
                              "option",
                              { domProps: { value: option.value } },
                              [
                                _vm._v(
                                  "\n                                    " +
                                    _vm._s(option.text) +
                                    "\n                                  "
                                )
                              ]
                            )
                          }
                        )
                      ),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.configForm,
                          "prop-name": "per_day_salary_calculation_basis"
                        }
                      })
                    ],
                    1
                  )
                ]),
                _vm._v(" "),
                _vm.configForm.per_day_salary_calculation_basis ==
                "user_defined"
                  ? _c("div", { staticClass: "col-12 col-sm-3" }, [
                      _c(
                        "div",
                        { staticClass: "form-group" },
                        [
                          _c("label", { attrs: { for: "" } }, [
                            _vm._v(
                              _vm._s(
                                _vm.trans(
                                  "employee.user_defined_per_day_salary_calculation_basis"
                                )
                              )
                            )
                          ]),
                          _vm._v(" "),
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value:
                                  _vm.configForm
                                    .user_defined_per_day_salary_calculation_basis,
                                expression:
                                  "configForm.user_defined_per_day_salary_calculation_basis"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "number",
                              name:
                                "user_defined_per_day_salary_calculation_basis",
                              placeholder: _vm.trans(
                                "employee.user_defined_per_day_salary_calculation_basis"
                              )
                            },
                            domProps: {
                              value:
                                _vm.configForm
                                  .user_defined_per_day_salary_calculation_basis
                            },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.configForm,
                                  "user_defined_per_day_salary_calculation_basis",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c("show-error", {
                            attrs: {
                              "form-name": _vm.configForm,
                              "prop-name":
                                "user_defined_per_day_salary_calculation_basis"
                            }
                          })
                        ],
                        1
                      )
                    ])
                  : _vm._e()
              ]),
              _vm._v(" "),
              _c(
                "button",
                {
                  staticClass:
                    "btn btn-info waves-effect waves-light pull-right m-t-10",
                  attrs: { type: "submit" }
                },
                [_vm._v(_vm._s(_vm.trans("general.save")))]
              )
            ]
          )
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-544be42e", module.exports)
  }
}

/***/ }),

/***/ 313:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1119)
/* template */
var __vue_template__ = __webpack_require__(1120)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/configuration/employee/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-544be42e", Component.options)
  } else {
    hotAPI.reload("data-v-544be42e", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ })

});
//# sourceMappingURL=index.js.map