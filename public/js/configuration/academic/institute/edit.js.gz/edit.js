webpackJsonp([214],{

/***/ 1051:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _form = __webpack_require__(713);

var _form2 = _interopRequireDefault(_form);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: { instituteForm: _form2.default },
    data: function data() {
        return {
            id: this.$route.params.id
        };
    },
    mounted: function mounted() {
        if (!helper.hasPermission('access-configuration')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1052:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-titles" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("h3", { staticClass: "text-themecolor" }, [
            _vm._v(_vm._s(_vm.trans("academic.edit_institute")))
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("div", { staticClass: "action-buttons pull-right" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-info btn-sm",
                on: {
                  click: function($event) {
                    _vm.$router.push("/configuration/academic/institute")
                  }
                }
              },
              [
                _c("i", { staticClass: "fas fa-list" }),
                _vm._v(" "),
                _c("span", { staticClass: "d-none d-sm-inline" }, [
                  _vm._v(_vm._s(_vm.trans("academic.institute")))
                ])
              ]
            )
          ])
        ])
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "container-fluid" }, [
      _c("div", { staticClass: "card card-form" }, [
        _c(
          "div",
          { staticClass: "card-body p-t-20" },
          [_c("institute-form", { attrs: { id: _vm.id } })],
          1
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-3be7bec4", module.exports)
  }
}

/***/ }),

/***/ 279:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1051)
/* template */
var __vue_template__ = __webpack_require__(1052)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/configuration/academic/institute/edit.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-3be7bec4", Component.options)
  } else {
    hotAPI.reload("data-v-3be7bec4", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 713:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(714)
/* template */
var __vue_template__ = __webpack_require__(715)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/configuration/academic/institute/form.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-0eb31f04", Component.options)
  } else {
    hotAPI.reload("data-v-0eb31f04", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 714:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    data: function data() {
        return {
            instituteForm: new Form({
                name: '',
                contact_number: '',
                alternate_contact_number: '',
                principal_name: '',
                website: '',
                address: '',
                remarks: ''
            })
        };
    },

    props: ['id'],
    mounted: function mounted() {
        if (this.id) this.get();
    },

    methods: {
        proceed: function proceed() {
            if (this.id) this.update();else this.store();
        },
        store: function store() {
            var _this = this;

            var loader = this.$loading.show();
            this.instituteForm.post('/api/academic/institute').then(function (response) {
                toastr.success(response.message);
                _this.$emit('completed');
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        get: function get() {
            var _this2 = this;

            var loader = this.$loading.show();
            axios.get('/api/academic/institute/' + this.id).then(function (response) {
                _this2.instituteForm.name = response.name;
                _this2.instituteForm.contact_number = response.contact_number;
                _this2.instituteForm.alternate_contact_number = response.alternate_contact_number;
                _this2.instituteForm.principal_name = response.principal_name;
                _this2.instituteForm.website = response.website;
                _this2.instituteForm.address = response.address;
                _this2.instituteForm.remarks = response.remarks;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
                _this2.$router.push('/configuration/academic/institute');
            });
        },
        update: function update() {
            var _this3 = this;

            var loader = this.$loading.show();
            this.instituteForm.patch('/api/academic/institute/' + this.id).then(function (response) {
                toastr.success(response.message);
                loader.hide();
                _this3.$router.push('/configuration/academic/institute');
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    }
};

/***/ }),

/***/ 715:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "form",
    {
      on: {
        submit: function($event) {
          $event.preventDefault()
          return _vm.proceed($event)
        },
        keydown: function($event) {
          _vm.instituteForm.errors.clear($event.target.name)
        }
      }
    },
    [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(_vm._s(_vm.trans("academic.institute_name")))
              ]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.instituteForm.name,
                    expression: "instituteForm.name"
                  }
                ],
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  name: "name",
                  placeholder: _vm.trans("academic.institute_name")
                },
                domProps: { value: _vm.instituteForm.name },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.instituteForm, "name", $event.target.value)
                  }
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: { "form-name": _vm.instituteForm, "prop-name": "name" }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(_vm._s(_vm.trans("academic.institute_contact_number")))
              ]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.instituteForm.contact_number,
                    expression: "instituteForm.contact_number"
                  }
                ],
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  name: "contact_number",
                  placeholder: _vm.trans("academic.institute_contact_number")
                },
                domProps: { value: _vm.instituteForm.contact_number },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.instituteForm,
                      "contact_number",
                      $event.target.value
                    )
                  }
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: {
                  "form-name": _vm.instituteForm,
                  "prop-name": "contact_number"
                }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(
                  _vm._s(
                    _vm.trans("academic.institute_alternate_contact_number")
                  )
                )
              ]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.instituteForm.alternate_contact_number,
                    expression: "instituteForm.alternate_contact_number"
                  }
                ],
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  name: "alternate_contact_number",
                  placeholder: _vm.trans(
                    "academic.institute_alternate_contact_number"
                  )
                },
                domProps: { value: _vm.instituteForm.alternate_contact_number },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.instituteForm,
                      "alternate_contact_number",
                      $event.target.value
                    )
                  }
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: {
                  "form-name": _vm.instituteForm,
                  "prop-name": "alternate_contact_number"
                }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(_vm._s(_vm.trans("academic.institute_principal_name")))
              ]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.instituteForm.principal_name,
                    expression: "instituteForm.principal_name"
                  }
                ],
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  name: "principal_name",
                  placeholder: _vm.trans("academic.institute_principal_name")
                },
                domProps: { value: _vm.instituteForm.principal_name },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.instituteForm,
                      "principal_name",
                      $event.target.value
                    )
                  }
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: {
                  "form-name": _vm.instituteForm,
                  "prop-name": "principal_name"
                }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(_vm._s(_vm.trans("academic.institute_website")))
              ]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.instituteForm.website,
                    expression: "instituteForm.website"
                  }
                ],
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  name: "website",
                  placeholder: _vm.trans("academic.institute_website")
                },
                domProps: { value: _vm.instituteForm.website },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.instituteForm, "website", $event.target.value)
                  }
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: {
                  "form-name": _vm.instituteForm,
                  "prop-name": "website"
                }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(_vm._s(_vm.trans("academic.institute_address")))
              ]),
              _vm._v(" "),
              _c("autosize-textarea", {
                attrs: {
                  rows: "1",
                  name: "address",
                  placeholder: _vm.trans("academic.institute_address")
                },
                model: {
                  value: _vm.instituteForm.address,
                  callback: function($$v) {
                    _vm.$set(_vm.instituteForm, "address", $$v)
                  },
                  expression: "instituteForm.address"
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: {
                  "form-name": _vm.instituteForm,
                  "prop-name": "address"
                }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(_vm._s(_vm.trans("academic.institute_remarks")))
              ]),
              _vm._v(" "),
              _c("autosize-textarea", {
                attrs: {
                  rows: "1",
                  name: "remarks",
                  placeholder: _vm.trans("academic.institute_remarks")
                },
                model: {
                  value: _vm.instituteForm.remarks,
                  callback: function($$v) {
                    _vm.$set(_vm.instituteForm, "remarks", $$v)
                  },
                  expression: "instituteForm.remarks"
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: {
                  "form-name": _vm.instituteForm,
                  "prop-name": "remarks"
                }
              })
            ],
            1
          )
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "card-footer text-right" },
        [
          _c(
            "router-link",
            {
              directives: [
                {
                  name: "show",
                  rawName: "v-show",
                  value: _vm.id,
                  expression: "id"
                }
              ],
              staticClass: "btn btn-danger waves-effect waves-light ",
              attrs: { to: "/configuration/academic/institute" }
            },
            [_vm._v(_vm._s(_vm.trans("general.cancel")))]
          ),
          _vm._v(" "),
          !_vm.id
            ? _c(
                "button",
                {
                  staticClass: "btn btn-danger waves-effect waves-light ",
                  attrs: { type: "button" },
                  on: {
                    click: function($event) {
                      _vm.$emit("cancel")
                    }
                  }
                },
                [_vm._v(_vm._s(_vm.trans("general.cancel")))]
              )
            : _vm._e(),
          _vm._v(" "),
          _c(
            "button",
            {
              staticClass: "btn btn-info waves-effect waves-light",
              attrs: { type: "submit" }
            },
            [
              _vm.id
                ? _c("span", [_vm._v(_vm._s(_vm.trans("general.update")))])
                : _c("span", [_vm._v(_vm._s(_vm.trans("general.save")))])
            ]
          )
        ],
        1
      )
    ]
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-0eb31f04", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=edit.js.map