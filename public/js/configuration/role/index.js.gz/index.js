webpackJsonp([171],{

/***/ 1020:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _form = __webpack_require__(1021);

var _form2 = _interopRequireDefault(_form);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: { roleForm: _form2.default },
    data: function data() {
        return {
            roles: {
                total: 0,
                data: []
            },
            filter: {
                page_length: helper.getConfig('page_length')
            },
            showCreatePanel: false,
            help_topic: ''
        };
    },
    mounted: function mounted() {
        if (!helper.hasRole('admin')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }
        this.getRoles();
    },

    methods: {
        getRoles: function getRoles(page) {
            var _this = this;

            var loader = this.$loading.show();
            if (typeof page !== 'number') {
                page = 1;
            }
            var url = helper.getFilterURL(this.filter);
            axios.get('/api/role?page=' + page + url).then(function (response) {
                _this.roles = response;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        confirmDelete: function confirmDelete(role) {
            var _this2 = this;

            return function (dialog) {
                return _this2.deleteRole(role);
            };
        },
        deleteRole: function deleteRole(role) {
            var _this3 = this;

            var loader = this.$loading.show();
            axios.delete('/api/role/' + role.id).then(function (response) {
                toastr.success(response.message);
                _this3.getRoles();
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        toWord: function toWord(word) {
            return helper.toWord(word);
        }
    },
    filters: {
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1021:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1022)
/* template */
var __vue_template__ = __webpack_require__(1023)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/configuration/role/form.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-5f9e0596", Component.options)
  } else {
    hotAPI.reload("data-v-5f9e0596", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 1022:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    data: function data() {
        return {
            roleForm: new Form({
                'name': ''
            })
        };
    },

    methods: {
        storeRole: function storeRole() {
            var _this = this;

            var loader = this.$loading.show();
            this.roleForm.post('/api/role').then(function (response) {
                toastr.success(response.message);
                _this.$emit('completed');
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    }
};

/***/ }),

/***/ 1023:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "form",
    {
      on: {
        submit: function($event) {
          $event.preventDefault()
          return _vm.storeRole($event)
        },
        keydown: function($event) {
          _vm.roleForm.errors.clear($event.target.name)
        }
      }
    },
    [
      _c(
        "div",
        { staticClass: "form-group" },
        [
          _c("label", { attrs: { for: "" } }, [
            _vm._v(_vm._s(_vm.trans("configuration.role_name")))
          ]),
          _vm._v(" "),
          _c("input", {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.roleForm.name,
                expression: "roleForm.name"
              }
            ],
            staticClass: "form-control",
            attrs: {
              type: "text",
              name: "name",
              placeholder: _vm.trans("configuration.role_name")
            },
            domProps: { value: _vm.roleForm.name },
            on: {
              input: function($event) {
                if ($event.target.composing) {
                  return
                }
                _vm.$set(_vm.roleForm, "name", $event.target.value)
              }
            }
          }),
          _vm._v(" "),
          _c("show-error", {
            attrs: { "form-name": _vm.roleForm, "prop-name": "name" }
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("div", { staticClass: "card-footer text-right" }, [
        _c(
          "button",
          {
            staticClass: "btn btn-danger waves-effect waves-light ",
            attrs: { type: "button" },
            on: {
              click: function($event) {
                _vm.$emit("cancel")
              }
            }
          },
          [_vm._v(_vm._s(_vm.trans("general.cancel")))]
        ),
        _vm._v(" "),
        _c(
          "button",
          {
            staticClass: "btn btn-info waves-effect waves-light",
            attrs: { type: "submit" }
          },
          [_c("span", [_vm._v(_vm._s(_vm.trans("general.save")))])]
        )
      ])
    ]
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-5f9e0596", module.exports)
  }
}

/***/ }),

/***/ 1024:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("div", { staticClass: "page-titles" }, [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c("h3", { staticClass: "text-themecolor" }, [
              _vm._v(
                _vm._s(_vm.trans("configuration.role")) +
                  "\n                    "
              ),
              _vm.roles.total
                ? _c(
                    "span",
                    { staticClass: "card-subtitle d-none d-sm-inline" },
                    [
                      _vm._v(
                        _vm._s(
                          _vm.trans("general.total_result_found", {
                            count: _vm.roles.total,
                            from: _vm.roles.from,
                            to: _vm.roles.to
                          })
                        )
                      )
                    ]
                  )
                : _c(
                    "span",
                    { staticClass: "card-subtitle d-none d-sm-inline" },
                    [_vm._v(_vm._s(_vm.trans("general.no_result_found")))]
                  )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c(
              "div",
              { staticClass: "action-buttons pull-right" },
              [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info btn-sm",
                    on: {
                      click: function($event) {
                        _vm.showCreatePanel = !_vm.showCreatePanel
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-plus" }),
                    _vm._v(" "),
                    _c("span", { staticClass: "d-none d-sm-inline" }, [
                      _vm._v(_vm._s(_vm.trans("configuration.add_new_role")))
                    ])
                  ]
                ),
                _vm._v(" "),
                _c("help-button", {
                  on: {
                    clicked: function($event) {
                      _vm.help_topic = "configuration.role"
                    }
                  }
                })
              ],
              1
            )
          ])
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "container-fluid" },
        [
          _c("transition", { attrs: { name: "fade" } }, [
            _vm.showCreatePanel
              ? _c("div", { staticClass: "card card-form" }, [
                  _c(
                    "div",
                    { staticClass: "card-body" },
                    [
                      _c("h4", { staticClass: "card-title" }, [
                        _vm._v(_vm._s(_vm.trans("configuration.add_new_role")))
                      ]),
                      _vm._v(" "),
                      _c("role-form", {
                        on: {
                          completed: _vm.getRoles,
                          cancel: function($event) {
                            _vm.showCreatePanel = !_vm.showCreatePanel
                          }
                        }
                      })
                    ],
                    1
                  )
                ])
              : _vm._e()
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "card" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _vm.roles.total
                  ? _c("div", { staticClass: "table-responsive" }, [
                      _c("table", { staticClass: "table table-sm" }, [
                        _c("thead", [
                          _c("tr", [
                            _c("th", [
                              _vm._v(
                                _vm._s(_vm.trans("configuration.role_name"))
                              )
                            ]),
                            _vm._v(" "),
                            _c("th", { staticClass: "table-option" }, [
                              _vm._v("Action")
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          _vm._l(_vm.roles.data, function(role) {
                            return _c("tr", [
                              _c("td", {
                                domProps: {
                                  textContent: _vm._s(_vm.toWord(role.name))
                                }
                              }),
                              _vm._v(" "),
                              _c("td", { staticClass: "table-option" }, [
                                _c("div", { staticClass: "btn-group" }, [
                                  _c(
                                    "button",
                                    {
                                      directives: [
                                        {
                                          name: "confirm",
                                          rawName: "v-confirm",
                                          value: {
                                            ok: _vm.confirmDelete(role)
                                          },
                                          expression:
                                            "{ok: confirmDelete(role)}"
                                        },
                                        {
                                          name: "tooltip",
                                          rawName: "v-tooltip",
                                          value: _vm.trans(
                                            "configuration.delete_role"
                                          ),
                                          expression:
                                            "trans('configuration.delete_role')"
                                        }
                                      ],
                                      key: role.id,
                                      staticClass: "btn btn-danger btn-sm"
                                    },
                                    [_c("i", { staticClass: "fas fa-trash" })]
                                  )
                                ])
                              ])
                            ])
                          })
                        )
                      ])
                    ])
                  : _vm._e(),
                _vm._v(" "),
                !_vm.roles.total
                  ? _c("module-info", {
                      attrs: {
                        module: "configuration",
                        title: "role_module_title",
                        description: "role_module_description",
                        icon: "list"
                      }
                    })
                  : _vm._e(),
                _vm._v(" "),
                _c("pagination-record", {
                  attrs: {
                    "page-length": _vm.filter.page_length,
                    records: _vm.roles
                  },
                  on: {
                    "update:pageLength": function($event) {
                      _vm.$set(_vm.filter, "page_length", $event)
                    },
                    updateRecords: _vm.getRoles
                  },
                  nativeOn: {
                    change: function($event) {
                      return _vm.getRoles($event)
                    }
                  }
                })
              ],
              1
            )
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("right-panel", { attrs: { topic: _vm.help_topic } })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-c6e2449e", module.exports)
  }
}

/***/ }),

/***/ 267:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1020)
/* template */
var __vue_template__ = __webpack_require__(1024)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/configuration/role/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-c6e2449e", Component.options)
  } else {
    hotAPI.reload("data-v-c6e2449e", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ })

});
//# sourceMappingURL=index.js.map