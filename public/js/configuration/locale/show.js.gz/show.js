webpackJsonp([8],{

/***/ 1039:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1040);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(14)("0104010f", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-2eb4c18a\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./show.vue", function() {
     var newContent = require("!!../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-2eb4c18a\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./show.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 1040:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(8)(true);
// imports


// module
exports.push([module.i, "\n.list-group-item .active {color:#ffffff;\n}\n", "", {"version":3,"sources":["D:/Projects/jacob/resources/js/views/configuration/locale/resources/js/views/configuration/locale/show.vue"],"names":[],"mappings":";AAsJA,0BAAA,cAAA;CAAA","file":"show.vue","sourcesContent":["<template>\r\n    <div>\r\n        <div class=\"page-titles\">\r\n            <div class=\"row\">\r\n                <div class=\"col-12 col-sm-6\">\r\n                    <h3 class=\"text-themecolor\">{{trans('configuration.translation')}} ({{locale.name}}) </h3>\r\n                </div>\r\n                <div class=\"col-12 col-sm-6\">\r\n                    <div class=\"action-buttons pull-right\">\r\n                        <button class=\"btn btn-info btn-sm\" @click=\"$router.push('/configuration/locale')\"><i class=\"fas fa-globe\"></i> <span class=\"d-none d-sm-inline\">{{trans('configuration.locale')}}</span></button>\r\n                        <div class=\"btn-group\">\r\n                            <button type=\"button\" style=\"margin-top:-5px;\" class=\"btn btn-info btn-sm\" href=\"#\" role=\"button\" id=\"moduleLink\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\r\n                                <i class=\"fas fa-boxes\"></i> <span class=\"d-none d-sm-inline\">{{trans('configuration.locale_module')}} <span>({{toWord(module)}})</span> <i class=\"fas fa-chevron-down\"></i> </span>\r\n                            </button>\r\n                            <div :class=\"['dropdown-menu',getConfig('direction') == 'ltr' ? 'dropdown-menu-right' : '']\" aria-labelledby=\"moduleLink\">\r\n                                <button style=\"cursor:pointer;\" class=\"dropdown-item\" v-for=\"mod in modules\" @click=\"$router.push('/configuration/locale/'+locale.locale+'/'+mod)\">\r\n                                    {{toWord(mod)}} <span v-if=\"mod == module\" class=\"pull-right\"><i class=\"fas fa-check\"></i></span> \r\n                                </button>\r\n                            </div>\r\n                        </div>\r\n                        <help-button @clicked=\"help_topic = 'configuration.locale.translation'\"></help-button>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <div class=\"container-fluid\">\r\n            <div class=\"card\">\r\n                <div class=\"card-body p-4\">\r\n                    <div v-if=\"getWordCount\">\r\n                        <div class=\"row\">\r\n                            <template v-for=\"(word,index) in words\">\r\n                                <template v-if=\"typeof word === 'object'\">\r\n                                    <div class=\"col-12 col-sm-4\" v-for=\"(wrd,i) in word\">\r\n                                        <div class=\"form-group\">\r\n                                            <label for=\"\" style=\"color:red;\">{{trans(module+'.'+index+'.'+i)}}</label>\r\n                                            <!-- <label for=\"\">{{index}}_{{i}}</label> -->\r\n                                            <input class=\"form-control\" type=\"text\" v-model=\"words[index][i]\" :name=\"`${index}_${i}`\">\r\n                                        </div>\r\n                                    </div>\r\n                                </template>\r\n                                <template v-else>\r\n                                    <div class=\"col-12 col-sm-4\">\r\n                                        <div class=\"form-group\">\r\n                                            <label for=\"\" class=\"font-weight-bold\">{{trans(module+'.'+index)}}</label>\r\n                                            <!-- <label for=\"\">{{index}}</label> -->\r\n                                            <input class=\"form-control\" type=\"text\" v-model=\"words[index]\" :name=\"index\">\r\n                                        </div>\r\n                                    </div>\r\n                                </template>\r\n                            </template>\r\n                        </div>\r\n                        <div class=\"form-group\">\r\n                            <button class=\"btn btn-info btn-sm pull-right\" @click=\"saveTranslation\">{{trans('general.save')}}</button>\r\n                        </div>\r\n                    </div>\r\n                    <div v-if=\"!getWordCount\">\r\n                        <p class=\"alert alert-danger\">{{trans('general.no_result_found')}}</p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <right-panel :topic=\"help_topic\"></right-panel>\r\n    </div>\r\n</template>\r\n\r\n\r\n<script>\r\n    export default {\r\n        data() {\r\n            return {\r\n                modules: {},\r\n                words: {},\r\n                locale: {},\r\n                module: (this.$route.params.module) ? this.$route.params.module : 'auth',\r\n                help_topic: ''\r\n            };\r\n        },\r\n        mounted(){\r\n            if(!helper.hasPermission('access-configuration')){\r\n                helper.notAccessibleMsg();\r\n                this.$router.push('/dashboard');\r\n            }\r\n\r\n            if(!helper.featureAvailable('multilingual')){\r\n                helper.featureNotAvailableMsg();\r\n                this.$router.push('/dashboard');\r\n            }\r\n\r\n            this.fetchWords();\r\n        },\r\n        methods: {\r\n            fetchWords(){\r\n                let loader = this.$loading.show();\r\n                axios.post('/api/locale/fetch',{\r\n                    locale: this.$route.params.locale,\r\n                    module: this.module\r\n                    })\r\n                    .then(response => {\r\n                        this.modules = response.modules;\r\n                        this.words = response.words;\r\n                        this.locale = response.locale;\r\n                        loader.hide();\r\n                    }).catch(error => {\r\n                        loader.hide();\r\n                        helper.showErrorMsg(error);\r\n                        this.$router.push('/configuration/locale');\r\n                    });\r\n            },\r\n            getName(name){\r\n                name = helper.ucword(name);\r\n                return name.replace(/_/g, ' ');\r\n            },\r\n            getModuleLink(module){\r\n                return '/configuration/locale/'+this.$route.params.locale+'/'+module\r\n            },\r\n            saveTranslation(){\r\n                let loader = this.$loading.show();\r\n                axios.post('/api/locale/translate',{\r\n                    locale: this.$route.params.locale,\r\n                    module: this.module,\r\n                    words: this.words\r\n                }).then(response => {\r\n                    toastr.success(response.message);\r\n                    loader.hide();\r\n                }).catch(error => {\r\n                    loader.hide();\r\n                    helper.showErrorMsg(error);\r\n                });\r\n            },\r\n            getConfig(config){\r\n                return helper.getConfig(config);\r\n            },\r\n            toWord(word){\r\n                return helper.toWord(word);\r\n            }\r\n        },\r\n        watch: {\r\n            '$route.params.module'(newModule, oldModule) {\r\n                this.module = newModule;\r\n                this.fetchWords();\r\n            }\r\n        },\r\n        computed: {\r\n            getWordCount(){\r\n                return _size(this.words);\r\n            }\r\n        }\r\n    }\r\n</script>\r\n<style>\r\n    .list-group-item .active {color:#ffffff;}\r\n</style>\r\n"],"sourceRoot":""}]);

// exports


/***/ }),

/***/ 1041:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    data: function data() {
        return {
            modules: {},
            words: {},
            locale: {},
            module: this.$route.params.module ? this.$route.params.module : 'auth',
            help_topic: ''
        };
    },
    mounted: function mounted() {
        if (!helper.hasPermission('access-configuration')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }

        if (!helper.featureAvailable('multilingual')) {
            helper.featureNotAvailableMsg();
            this.$router.push('/dashboard');
        }

        this.fetchWords();
    },

    methods: {
        fetchWords: function fetchWords() {
            var _this = this;

            var loader = this.$loading.show();
            axios.post('/api/locale/fetch', {
                locale: this.$route.params.locale,
                module: this.module
            }).then(function (response) {
                _this.modules = response.modules;
                _this.words = response.words;
                _this.locale = response.locale;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
                _this.$router.push('/configuration/locale');
            });
        },
        getName: function getName(name) {
            name = helper.ucword(name);
            return name.replace(/_/g, ' ');
        },
        getModuleLink: function getModuleLink(module) {
            return '/configuration/locale/' + this.$route.params.locale + '/' + module;
        },
        saveTranslation: function saveTranslation() {
            var loader = this.$loading.show();
            axios.post('/api/locale/translate', {
                locale: this.$route.params.locale,
                module: this.module,
                words: this.words
            }).then(function (response) {
                toastr.success(response.message);
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getConfig: function getConfig(config) {
            return helper.getConfig(config);
        },
        toWord: function toWord(word) {
            return helper.toWord(word);
        }
    },
    watch: {
        '$route.params.module': function $routeParamsModule(newModule, oldModule) {
            this.module = newModule;
            this.fetchWords();
        }
    },
    computed: {
        getWordCount: function getWordCount() {
            return _size(this.words);
        }
    }
};

/***/ }),

/***/ 1042:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("div", { staticClass: "page-titles" }, [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c("h3", { staticClass: "text-themecolor" }, [
              _vm._v(
                _vm._s(_vm.trans("configuration.translation")) +
                  " (" +
                  _vm._s(_vm.locale.name) +
                  ") "
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c(
              "div",
              { staticClass: "action-buttons pull-right" },
              [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info btn-sm",
                    on: {
                      click: function($event) {
                        _vm.$router.push("/configuration/locale")
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-globe" }),
                    _vm._v(" "),
                    _c("span", { staticClass: "d-none d-sm-inline" }, [
                      _vm._v(_vm._s(_vm.trans("configuration.locale")))
                    ])
                  ]
                ),
                _vm._v(" "),
                _c("div", { staticClass: "btn-group" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-info btn-sm",
                      staticStyle: { "margin-top": "-5px" },
                      attrs: {
                        type: "button",
                        href: "#",
                        role: "button",
                        id: "moduleLink",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false"
                      }
                    },
                    [
                      _c("i", { staticClass: "fas fa-boxes" }),
                      _vm._v(" "),
                      _c("span", { staticClass: "d-none d-sm-inline" }, [
                        _vm._v(
                          _vm._s(_vm.trans("configuration.locale_module")) + " "
                        ),
                        _c("span", [
                          _vm._v("(" + _vm._s(_vm.toWord(_vm.module)) + ")")
                        ]),
                        _vm._v(" "),
                        _c("i", { staticClass: "fas fa-chevron-down" })
                      ])
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      class: [
                        "dropdown-menu",
                        _vm.getConfig("direction") == "ltr"
                          ? "dropdown-menu-right"
                          : ""
                      ],
                      attrs: { "aria-labelledby": "moduleLink" }
                    },
                    _vm._l(_vm.modules, function(mod) {
                      return _c(
                        "button",
                        {
                          staticClass: "dropdown-item",
                          staticStyle: { cursor: "pointer" },
                          on: {
                            click: function($event) {
                              _vm.$router.push(
                                "/configuration/locale/" +
                                  _vm.locale.locale +
                                  "/" +
                                  mod
                              )
                            }
                          }
                        },
                        [
                          _vm._v(
                            "\n                                " +
                              _vm._s(_vm.toWord(mod)) +
                              " "
                          ),
                          mod == _vm.module
                            ? _c("span", { staticClass: "pull-right" }, [
                                _c("i", { staticClass: "fas fa-check" })
                              ])
                            : _vm._e()
                        ]
                      )
                    })
                  )
                ]),
                _vm._v(" "),
                _c("help-button", {
                  on: {
                    clicked: function($event) {
                      _vm.help_topic = "configuration.locale.translation"
                    }
                  }
                })
              ],
              1
            )
          ])
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "container-fluid" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-body p-4" }, [
            _vm.getWordCount
              ? _c("div", [
                  _c(
                    "div",
                    { staticClass: "row" },
                    [
                      _vm._l(_vm.words, function(word, index) {
                        return [
                          typeof word === "object"
                            ? _vm._l(word, function(wrd, i) {
                                return _c(
                                  "div",
                                  { staticClass: "col-12 col-sm-4" },
                                  [
                                    _c("div", { staticClass: "form-group" }, [
                                      _c(
                                        "label",
                                        {
                                          staticStyle: { color: "red" },
                                          attrs: { for: "" }
                                        },
                                        [
                                          _vm._v(
                                            _vm._s(
                                              _vm.trans(
                                                _vm.module +
                                                  "." +
                                                  index +
                                                  "." +
                                                  i
                                              )
                                            )
                                          )
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.words[index][i],
                                            expression: "words[index][i]"
                                          }
                                        ],
                                        staticClass: "form-control",
                                        attrs: {
                                          type: "text",
                                          name: index + "_" + i
                                        },
                                        domProps: {
                                          value: _vm.words[index][i]
                                        },
                                        on: {
                                          input: function($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              _vm.words[index],
                                              i,
                                              $event.target.value
                                            )
                                          }
                                        }
                                      })
                                    ])
                                  ]
                                )
                              })
                            : [
                                _c("div", { staticClass: "col-12 col-sm-4" }, [
                                  _c("div", { staticClass: "form-group" }, [
                                    _c(
                                      "label",
                                      {
                                        staticClass: "font-weight-bold",
                                        attrs: { for: "" }
                                      },
                                      [
                                        _vm._v(
                                          _vm._s(
                                            _vm.trans(_vm.module + "." + index)
                                          )
                                        )
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c("input", {
                                      directives: [
                                        {
                                          name: "model",
                                          rawName: "v-model",
                                          value: _vm.words[index],
                                          expression: "words[index]"
                                        }
                                      ],
                                      staticClass: "form-control",
                                      attrs: { type: "text", name: index },
                                      domProps: { value: _vm.words[index] },
                                      on: {
                                        input: function($event) {
                                          if ($event.target.composing) {
                                            return
                                          }
                                          _vm.$set(
                                            _vm.words,
                                            index,
                                            $event.target.value
                                          )
                                        }
                                      }
                                    })
                                  ])
                                ])
                              ]
                        ]
                      })
                    ],
                    2
                  ),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group" }, [
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-info btn-sm pull-right",
                        on: { click: _vm.saveTranslation }
                      },
                      [_vm._v(_vm._s(_vm.trans("general.save")))]
                    )
                  ])
                ])
              : _vm._e(),
            _vm._v(" "),
            !_vm.getWordCount
              ? _c("div", [
                  _c("p", { staticClass: "alert alert-danger" }, [
                    _vm._v(_vm._s(_vm.trans("general.no_result_found")))
                  ])
                ])
              : _vm._e()
          ])
        ])
      ]),
      _vm._v(" "),
      _c("right-panel", { attrs: { topic: _vm.help_topic } })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-2eb4c18a", module.exports)
  }
}

/***/ }),

/***/ 52:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(1039)
}
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1041)
/* template */
var __vue_template__ = __webpack_require__(1042)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/configuration/locale/show.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-2eb4c18a", Component.options)
  } else {
    hotAPI.reload("data-v-2eb4c18a", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ })

});
//# sourceMappingURL=show.js.map