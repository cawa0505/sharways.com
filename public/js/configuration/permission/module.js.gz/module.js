webpackJsonp([294],{

/***/ 1027:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    data: function data() {
        return {
            module: this.$route.params.module,
            roles: [],
            permissions: [],
            modules: [],
            assigned_permissions: [],
            permissionForm: new Form({
                module: '',
                roles: []
            }, false),
            help_topic: ''
        };
    },
    mounted: function mounted() {
        if (!helper.hasRole('admin')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }

        this.getPreRequisite();
    },

    methods: {
        getPreRequisite: function getPreRequisite() {
            var _this = this;

            var loader = this.$loading.show();
            this.permissionForm.roles = [];
            this.permissionForm.module = this.module;
            axios.get('/api/permission/' + this.module + '/pre-requisite').then(function (response) {
                _this.roles = response.roles;
                _this.permissions = response.permissions;
                _this.assigned_permissions = response.assigned_permissions;
                _this.modules = response.modules;

                _this.roles.forEach(function (role) {

                    var permissions = _this.assigned_permissions.find(function (o) {
                        return o.role == role.name;
                    });

                    _this.permissionForm.roles.push({
                        name: role.name,
                        permissions: permissions != 'undefined' ? permissions.permissions : []
                    });
                });
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getConfig: function getConfig(config) {
            return helper.getConfig(config);
        },
        toWord: function toWord(word) {
            return helper.toWord(word);
        },
        submit: function submit() {
            var loader = this.$loading.show();
            this.permissionForm.module = this.module;
            this.permissionForm.post('/api/permission/module').then(function (response) {
                toastr.success(response.message);
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getDefaultRole: function getDefaultRole(role) {
            return helper.getDefaultRole(role);
        }
    },
    watch: {
        '$route.params.module': function $routeParamsModule(module) {
            this.module = module;
            this.getPreRequisite();
        }
    }
};

/***/ }),

/***/ 1028:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("div", { staticClass: "page-titles" }, [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c("h3", { staticClass: "text-themecolor" }, [
              _vm._v(
                _vm._s(
                  _vm.trans("configuration.assign_permission_module", {
                    module: _vm.trans(_vm.module + "." + _vm.module)
                  })
                )
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c(
              "div",
              { staticClass: "action-buttons pull-right" },
              [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info btn-sm d-none d-sm-inline ",
                    on: {
                      click: function($event) {
                        _vm.$router.push("/configuration/permission")
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-list" }),
                    _vm._v(" "),
                    _c("span", { staticClass: "d-none d-sm-inline" }, [
                      _vm._v(_vm._s(_vm.trans("configuration.permission")))
                    ])
                  ]
                ),
                _vm._v(" "),
                _c("div", { staticClass: "btn-group" }, [
                  _c(
                    "button",
                    {
                      staticClass:
                        "btn btn-info btn-sm dropdown-toggle no-caret ",
                      attrs: {
                        type: "button",
                        role: "menu",
                        id: "moduleLink",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false"
                      }
                    },
                    [
                      _c("i", { staticClass: "fas fa-boxes" }),
                      _vm._v(" "),
                      _c("span", { staticClass: "d-none d-sm-inline" }, [
                        _vm._v(
                          _vm._s(_vm.trans("configuration.locale_module")) + " "
                        ),
                        _c("span", [
                          _vm._v("(" + _vm._s(_vm.toWord(_vm.module)) + ")")
                        ]),
                        _vm._v(" "),
                        _c("i", { staticClass: "fas fa-chevron-down" })
                      ])
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      class: [
                        "dropdown-menu",
                        _vm.getConfig("direction") == "ltr"
                          ? "dropdown-menu-right"
                          : ""
                      ],
                      attrs: { "aria-labelledby": "moduleLink" }
                    },
                    _vm._l(_vm.modules, function(mod) {
                      return _c(
                        "button",
                        {
                          staticClass: "dropdown-item",
                          staticStyle: { cursor: "pointer" },
                          on: {
                            click: function($event) {
                              _vm.$router.push(
                                "/configuration/permission/" + mod
                              )
                            }
                          }
                        },
                        [
                          _vm._v(
                            "\n                                " +
                              _vm._s(_vm.trans(mod + "." + mod)) +
                              "  "
                          ),
                          mod == _vm.module
                            ? _c("span", { staticClass: "pull-right" }, [
                                _c("i", { staticClass: "fas fa-check" })
                              ])
                            : _vm._e()
                        ]
                      )
                    })
                  )
                ]),
                _vm._v(" "),
                _c("help-button", {
                  on: {
                    clicked: function($event) {
                      _vm.help_topic = "configuration.permission"
                    }
                  }
                })
              ],
              1
            )
          ])
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "container-fluid" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-body p-4" }, [
            _c("div", { staticClass: "table-responsive m-b-20" }, [
              _c(
                "form",
                {
                  on: {
                    submit: function($event) {
                      $event.preventDefault()
                      return _vm.proceed($event)
                    },
                    keydown: function($event) {
                      _vm.permissionForm.errors.clear($event.target.name)
                    }
                  }
                },
                [
                  _c("table", { staticClass: "table table-hover" }, [
                    _c("thead", [
                      _c(
                        "tr",
                        [
                          _c("th", [
                            _vm._v(
                              _vm._s(_vm.trans("configuration.permission"))
                            )
                          ]),
                          _vm._v(" "),
                          _vm._l(_vm.permissionForm.roles, function(
                            role_permission
                          ) {
                            return _c("th", [
                              _vm._v(_vm._s(_vm.toWord(role_permission.name)))
                            ])
                          })
                        ],
                        2
                      )
                    ]),
                    _vm._v(" "),
                    _c(
                      "tbody",
                      _vm._l(_vm.permissions, function(permission) {
                        return _c(
                          "tr",
                          [
                            _c("td", [_vm._v(_vm._s(_vm.toWord(permission)))]),
                            _vm._v(" "),
                            _vm._l(_vm.permissionForm.roles, function(
                              role_permission
                            ) {
                              return _c("td", [
                                _c(
                                  "label",
                                  {
                                    staticClass:
                                      "custom-control custom-checkbox",
                                    staticStyle: { cursor: "pointer" }
                                  },
                                  [
                                    _c("input", {
                                      directives: [
                                        {
                                          name: "model",
                                          rawName: "v-model",
                                          value: role_permission.permissions,
                                          expression:
                                            "role_permission.permissions"
                                        }
                                      ],
                                      staticClass: "custom-control-input",
                                      attrs: {
                                        type: "checkbox",
                                        disabled:
                                          role_permission.name ==
                                          _vm.getDefaultRole("admin")
                                            ? true
                                            : false
                                      },
                                      domProps: {
                                        value: permission,
                                        checked: Array.isArray(
                                          role_permission.permissions
                                        )
                                          ? _vm._i(
                                              role_permission.permissions,
                                              permission
                                            ) > -1
                                          : role_permission.permissions
                                      },
                                      on: {
                                        change: function($event) {
                                          var $$a = role_permission.permissions,
                                            $$el = $event.target,
                                            $$c = $$el.checked ? true : false
                                          if (Array.isArray($$a)) {
                                            var $$v = permission,
                                              $$i = _vm._i($$a, $$v)
                                            if ($$el.checked) {
                                              $$i < 0 &&
                                                _vm.$set(
                                                  role_permission,
                                                  "permissions",
                                                  $$a.concat([$$v])
                                                )
                                            } else {
                                              $$i > -1 &&
                                                _vm.$set(
                                                  role_permission,
                                                  "permissions",
                                                  $$a
                                                    .slice(0, $$i)
                                                    .concat($$a.slice($$i + 1))
                                                )
                                            }
                                          } else {
                                            _vm.$set(
                                              role_permission,
                                              "permissions",
                                              $$c
                                            )
                                          }
                                        }
                                      }
                                    }),
                                    _vm._v(" "),
                                    _c("span", {
                                      staticClass: "custom-control-label"
                                    })
                                  ]
                                )
                              ])
                            })
                          ],
                          2
                        )
                      })
                    )
                  ]),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      staticClass:
                        "btn btn-info waves-effect waves-light pull-right ",
                      attrs: { type: "button" },
                      on: { click: _vm.submit }
                    },
                    [_vm._v(_vm._s(_vm.trans("general.save")))]
                  )
                ]
              )
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c("right-panel", { attrs: { topic: _vm.help_topic } })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-1c20c1a4", module.exports)
  }
}

/***/ }),

/***/ 269:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1027)
/* template */
var __vue_template__ = __webpack_require__(1028)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/configuration/permission/module.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-1c20c1a4", Component.options)
  } else {
    hotAPI.reload("data-v-1c20c1a4", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ })

});
//# sourceMappingURL=module.js.map