webpackJsonp([292],{

/***/ 1014:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    data: function data() {
        return {
            configForm: new Form({
                facebook_link: '',
                twitter_link: '',
                linkedin_link: '',
                google_plus_link: '',
                youtube_link: '',
                config_type: ''
            }, false),
            help_topic: ''
        };
    },
    mounted: function mounted() {
        if (!helper.hasPermission('access-configuration')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }

        this.getConfiguration();
    },

    methods: {
        getConfiguration: function getConfiguration() {
            var _this = this;

            var loader = this.$loading.show();
            axios.get('/api/configuration').then(function (response) {
                _this.configForm = helper.formAssign(_this.configForm, response);
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        submit: function submit() {
            var _this2 = this;

            var loader = this.$loading.show();
            this.configForm.config_type = 'social_network';
            this.configForm.post('/api/configuration').then(function (response) {
                _this2.$store.dispatch('setConfig', { loaded: false });
                toastr.success(response.message);
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    }
};

/***/ }),

/***/ 1015:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("div", { staticClass: "page-titles" }, [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c("h3", { staticClass: "text-themecolor" }, [
              _vm._v(_vm._s(_vm.trans("configuration.social_network")))
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c(
              "div",
              { staticClass: "action-buttons pull-right" },
              [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info btn-sm",
                    on: {
                      click: function($event) {
                        _vm.$router.push("/dashboard")
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-home" }),
                    _vm._v(" "),
                    _c("span", { staticClass: "d-none d-sm-inline" }, [
                      _vm._v(_vm._s(_vm.trans("general.home")))
                    ])
                  ]
                ),
                _vm._v(" "),
                _c("help-button", {
                  on: {
                    clicked: function($event) {
                      _vm.help_topic = "configuration.social_network"
                    }
                  }
                })
              ],
              1
            )
          ])
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "container-fluid" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-body p-4" }, [
            _c(
              "form",
              {
                on: {
                  submit: function($event) {
                    $event.preventDefault()
                    return _vm.submit($event)
                  },
                  keydown: function($event) {
                    _vm.configForm.errors.clear($event.target.name)
                  }
                }
              },
              [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-12 col-sm-6" }, [
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _vm._v(
                            _vm._s(
                              _vm.trans("configuration.social_network_link", {
                                name: "Facebook"
                              })
                            )
                          )
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.configForm.facebook_link,
                              expression: "configForm.facebook_link"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "facebook_link",
                            placeholder: _vm.trans(
                              "configuration.facebook_link"
                            )
                          },
                          domProps: { value: _vm.configForm.facebook_link },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.configForm,
                                "facebook_link",
                                $event.target.value
                              )
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("show-error", {
                          attrs: {
                            "form-name": _vm.configForm,
                            "prop-name": "facebook_link"
                          }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-12 col-sm-6" }, [
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _vm._v(
                            _vm._s(
                              _vm.trans("configuration.social_network_link", {
                                name: "Twitter"
                              })
                            )
                          )
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.configForm.twitter_link,
                              expression: "configForm.twitter_link"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "twitter_link",
                            placeholder: _vm.trans("configuration.twitter_link")
                          },
                          domProps: { value: _vm.configForm.twitter_link },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.configForm,
                                "twitter_link",
                                $event.target.value
                              )
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("show-error", {
                          attrs: {
                            "form-name": _vm.configForm,
                            "prop-name": "twitter_link"
                          }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-12 col-sm-6" }, [
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _vm._v(
                            _vm._s(
                              _vm.trans("configuration.social_network_link", {
                                name: "LinkedIn"
                              })
                            )
                          )
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.configForm.linkedin_link,
                              expression: "configForm.linkedin_link"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "linkedin_link",
                            placeholder: _vm.trans(
                              "configuration.linkedin_link"
                            )
                          },
                          domProps: { value: _vm.configForm.linkedin_link },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.configForm,
                                "linkedin_link",
                                $event.target.value
                              )
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("show-error", {
                          attrs: {
                            "form-name": _vm.configForm,
                            "prop-name": "linkedin_link"
                          }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-12 col-sm-6" }, [
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _vm._v(
                            _vm._s(
                              _vm.trans("configuration.social_network_link", {
                                name: "Google Plus"
                              })
                            )
                          )
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.configForm.google_plus_link,
                              expression: "configForm.google_plus_link"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "google_plus_link",
                            placeholder: _vm.trans(
                              "configuration.google_plus_link"
                            )
                          },
                          domProps: { value: _vm.configForm.google_plus_link },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.configForm,
                                "google_plus_link",
                                $event.target.value
                              )
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("show-error", {
                          attrs: {
                            "form-name": _vm.configForm,
                            "prop-name": "google_plus_link"
                          }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-12 col-sm-6" }, [
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _vm._v(
                            _vm._s(
                              _vm.trans("configuration.social_network_link", {
                                name: "Youtube"
                              })
                            )
                          )
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.configForm.youtube_link,
                              expression: "configForm.youtube_link"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: {
                            type: "text",
                            name: "youtube_link",
                            placeholder: _vm.trans("configuration.youtube_link")
                          },
                          domProps: { value: _vm.configForm.youtube_link },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.configForm,
                                "youtube_link",
                                $event.target.value
                              )
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("show-error", {
                          attrs: {
                            "form-name": _vm.configForm,
                            "prop-name": "youtube_link"
                          }
                        })
                      ],
                      1
                    )
                  ])
                ]),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass:
                      "btn btn-info waves-effect waves-light pull-right m-t-10",
                    attrs: { type: "submit" }
                  },
                  [_vm._v(_vm._s(_vm.trans("general.save")))]
                )
              ]
            )
          ])
        ])
      ]),
      _vm._v(" "),
      _c("right-panel", { attrs: { topic: _vm.help_topic } })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-488883e8", module.exports)
  }
}

/***/ }),

/***/ 264:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1014)
/* template */
var __vue_template__ = __webpack_require__(1015)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/configuration/social/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-488883e8", Component.options)
  } else {
    hotAPI.reload("data-v-488883e8", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ })

});
//# sourceMappingURL=index.js.map