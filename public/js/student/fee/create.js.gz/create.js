webpackJsonp([158],{

/***/ 1727:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _summary = __webpack_require__(644);

var _summary2 = _interopRequireDefault(_summary);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: { studentSummary: _summary2.default },
    data: function data() {
        return {
            uuid: this.$route.params.uuid,
            record_id: this.$route.params.record_id,
            transport_circles: [],
            fee_concessions: [],
            student_record: {},
            studentFeeRecordForm: new Form({
                transport_circle_id: null,
                fee_concession_id: null
            }, false)
        };
    },
    mounted: function mounted() {
        if (!helper.hasPermission('set-fee')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }

        this.getRecord();
    },

    methods: {
        hasPermission: function hasPermission(permission) {
            return helper.hasPermission(permission);
        },
        getConfig: function getConfig(config) {
            return helper.getConfig(config);
        },
        getStudentName: function getStudentName(student) {
            return helper.getStudentName(student);
        },
        getRecord: function getRecord() {
            var _this = this;

            axios.get('/api/student/' + this.uuid + '/record/' + this.record_id).then(function (response) {
                _this.student_record = response.student_record;
                _this.fee_concessions = response.fee_concessions;
                _this.transport_circles = response.transport_circles;

                if (_this.student_record.fee_allocation_id) {
                    toastr.error(i18n.student.fee_already_allocated);
                    _this.$router('/student/' + _this.uuid + '/fee/' + _this.record_id);
                }
            }).catch(function (error) {
                helper.showErrorMsg(error);
                _this.$router.push('/student/' + _this.uuid);
            });
        },
        submit: function submit() {
            var _this2 = this;

            this.studentFeeRecordForm.post('/api/student/' + this.uuid + '/fee/' + this.record_id).then(function (response) {
                toastr.success(response.message);
                _this2.$router.push('/student/' + _this2.uuid + '/fee/' + _this2.record_id);
            }).catch(function (error) {
                helper.showErrorMsg(error);
            });
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1728:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-titles" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("h3", { staticClass: "text-themecolor" }, [
            _vm._v(_vm._s(_vm.trans("student.set_fee")) + " "),
            _vm.student_record.student
              ? _c("small", [
                  _vm._v(
                    _vm._s(_vm.getStudentName(_vm.student_record.student)) +
                      "  (" +
                      _vm._s(_vm.student_record.academic_session.name) +
                      ")"
                  )
                ])
              : _vm._e()
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c(
            "div",
            { staticClass: "action-buttons pull-right" },
            [
              _c(
                "router-link",
                {
                  staticClass: "btn btn-info btn-sm",
                  attrs: { to: "/student/admission" }
                },
                [
                  _c("i", { staticClass: "fas fa-list" }),
                  _vm._v(" "),
                  _c("span", { staticClass: "d-none d-sm-inline" }, [
                    _vm._v(_vm._s(_vm.trans("student.student")))
                  ])
                ]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "btn-group" }, [
                _c(
                  "button",
                  {
                    directives: [
                      {
                        name: "tooltip",
                        rawName: "v-tooltip",
                        value: _vm.trans("general.more_option"),
                        expression: "trans('general.more_option')"
                      }
                    ],
                    staticClass:
                      "btn btn-info btn-sm dropdown-toggle no-caret ",
                    attrs: {
                      type: "button",
                      role: "menu",
                      id: "moreOption",
                      "data-toggle": "dropdown",
                      "aria-haspopup": "true",
                      "aria-expanded": "false"
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-ellipsis-h" }),
                    _vm._v(" "),
                    _c("span", { staticClass: "d-none d-sm-inline" })
                  ]
                ),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    class: [
                      "dropdown-menu",
                      _vm.getConfig("direction") == "ltr"
                        ? "dropdown-menu-right"
                        : ""
                    ],
                    attrs: { "aria-labelledby": "moreOption" }
                  },
                  [
                    _c(
                      "button",
                      {
                        staticClass: "dropdown-item custom-dropdown",
                        on: {
                          click: function($event) {
                            _vm.$router.push(
                              "/student/" + _vm.student_record.student.uuid
                            )
                          }
                        }
                      },
                      [
                        _c("i", { staticClass: "fas fa-arrow-circle-right" }),
                        _vm._v(" " + _vm._s(_vm.trans("student.view_detail")))
                      ]
                    )
                  ]
                )
              ])
            ],
            1
          )
        ])
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "container-fluid" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12" }, [
          _c("div", { staticClass: "card" }, [
            _c(
              "div",
              { staticClass: "card-body py-4" },
              [
                _c("student-summary", {
                  staticClass: "border-bottom",
                  attrs: { "student-record": _vm.student_record }
                })
              ],
              1
            ),
            _vm._v(" "),
            _c("div", { staticClass: "card-body px-4" }, [
              _c(
                "form",
                {
                  on: {
                    submit: function($event) {
                      $event.preventDefault()
                      return _vm.submit($event)
                    },
                    keydown: function($event) {
                      _vm.studentFeeRecordForm.errors.clear($event.target.name)
                    }
                  }
                },
                [
                  _c("div", { staticClass: "row" }, [
                    _c("div", { staticClass: "col-12 col-sm-4" }, [
                      _c(
                        "div",
                        { staticClass: "form-group" },
                        [
                          _c("label", { attrs: { for: "" } }, [
                            _vm._v(
                              _vm._s(_vm.trans("transport.transport_circle"))
                            )
                          ]),
                          _vm._v(" "),
                          _c(
                            "select",
                            {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value:
                                    _vm.studentFeeRecordForm
                                      .transport_circle_id,
                                  expression:
                                    "studentFeeRecordForm.transport_circle_id"
                                }
                              ],
                              staticClass: "custom-select col-12",
                              attrs: { name: "transport_circle_id" },
                              on: {
                                change: [
                                  function($event) {
                                    var $$selectedVal = Array.prototype.filter
                                      .call($event.target.options, function(o) {
                                        return o.selected
                                      })
                                      .map(function(o) {
                                        var val =
                                          "_value" in o ? o._value : o.value
                                        return val
                                      })
                                    _vm.$set(
                                      _vm.studentFeeRecordForm,
                                      "transport_circle_id",
                                      $event.target.multiple
                                        ? $$selectedVal
                                        : $$selectedVal[0]
                                    )
                                  },
                                  function($event) {}
                                ]
                              }
                            },
                            [
                              _c("option", { domProps: { value: null } }, [
                                _vm._v(
                                  _vm._s(_vm.trans("transport.no_transport"))
                                )
                              ]),
                              _vm._v(" "),
                              _vm._l(_vm.transport_circles, function(
                                transport_circle
                              ) {
                                return _c(
                                  "option",
                                  { domProps: { value: transport_circle.id } },
                                  [
                                    _vm._v(
                                      "\n                                                " +
                                        _vm._s(transport_circle.name) +
                                        "\n                                            "
                                    )
                                  ]
                                )
                              })
                            ],
                            2
                          ),
                          _vm._v(" "),
                          _c("show-error", {
                            attrs: {
                              "form-name": _vm.studentFeeRecordForm,
                              "prop-name": "transport_circle_id"
                            }
                          })
                        ],
                        1
                      )
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-12 col-sm-4" }, [
                      _c(
                        "div",
                        { staticClass: "form-group" },
                        [
                          _c("label", { attrs: { for: "" } }, [
                            _vm._v(_vm._s(_vm.trans("finance.fee_concession")))
                          ]),
                          _vm._v(" "),
                          _c(
                            "select",
                            {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value:
                                    _vm.studentFeeRecordForm.fee_concession_id,
                                  expression:
                                    "studentFeeRecordForm.fee_concession_id"
                                }
                              ],
                              staticClass: "custom-select col-12",
                              attrs: { name: "fee_concession_id" },
                              on: {
                                change: [
                                  function($event) {
                                    var $$selectedVal = Array.prototype.filter
                                      .call($event.target.options, function(o) {
                                        return o.selected
                                      })
                                      .map(function(o) {
                                        var val =
                                          "_value" in o ? o._value : o.value
                                        return val
                                      })
                                    _vm.$set(
                                      _vm.studentFeeRecordForm,
                                      "fee_concession_id",
                                      $event.target.multiple
                                        ? $$selectedVal
                                        : $$selectedVal[0]
                                    )
                                  },
                                  function($event) {}
                                ]
                              }
                            },
                            [
                              _c("option", { domProps: { value: null } }, [
                                _vm._v(
                                  _vm._s(_vm.trans("finance.no_fee_concession"))
                                )
                              ]),
                              _vm._v(" "),
                              _vm._l(_vm.fee_concessions, function(
                                fee_concession
                              ) {
                                return _c(
                                  "option",
                                  { domProps: { value: fee_concession.id } },
                                  [
                                    _vm._v(
                                      "\n                                                " +
                                        _vm._s(fee_concession.name) +
                                        "\n                                            "
                                    )
                                  ]
                                )
                              })
                            ],
                            2
                          ),
                          _vm._v(" "),
                          _c("show-error", {
                            attrs: {
                              "form-name": _vm.studentFeeRecordForm,
                              "prop-name": "fee_concession_id"
                            }
                          })
                        ],
                        1
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-info waves-effect waves-light",
                      attrs: { type: "submit" }
                    },
                    [_vm._v(_vm._s(_vm.trans("general.save")))]
                  )
                ]
              )
            ])
          ])
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-2d681290", module.exports)
  }
}

/***/ }),

/***/ 483:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1727)
/* template */
var __vue_template__ = __webpack_require__(1728)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/student/fee/create.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-2d681290", Component.options)
  } else {
    hotAPI.reload("data-v-2d681290", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 644:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(645)
/* template */
var __vue_template__ = __webpack_require__(646)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/student/summary.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-67e4e623", Component.options)
  } else {
    hotAPI.reload("data-v-67e4e623", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 645:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
	props: ['studentRecord'],
	data: function data() {
		return {
			student_record: {}
		};
	},
	mounted: function mounted() {},

	methods: {
		getStudentName: function getStudentName(student) {
			return helper.getStudentName(student);
		},
		getAdmissionNumber: function getAdmissionNumber(admission) {
			return helper.getAdmissionNumber(admission);
		}
	},
	filters: {
		moment: function moment(date) {
			return helper.formatDate(date);
		},
		momentDateTime: function momentDateTime(date) {
			return helper.formatDateTime(date);
		}
	},
	computed: {
		getImage: function getImage() {
			if (!this.student_record.student.student_photo) {
				return this.student_record.student.gender == 'female' ? '/images/female.png' : '/images/male.png';
			} else {
				return '/' + this.student_record.student.student_photo;
			}
		}
	},
	watch: {
		studentRecord: function studentRecord(val) {
			this.student_record = val;
		}
	}
};

/***/ }),

/***/ 646:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.student_record.student
    ? _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "form-group text-center" }, [
            _c("img", {
              staticClass: "img-fluid",
              staticStyle: { "max-width": "200px" },
              attrs: { src: _vm.getImage }
            })
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c("div", { staticClass: "table-responsive" }, [
            _c(
              "table",
              { staticClass: "table table-borderless custom-show-table" },
              [
                _c("tbody", [
                  _c("tr", [
                    _c("td", { staticClass: "font-weight-bold" }, [
                      _vm._v(_vm._s(_vm.trans("student.name")))
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(_vm.getStudentName(_vm.student_record.student))
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", { staticClass: "font-weight-bold" }, [
                      _vm._v(_vm._s(_vm.trans("student.admission_number")))
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(
                          _vm.getAdmissionNumber(_vm.student_record.admission)
                        )
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", { staticClass: "font-weight-bold" }, [
                      _vm._v(_vm._s(_vm.trans("student.date_of_admission")))
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(
                          _vm._f("moment")(
                            _vm.student_record.admission.date_of_admission
                          )
                        )
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", { staticClass: "font-weight-bold" }, [
                      _vm._v(_vm._s(_vm.trans("academic.course")))
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(
                          _vm.student_record.batch.course.name +
                            " (" +
                            _vm.student_record.batch.course.course_group.name +
                            ")"
                        )
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", { staticClass: "font-weight-bold" }, [
                      _vm._v(_vm._s(_vm.trans("academic.batch")))
                    ]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(_vm.student_record.batch.name))])
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", { staticClass: "font-weight-bold" }, [
                      _vm._v(_vm._s(_vm.trans("student.date_of_birth")))
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(
                          _vm._f("moment")(
                            _vm.student_record.student.date_of_birth
                          )
                        )
                      )
                    ])
                  ])
                ])
              ]
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-4" }, [
          _c("div", { staticClass: "table-responsive" }, [
            _c(
              "table",
              { staticClass: "table table-borderless custom-show-table" },
              [
                _c("tbody", [
                  _c("tr", [
                    _c("td", { staticClass: "font-weight-bold" }, [
                      _vm._v(_vm._s(_vm.trans("student.father_name")))
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(
                          _vm.student_record.student.parent
                            ? _vm.student_record.student.parent.father_name
                            : ""
                        )
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", { staticClass: "font-weight-bold" }, [
                      _vm._v(_vm._s(_vm.trans("student.mother_name")))
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(
                          _vm.student_record.student.parent
                            ? _vm.student_record.student.parent.mother_name
                            : ""
                        )
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", { staticClass: "font-weight-bold" }, [
                      _vm._v(_vm._s(_vm.trans("student.contact_number")))
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(_vm._s(_vm.student_record.student.contact_number))
                    ])
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", { staticClass: "font-weight-bold" }, [
                      _vm._v(_vm._s(_vm.trans("student.present_address")))
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        "\n\t                            " +
                          _vm._s(
                            _vm.student_record.student.present_address_line_1
                          ) +
                          "\n\t                            "
                      ),
                      _vm.student_record.student.present_address_line_2
                        ? _c("span", [
                            _vm._v(
                              ", " +
                                _vm._s(
                                  _vm.student_record.student
                                    .present_address_line_2
                                )
                            )
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.student_record.student.present_city
                        ? _c("span", [
                            _c("br"),
                            _vm._v(
                              " " +
                                _vm._s(_vm.student_record.student.present_city)
                            )
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.student_record.student.present_state
                        ? _c("span", [
                            _vm._v(
                              ", " +
                                _vm._s(_vm.student_record.student.present_state)
                            )
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.student_record.student.present_zipcode
                        ? _c("span", [
                            _vm._v(
                              ", " +
                                _vm._s(
                                  _vm.student_record.student.present_zipcode
                                )
                            )
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.student_record.student.present_country
                        ? _c("span", [
                            _c("br"),
                            _vm._v(
                              " " +
                                _vm._s(
                                  _vm.student_record.student.present_country
                                )
                            )
                          ])
                        : _vm._e()
                    ])
                  ])
                ])
              ]
            )
          ])
        ])
      ])
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-67e4e623", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=create.js.map