webpackJsonp([281],{

/***/ 1260:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {};

/***/ }),

/***/ 1261:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-titles" }, [
      _c("h3", { staticClass: "text-themecolor" }, [
        _vm._v(_vm._s(_vm.trans("general.report")))
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "container-fluid container-body" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("finance.fee_summary_report")))
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(
                      _vm.trans("finance.fee_summary_report_module_description")
                    )
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/finance/fee/report/summary" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("finance.fee_summary_report")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("finance.fee_concession_report")))
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(
                      _vm.trans(
                        "finance.fee_concession_report_module_description"
                      )
                    )
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/finance/fee/report/concession" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("finance.fee_concession_report")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("finance.fee_due_report")))
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(
                      _vm.trans("finance.fee_due_report_module_description")
                    )
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/finance/fee/report/due" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("finance.fee_due_report")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("finance.fee_payment_report")))
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(
                      _vm.trans("finance.fee_payment_report_module_description")
                    )
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/finance/fee/report/payment" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("finance.fee_payment_report")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(
                    _vm._s(_vm.trans("finance.transaction_summary_report"))
                  )
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(
                      _vm.trans(
                        "finance.transaction_summary_report_module_description"
                      )
                    )
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/finance/transaction/report/summary" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("finance.transaction_summary_report")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(
                    _vm._s(_vm.trans("finance.transaction_day_book_report"))
                  )
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(
                      _vm.trans(
                        "finance.transaction_day_book_report_module_description"
                      )
                    )
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/finance/transaction/report/day-book" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("finance.transaction_day_book_report")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-55835748", module.exports)
  }
}

/***/ }),

/***/ 376:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1260)
/* template */
var __vue_template__ = __webpack_require__(1261)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/finance/report.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-55835748", Component.options)
  } else {
    hotAPI.reload("data-v-55835748", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ })

});
//# sourceMappingURL=report.js.map