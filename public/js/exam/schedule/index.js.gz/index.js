webpackJsonp([284],{

/***/ 1729:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    data: function data() {
        return {
            exam_schedules: {
                total: 0,
                data: []
            },
            filter: {
                sort_by: 'created_at',
                order: 'desc',
                name: '',
                page_length: helper.getConfig('page_length')
            },
            orderByOptions: [{
                value: 'created_at',
                translation: i18n.general.created_at
            }],
            showFilterPanel: false,
            showDetail: true,
            help_topic: ''
        };
    },
    mounted: function mounted() {
        if (!helper.hasPermission('list-exam-schedule')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }

        this.getExamSchedules();
    },

    methods: {
        hasPermission: function hasPermission(permission) {
            return helper.hasPermission(permission);
        },
        hasNotAnyRole: function hasNotAnyRole(roles) {
            return helper.hasNotAnyRole(roles);
        },
        getExamSchedules: function getExamSchedules(page) {
            var _this = this;

            var loader = this.$loading.show();
            if (typeof page !== 'number') {
                page = 1;
            }
            var url = helper.getFilterURL(this.filter);
            axios.get('/api/exam/schedule?page=' + page + url).then(function (response) {
                _this.exam_schedules = response;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        editExamSchedule: function editExamSchedule(exam_schedule) {
            this.$router.push('/exam/schedule/' + exam_schedule.id + '/edit');
        },
        confirmDelete: function confirmDelete(exam_schedule) {
            var _this2 = this;

            return function (dialog) {
                return _this2.deleteExam(exam_schedule);
            };
        },
        deleteExam: function deleteExam(exam_schedule) {
            var _this3 = this;

            var loader = this.$loading.show();
            axios.delete('/api/exam/schedule/' + exam_schedule.id).then(function (response) {
                toastr.success(response.message);
                _this3.getExamSchedules();
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getConfig: function getConfig(config) {
            return helper.getConfig(config);
        },
        print: function print() {
            var loader = this.$loading.show();
            axios.post('/api/exam/schedule/print', { filter: this.filter }).then(function (response) {
                var print = window.open("/print");
                loader.hide();
                print.document.write(response);
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        pdf: function pdf() {
            var _this4 = this;

            var loader = this.$loading.show();
            axios.post('/api/exam/schedule/pdf', { filter: this.filter }).then(function (response) {
                loader.hide();
                window.open('/download/report/' + response + '?token=' + _this4.authToken);
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getStartDate: function getStartDate(exam_schedule) {
            var records = exam_schedule.records.filter(function (o) {
                return o.date != null;
            });

            if (!records.length) {
                return '-';
            }

            return helper.formatDate(records[0].date);
        },
        getEndDate: function getEndDate(exam_schedule) {
            var records = exam_schedule.records.filter(function (o) {
                return o.date != null;
            });

            if (!records.length) {
                return '-';
            }

            return helper.formatDate(records[records.length - 1].date);
        }
    },
    filters: {
        moment: function moment(date) {
            return helper.formatDate(date);
        },
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        }
    },
    watch: {
        'filter.sort_by': function filterSort_by(val) {
            this.getExamSchedules();
        },
        'filter.order': function filterOrder(val) {
            this.getExamSchedules();
        },
        'filter.page_length': function filterPage_length(val) {
            this.getExamSchedules();
        }
    },
    computed: {
        authToken: function authToken() {
            return helper.getAuthToken();
        }
    }
};

/***/ }),

/***/ 1730:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("div", { staticClass: "page-titles" }, [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c("h3", { staticClass: "text-themecolor" }, [
              _vm._v(
                _vm._s(_vm.trans("exam.schedule")) + " \n                    "
              ),
              _vm.exam_schedules.total
                ? _c(
                    "span",
                    { staticClass: "card-subtitle d-none d-sm-inline" },
                    [
                      _vm._v(
                        _vm._s(
                          _vm.trans("general.total_result_found", {
                            count: _vm.exam_schedules.total,
                            from: _vm.exam_schedules.from,
                            to: _vm.exam_schedules.to
                          })
                        )
                      )
                    ]
                  )
                : _c(
                    "span",
                    { staticClass: "card-subtitle d-none d-sm-inline" },
                    [_vm._v(_vm._s(_vm.trans("general.no_result_found")))]
                  )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c(
              "div",
              { staticClass: "action-buttons pull-right" },
              [
                _vm.exam_schedules.total &&
                _vm.hasPermission("create-exam-schedule")
                  ? _c(
                      "button",
                      {
                        directives: [
                          {
                            name: "tooltip",
                            rawName: "v-tooltip",
                            value: _vm.trans("general.add_new"),
                            expression: "trans('general.add_new')"
                          }
                        ],
                        staticClass: "btn btn-info btn-sm",
                        on: {
                          click: function($event) {
                            _vm.$router.push("/exam/schedule/create")
                          }
                        }
                      },
                      [
                        _c("i", { staticClass: "fas fa-plus" }),
                        _vm._v(" "),
                        _c("span", { staticClass: "d-none d-sm-inline" }, [
                          _vm._v(_vm._s(_vm.trans("exam.add_new_schedule")))
                        ])
                      ]
                    )
                  : _vm._e(),
                _vm._v(" "),
                !_vm.showFilterPanel
                  ? _c(
                      "button",
                      {
                        staticClass: "btn btn-info btn-sm",
                        on: {
                          click: function($event) {
                            _vm.showFilterPanel = !_vm.showFilterPanel
                          }
                        }
                      },
                      [
                        _c("i", { staticClass: "fas fa-filter" }),
                        _vm._v(" "),
                        _c("span", { staticClass: "d-none d-sm-inline" }, [
                          _vm._v(_vm._s(_vm.trans("general.filter")))
                        ])
                      ]
                    )
                  : _vm._e(),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info btn-sm",
                    on: {
                      click: function($event) {
                        _vm.showDetail = !_vm.showDetail
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-arrows-alt" }),
                    _vm._v(" "),
                    _c("span", { staticClass: "d-none d-sm-inline" }, [
                      _vm.showDetail
                        ? _c("span", [
                            _vm._v(_vm._s(_vm.trans("general.hide_detail")))
                          ])
                        : _c("span", [
                            _vm._v(_vm._s(_vm.trans("general.view_detail")))
                          ])
                    ])
                  ]
                ),
                _vm._v(" "),
                _c("sort-by", {
                  attrs: {
                    "order-by-options": _vm.orderByOptions,
                    "sort-by": _vm.filter.sort_by,
                    order: _vm.filter.order
                  },
                  on: {
                    updateSortBy: function(value) {
                      _vm.filter.sort_by = value
                    },
                    updateOrder: function(value) {
                      _vm.filter.order = value
                    }
                  }
                }),
                _vm._v(" "),
                _c("div", { staticClass: "btn-group" }, [
                  _c(
                    "button",
                    {
                      directives: [
                        {
                          name: "tooltip",
                          rawName: "v-tooltip",
                          value: _vm.trans("general.more_option"),
                          expression: "trans('general.more_option')"
                        }
                      ],
                      staticClass:
                        "btn btn-info btn-sm dropdown-toggle no-caret ",
                      attrs: {
                        type: "button",
                        role: "menu",
                        id: "moreOption",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false"
                      }
                    },
                    [
                      _c("i", { staticClass: "fas fa-ellipsis-h" }),
                      _vm._v(" "),
                      _c("span", { staticClass: "d-none d-sm-inline" })
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      class: [
                        "dropdown-menu",
                        _vm.getConfig("direction") == "ltr"
                          ? "dropdown-menu-right"
                          : ""
                      ],
                      attrs: { "aria-labelledby": "moreOption" }
                    },
                    [
                      _vm.hasPermission("list-exam")
                        ? _c(
                            "button",
                            {
                              staticClass: "dropdown-item custom-dropdown",
                              on: {
                                click: function($event) {
                                  _vm.$router.push("/exam")
                                }
                              }
                            },
                            [
                              _c("i", { staticClass: "fas fa-file-alt" }),
                              _vm._v(" " + _vm._s(_vm.trans("exam.exam")))
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          staticClass: "dropdown-item custom-dropdown",
                          on: { click: _vm.print }
                        },
                        [
                          _c("i", { staticClass: "fas fa-print" }),
                          _vm._v(" " + _vm._s(_vm.trans("general.print")))
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          staticClass: "dropdown-item custom-dropdown",
                          on: { click: _vm.pdf }
                        },
                        [
                          _c("i", { staticClass: "fas fa-file-pdf" }),
                          _vm._v(
                            " " + _vm._s(_vm.trans("general.generate_pdf"))
                          )
                        ]
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("help-button", {
                  on: {
                    clicked: function($event) {
                      _vm.help_topic = "exam.schedule"
                    }
                  }
                })
              ],
              1
            )
          ])
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "container-fluid" },
        [
          _c("transition", { attrs: { name: "fade" } }, [
            _vm.showFilterPanel
              ? _c("div", { staticClass: "card card-form" }, [
                  _c("div", { staticClass: "card-body" }, [
                    _c("h4", { staticClass: "card-title" }, [
                      _vm._v(_vm._s(_vm.trans("general.filter")))
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "row" }, [
                      _c("div", { staticClass: "col-12 col-sm-4" })
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "card-footer text-right" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-danger",
                          attrs: { type: "button" },
                          on: {
                            click: function($event) {
                              _vm.showFilterPanel = false
                            }
                          }
                        },
                        [_vm._v(_vm._s(_vm.trans("general.cancel")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-info waves-effect waves-light",
                          attrs: { type: "button" },
                          on: { click: _vm.getExamSchedules }
                        },
                        [_vm._v(_vm._s(_vm.trans("general.filter")))]
                      )
                    ])
                  ])
                ])
              : _vm._e()
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "card" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _vm.exam_schedules.total
                  ? _c("div", { staticClass: "table-responsive p-2" }, [
                      _c("table", { staticClass: "table table-sm" }, [
                        _c("thead", [
                          _c(
                            "tr",
                            [
                              _c("th", [
                                _vm._v(_vm._s(_vm.trans("exam.exam")))
                              ]),
                              _vm._v(" "),
                              _c("th", [
                                _vm._v(_vm._s(_vm.trans("academic.batch")))
                              ]),
                              _vm._v(" "),
                              _c("th", [
                                _vm._v(_vm._s(_vm.trans("exam.schedule")))
                              ]),
                              _vm._v(" "),
                              _c("th", [
                                _vm._v(_vm._s(_vm.trans("exam.assessment")))
                              ]),
                              _vm._v(" "),
                              _vm.hasNotAnyRole(["student", "parent"])
                                ? [
                                    _c("th", [
                                      _vm._v(_vm._s(_vm.trans("exam.grade")))
                                    ]),
                                    _vm._v(" "),
                                    _c("th", { staticClass: "table-option" }, [
                                      _vm._v(
                                        _vm._s(_vm.trans("general.action"))
                                      )
                                    ])
                                  ]
                                : _vm._e()
                            ],
                            2
                          )
                        ]),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          _vm._l(_vm.exam_schedules.data, function(
                            exam_schedule
                          ) {
                            return _c(
                              "tr",
                              [
                                _c("td", {
                                  domProps: {
                                    textContent: _vm._s(exam_schedule.exam.name)
                                  }
                                }),
                                _vm._v(" "),
                                _c("td", {
                                  domProps: {
                                    textContent: _vm._s(
                                      exam_schedule.batch.course.name +
                                        " " +
                                        exam_schedule.batch.name
                                    )
                                  }
                                }),
                                _vm._v(" "),
                                _c("td", [
                                  !_vm.showDetail
                                    ? _c("span", [
                                        _vm._v(
                                          "\n                                        " +
                                            _vm._s(
                                              _vm.trans(
                                                "exam.schedule_date_range",
                                                {
                                                  start_date: _vm.getStartDate(
                                                    exam_schedule
                                                  ),
                                                  end_date: _vm.getEndDate(
                                                    exam_schedule
                                                  )
                                                }
                                              )
                                            ) +
                                            "\n                                    "
                                        )
                                      ])
                                    : _c(
                                        "span",
                                        _vm._l(exam_schedule.records, function(
                                          record
                                        ) {
                                          return record.date
                                            ? _c(
                                                "div",
                                                { staticClass: "row" },
                                                [
                                                  _c(
                                                    "div",
                                                    { staticClass: "col-6" },
                                                    [
                                                      _vm._v(
                                                        _vm._s(
                                                          record.subject.name +
                                                            " (" +
                                                            record.subject
                                                              .code +
                                                            ")"
                                                        )
                                                      )
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "div",
                                                    { staticClass: "col-6" },
                                                    [
                                                      _vm._v(
                                                        _vm._s(
                                                          _vm._f("moment")(
                                                            record.date
                                                          )
                                                        )
                                                      )
                                                    ]
                                                  )
                                                ]
                                              )
                                            : _vm._e()
                                        })
                                      )
                                ]),
                                _vm._v(" "),
                                _c("td", [
                                  !_vm.showDetail
                                    ? _c("span", [
                                        _vm._v(
                                          _vm._s(exam_schedule.assessment.name)
                                        )
                                      ])
                                    : _c(
                                        "span",
                                        _vm._l(
                                          exam_schedule.assessment.details,
                                          function(detail) {
                                            return _c(
                                              "div",
                                              { staticClass: "row" },
                                              [
                                                _c(
                                                  "div",
                                                  { staticClass: "col-4" },
                                                  [_vm._v(_vm._s(detail.name))]
                                                ),
                                                _vm._v(" "),
                                                _c(
                                                  "div",
                                                  { staticClass: "col-8" },
                                                  [
                                                    _vm._v(
                                                      _vm._s(
                                                        _vm.trans(
                                                          "exam.assessment_detail",
                                                          {
                                                            max_mark:
                                                              detail.max_mark,
                                                            pass_percentage:
                                                              detail.pass_percentage
                                                          }
                                                        )
                                                      )
                                                    )
                                                  ]
                                                )
                                              ]
                                            )
                                          }
                                        )
                                      )
                                ]),
                                _vm._v(" "),
                                _vm.hasNotAnyRole(["student", "parent"])
                                  ? [
                                      _c("td", [
                                        _vm._v(
                                          _vm._s(
                                            exam_schedule.exam_grade_id
                                              ? exam_schedule.grade.name
                                              : "-"
                                          )
                                        )
                                      ]),
                                      _vm._v(" "),
                                      _c(
                                        "td",
                                        { staticClass: "table-option" },
                                        [
                                          _c(
                                            "div",
                                            { staticClass: "btn-group" },
                                            [
                                              _vm.hasPermission(
                                                "edit-exam-schedule"
                                              )
                                                ? _c(
                                                    "button",
                                                    {
                                                      directives: [
                                                        {
                                                          name: "tooltip",
                                                          rawName: "v-tooltip",
                                                          value: _vm.trans(
                                                            "exam.edit_schedule"
                                                          ),
                                                          expression:
                                                            "trans('exam.edit_schedule')"
                                                        }
                                                      ],
                                                      staticClass:
                                                        "btn btn-info btn-sm",
                                                      on: {
                                                        click: function(
                                                          $event
                                                        ) {
                                                          $event.preventDefault()
                                                          _vm.editExamSchedule(
                                                            exam_schedule
                                                          )
                                                        }
                                                      }
                                                    },
                                                    [
                                                      _c("i", {
                                                        staticClass:
                                                          "fas fa-edit"
                                                      })
                                                    ]
                                                  )
                                                : _vm._e(),
                                              _vm._v(" "),
                                              _vm.hasPermission(
                                                "delete-exam-schedule"
                                              )
                                                ? _c(
                                                    "button",
                                                    {
                                                      directives: [
                                                        {
                                                          name: "confirm",
                                                          rawName: "v-confirm",
                                                          value: {
                                                            ok: _vm.confirmDelete(
                                                              exam_schedule
                                                            )
                                                          },
                                                          expression:
                                                            "{ok: confirmDelete(exam_schedule)}"
                                                        },
                                                        {
                                                          name: "tooltip",
                                                          rawName: "v-tooltip",
                                                          value: _vm.trans(
                                                            "exam.delete_schedule"
                                                          ),
                                                          expression:
                                                            "trans('exam.delete_schedule')"
                                                        }
                                                      ],
                                                      key: exam_schedule.id,
                                                      staticClass:
                                                        "btn btn-danger btn-sm"
                                                    },
                                                    [
                                                      _c("i", {
                                                        staticClass:
                                                          "fas fa-trash"
                                                      })
                                                    ]
                                                  )
                                                : _vm._e()
                                            ]
                                          )
                                        ]
                                      )
                                    ]
                                  : _vm._e()
                              ],
                              2
                            )
                          })
                        )
                      ])
                    ])
                  : _vm._e(),
                _vm._v(" "),
                !_vm.exam_schedules.total
                  ? _c(
                      "module-info",
                      {
                        attrs: {
                          module: "exam",
                          title: "schedule_module_title",
                          description: "schedule_module_description",
                          icon: "check-circle"
                        }
                      },
                      [
                        _c("div", { attrs: { slot: "btn" }, slot: "btn" }, [
                          _vm.hasPermission("create-exam-schedule")
                            ? _c(
                                "button",
                                {
                                  staticClass: "btn btn-info btn-md",
                                  on: {
                                    click: function($event) {
                                      _vm.$router.push("/exam/schedule/create")
                                    }
                                  }
                                },
                                [
                                  _c("i", { staticClass: "fas fa-plus" }),
                                  _vm._v(
                                    " " + _vm._s(_vm.trans("general.add_new"))
                                  )
                                ]
                              )
                            : _vm._e()
                        ])
                      ]
                    )
                  : _vm._e(),
                _vm._v(" "),
                _c("pagination-record", {
                  attrs: {
                    "page-length": _vm.filter.page_length,
                    records: _vm.exam_schedules
                  },
                  on: {
                    "update:pageLength": function($event) {
                      _vm.$set(_vm.filter, "page_length", $event)
                    },
                    updateRecords: _vm.getExamSchedules
                  }
                })
              ],
              1
            )
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("right-panel", { attrs: { topic: _vm.help_topic } })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-5e4ff5ca", module.exports)
  }
}

/***/ }),

/***/ 484:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1729)
/* template */
var __vue_template__ = __webpack_require__(1730)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/exam/schedule/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-5e4ff5ca", Component.options)
  } else {
    hotAPI.reload("data-v-5e4ff5ca", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ })

});
//# sourceMappingURL=index.js.map