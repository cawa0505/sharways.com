webpackJsonp([5],{

/***/ 1499:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _form = __webpack_require__(855);

var _form2 = _interopRequireDefault(_form);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: { blockForm: _form2.default },
    data: function data() {
        return {
            uuid: this.$route.params.uuid
        };
    },
    mounted: function mounted() {
        if (!helper.frontendConfigurationAccessible()) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1500:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-titles" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("h3", { staticClass: "text-themecolor" }, [
            _vm._v(_vm._s(_vm.trans("frontend.edit_block")))
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("div", { staticClass: "action-buttons pull-right" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-info btn-sm",
                on: {
                  click: function($event) {
                    _vm.$router.push("/frontend/block")
                  }
                }
              },
              [
                _c("i", { staticClass: "fas fa-list" }),
                _vm._v(" "),
                _c("span", { staticClass: "d-none d-sm-inline" }, [
                  _vm._v(_vm._s(_vm.trans("frontend.block")))
                ])
              ]
            )
          ])
        ])
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "container-fluid" }, [
      _c("div", { staticClass: "card card-form" }, [
        _c(
          "div",
          { staticClass: "card-body p-t-20" },
          [_c("block-form", { attrs: { uuid: _vm.uuid } })],
          1
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-07efb0ba", module.exports)
  }
}

/***/ }),

/***/ 54:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1499)
/* template */
var __vue_template__ = __webpack_require__(1500)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/frontend/block/edit.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-07efb0ba", Component.options)
  } else {
    hotAPI.reload("data-v-07efb0ba", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 555:
/***/ (function(module, exports, __webpack_require__) {

var rng = __webpack_require__(556);
var bytesToUuid = __webpack_require__(557);

function v4(options, buf, offset) {
  var i = buf && offset || 0;

  if (typeof(options) == 'string') {
    buf = options === 'binary' ? new Array(16) : null;
    options = null;
  }
  options = options || {};

  var rnds = options.random || (options.rng || rng)();

  // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
  rnds[6] = (rnds[6] & 0x0f) | 0x40;
  rnds[8] = (rnds[8] & 0x3f) | 0x80;

  // Copy bytes to buffer, if provided
  if (buf) {
    for (var ii = 0; ii < 16; ++ii) {
      buf[i + ii] = rnds[ii];
    }
  }

  return buf || bytesToUuid(rnds);
}

module.exports = v4;


/***/ }),

/***/ 556:
/***/ (function(module, exports) {

// Unique ID creation requires a high quality random # generator.  In the
// browser this is a little complicated due to unknown quality of Math.random()
// and inconsistent support for the `crypto` API.  We do the best we can via
// feature-detection

// getRandomValues needs to be invoked in a context where "this" is a Crypto
// implementation. Also, find the complete implementation of crypto on IE11.
var getRandomValues = (typeof(crypto) != 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto)) ||
                      (typeof(msCrypto) != 'undefined' && typeof window.msCrypto.getRandomValues == 'function' && msCrypto.getRandomValues.bind(msCrypto));

if (getRandomValues) {
  // WHATWG crypto RNG - http://wiki.whatwg.org/wiki/Crypto
  var rnds8 = new Uint8Array(16); // eslint-disable-line no-undef

  module.exports = function whatwgRNG() {
    getRandomValues(rnds8);
    return rnds8;
  };
} else {
  // Math.random()-based (RNG)
  //
  // If all else fails, use Math.random().  It's fast, but is of unspecified
  // quality.
  var rnds = new Array(16);

  module.exports = function mathRNG() {
    for (var i = 0, r; i < 16; i++) {
      if ((i & 0x03) === 0) r = Math.random() * 0x100000000;
      rnds[i] = r >>> ((i & 0x03) << 3) & 0xff;
    }

    return rnds;
  };
}


/***/ }),

/***/ 557:
/***/ (function(module, exports) {

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */
var byteToHex = [];
for (var i = 0; i < 256; ++i) {
  byteToHex[i] = (i + 0x100).toString(16).substr(1);
}

function bytesToUuid(buf, offset) {
  var i = offset || 0;
  var bth = byteToHex;
  // join used to fix memory issue caused by concatenation: https://bugs.chromium.org/p/v8/issues/detail?id=3175#c4
  return ([bth[buf[i++]], bth[buf[i++]], 
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]],
	bth[buf[i++]], bth[buf[i++]],
	bth[buf[i++]], bth[buf[i++]]]).join('');
}

module.exports = bytesToUuid;


/***/ }),

/***/ 855:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(856)
/* template */
var __vue_template__ = __webpack_require__(857)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/frontend/block/form.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-76a33b18", Component.options)
  } else {
    hotAPI.reload("data-v-76a33b18", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 856:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _v = __webpack_require__(555);

var _v2 = _interopRequireDefault(_v);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: {},
    data: function data() {
        return {
            blockForm: new Form({
                title: '',
                is_draft: 0,
                menu_id: '',
                url: '',
                body: '',
                featured_image: '',
                upload_token: ''
            }),
            menus: [],
            module_id: '',
            image: '',
            clearAttachment: true
        };
    },

    props: ['uuid'],
    mounted: function mounted() {
        if (!helper.frontendConfigurationAccessible()) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }

        if (this.uuid) this.get();else this.blockForm.upload_token = (0, _v2.default)();

        this.getPreRequisite();
    },

    methods: {
        hasPermission: function hasPermission(permission) {
            return helper.hasPermission(permission);
        },
        getPreRequisite: function getPreRequisite() {
            var _this = this;

            var loader = this.$loading.show();
            axios.get('/api/frontend/block/pre-requisite').then(function (response) {
                _this.menus = response.menus;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        proceed: function proceed() {
            if (this.uuid) this.update();else this.store();
        },
        store: function store() {
            var _this2 = this;

            var loader = this.$loading.show();
            this.blockForm.post('/api/frontend/block').then(function (response) {
                toastr.success(response.message);
                _this2.clearAttachment = !_this2.clearAttachment;
                _this2.blockForm.upload_token = (0, _v2.default)();
                _this2.$emit('completed');
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        get: function get() {
            var _this3 = this;

            var loader = this.$loading.show();
            axios.get('/api/frontend/block/' + this.uuid).then(function (response) {
                _this3.blockForm.title = response.block.title;
                _this3.blockForm.body = response.block.body;
                _this3.blockForm.is_draft = response.block.is_draft;
                _this3.blockForm.menu_id = response.block.frontend_menu_id;
                _this3.blockForm.url = response.block.url;
                _this3.blockForm.featured_image = response.block.featured_image;
                _this3.blockForm.upload_token = response.block.upload_token;
                _this3.module_id = response.block.id;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
                _this3.$router.push('/frontend/block');
            });
        },
        update: function update() {
            var _this4 = this;

            var loader = this.$loading.show();
            this.blockForm.patch('/api/frontend/block/' + this.uuid).then(function (response) {
                toastr.success(response.message);
                loader.hide();
                _this4.$router.push('/frontend/block');
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        updateImage: function updateImage(val) {
            this.blockForm.featured_image = val;
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 857:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c(
      "form",
      {
        on: {
          submit: function($event) {
            $event.preventDefault()
            return _vm.proceed($event)
          },
          keydown: function($event) {
            _vm.blockForm.errors.clear($event.target.name)
          }
        }
      },
      [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c(
              "div",
              { staticClass: "form-group" },
              [
                _c("label", { attrs: { for: "" } }, [
                  _vm._v(_vm._s(_vm.trans("frontend.block_title")))
                ]),
                _vm._v(" "),
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.blockForm.title,
                      expression: "blockForm.title"
                    }
                  ],
                  staticClass: "form-control",
                  attrs: {
                    type: "text",
                    name: "title",
                    placeholder: _vm.trans("frontend.block_title")
                  },
                  domProps: { value: _vm.blockForm.title },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(_vm.blockForm, "title", $event.target.value)
                    }
                  }
                }),
                _vm._v(" "),
                _c("show-error", {
                  attrs: { "form-name": _vm.blockForm, "prop-name": "title" }
                })
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "form-group" },
              [
                _c("label", { attrs: { for: "" } }, [
                  _vm._v(_vm._s(_vm.trans("frontend.menu")))
                ]),
                _vm._v(" "),
                _c(
                  "select",
                  {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.blockForm.menu_id,
                        expression: "blockForm.menu_id"
                      }
                    ],
                    staticClass: "custom-select col-12",
                    attrs: { name: "menu_id" },
                    on: {
                      change: [
                        function($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function(o) {
                              return o.selected
                            })
                            .map(function(o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.$set(
                            _vm.blockForm,
                            "menu_id",
                            $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          )
                        },
                        function($event) {
                          _vm.blockForm.errors.clear("menu_id")
                        }
                      ]
                    }
                  },
                  [
                    _c("option", { attrs: { value: "" } }, [
                      _vm._v(_vm._s(_vm.trans("general.select_one")))
                    ]),
                    _vm._v(" "),
                    _vm._l(_vm.menus, function(menu) {
                      return _c("option", { domProps: { value: menu.value } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(menu.text) +
                            "\n                      "
                        )
                      ])
                    })
                  ],
                  2
                ),
                _vm._v(" "),
                _c("show-error", {
                  attrs: { "form-name": _vm.blockForm, "prop-name": "menu_id" }
                })
              ],
              1
            ),
            _vm._v(" "),
            !_vm.blockForm.menu_id
              ? _c(
                  "div",
                  { staticClass: "form-group" },
                  [
                    _c("label", { attrs: { for: "" } }, [
                      _vm._v(_vm._s(_vm.trans("frontend.block_url")))
                    ]),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.blockForm.url,
                          expression: "blockForm.url"
                        }
                      ],
                      staticClass: "form-control",
                      attrs: {
                        type: "text",
                        name: "url",
                        placeholder: _vm.trans("frontend.block_url")
                      },
                      domProps: { value: _vm.blockForm.url },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.blockForm, "url", $event.target.value)
                        }
                      }
                    }),
                    _vm._v(" "),
                    _c("show-error", {
                      attrs: { "form-name": _vm.blockForm, "prop-name": "url" }
                    })
                  ],
                  1
                )
              : _vm._e(),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c("label", { staticClass: "custom-control custom-checkbox" }, [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.blockForm.is_draft,
                      expression: "blockForm.is_draft"
                    }
                  ],
                  staticClass: "custom-control-input",
                  attrs: { type: "checkbox", value: "1" },
                  domProps: {
                    checked: Array.isArray(_vm.blockForm.is_draft)
                      ? _vm._i(_vm.blockForm.is_draft, "1") > -1
                      : _vm.blockForm.is_draft
                  },
                  on: {
                    change: function($event) {
                      var $$a = _vm.blockForm.is_draft,
                        $$el = $event.target,
                        $$c = $$el.checked ? true : false
                      if (Array.isArray($$a)) {
                        var $$v = "1",
                          $$i = _vm._i($$a, $$v)
                        if ($$el.checked) {
                          $$i < 0 &&
                            _vm.$set(
                              _vm.blockForm,
                              "is_draft",
                              $$a.concat([$$v])
                            )
                        } else {
                          $$i > -1 &&
                            _vm.$set(
                              _vm.blockForm,
                              "is_draft",
                              $$a.slice(0, $$i).concat($$a.slice($$i + 1))
                            )
                        }
                      } else {
                        _vm.$set(_vm.blockForm, "is_draft", $$c)
                      }
                    }
                  }
                }),
                _vm._v(" "),
                _c("span", { staticClass: "custom-control-label" }, [
                  _vm._v(_vm._s(_vm.trans("frontend.block_is_draft")))
                ])
              ])
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c(
              "div",
              { staticClass: "form-group" },
              [
                _c("label", { attrs: { for: "" } }, [
                  _vm._v(_vm._s(_vm.trans("frontend.block_body")))
                ]),
                _vm._v(" "),
                _c("autosize-textarea", {
                  attrs: {
                    rows: "4",
                    name: "body",
                    placeholder: _vm.trans("frontend.block_body")
                  },
                  model: {
                    value: _vm.blockForm.body,
                    callback: function($$v) {
                      _vm.$set(_vm.blockForm, "body", $$v)
                    },
                    expression: "blockForm.body"
                  }
                }),
                _vm._v(" "),
                _c("show-error", {
                  attrs: { "form-name": _vm.blockForm, "prop-name": "body" }
                })
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "form-group" },
              [
                _c("upload-image", {
                  attrs: {
                    id: "block_image",
                    "button-text": _vm.trans("frontend.choose_featured_image"),
                    "upload-path": "/frontend/block/featured/image",
                    "remove-path": "/frontend/block/featured/image",
                    "image-source": _vm.blockForm.featured_image
                  },
                  on: {
                    uploaded: _vm.updateImage,
                    removed: function($event) {
                      _vm.blockForm.featured_image = ""
                    }
                  }
                })
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "card-footer text-right" },
          [
            _c(
              "router-link",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.uuid,
                    expression: "uuid"
                  }
                ],
                staticClass: "btn btn-danger waves-effect waves-light ",
                attrs: { to: "/frontend/block" }
              },
              [_vm._v(_vm._s(_vm.trans("general.cancel")))]
            ),
            _vm._v(" "),
            !_vm.uuid
              ? _c(
                  "button",
                  {
                    staticClass: "btn btn-danger waves-effect waves-light ",
                    attrs: { type: "button" },
                    on: {
                      click: function($event) {
                        _vm.$emit("cancel")
                      }
                    }
                  },
                  [_vm._v(_vm._s(_vm.trans("general.cancel")))]
                )
              : _vm._e(),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-info waves-effect waves-light",
                attrs: { type: "submit" }
              },
              [
                _vm.uuid
                  ? _c("span", [_vm._v(_vm._s(_vm.trans("general.update")))])
                  : _c("span", [_vm._v(_vm._s(_vm.trans("general.save")))])
              ]
            )
          ],
          1
        )
      ]
    )
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-76a33b18", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=edit.js.map