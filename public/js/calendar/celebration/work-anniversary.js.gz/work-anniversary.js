webpackJsonp([304],{

/***/ 1483:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    data: function data() {
        return {
            work_anniversaries: {
                total: 0,
                data: []
            },
            filter: {
                sort_by: 'date',
                order: 'asc',
                start_date: '',
                end_date: '',
                page_length: helper.getConfig('page_length')
            },
            showFilterPanel: false
        };
    },
    mounted: function mounted() {
        if (!helper.hasPermission('list-work-anniversary')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }
        this.getWorkAnniversaries();
        helper.showDemoNotification(['calendar']);
    },
    created: function created() {
        this.filter.start_date = moment().format('YYYY-MM-DD');
        this.filter.end_date = moment().add(1, 'weeks').format('YYYY-MM-DD');
    },

    methods: {
        getConfig: function getConfig(config) {
            return helper.getConfig(config);
        },
        hasPermission: function hasPermission(permission) {
            return helper.hasPermission(permission);
        },
        getEmployeeName: function getEmployeeName(employee) {
            return helper.getEmployeeName(employee);
        },
        getEmployeeCode: function getEmployeeCode(employee) {
            return helper.getEmployeeCode(employee);
        },
        getCount: function getCount(date) {
            return moment().diff(date, 'years');
        },
        getEmployeeDesignationOnDate: function getEmployeeDesignationOnDate(employee) {
            return helper.getEmployeeDesignationOnDate(employee, moment().format('YYYY-MM-DD'));
        },
        getWorkAnniversaries: function getWorkAnniversaries(page) {
            var _this = this;

            var loader = this.$loading.show();
            if (typeof page !== 'number') {
                page = 1;
            }
            var url = helper.getFilterURL(this.filter);
            axios.get('/api/work/anniversary?page=' + page + url).then(function (response) {
                _this.work_anniversaries = response;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        print: function print() {
            var loader = this.$loading.show();
            axios.post('/api/work/anniversary/print', { filter: this.filter }).then(function (response) {
                loader.hide();
                var print = window.open("/print");
                print.document.write(response);
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        pdf: function pdf() {
            var _this2 = this;

            var loader = this.$loading.show();
            axios.post('/api/work/anniversary/pdf', { filter: this.filter }).then(function (response) {
                loader.hide();
                window.open('/download/report/' + response + '?token=' + _this2.authToken);
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        showDate: function showDate(date) {
            return helper.formatDate(date);
        }
    },
    filters: {
        moment: function moment(date) {
            return helper.formatDate(date);
        },
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        }
    },
    watch: {
        'filter.sort_by': function filterSort_by(val) {
            this.getWorkAnniversaries();
        },
        'filter.order': function filterOrder(val) {
            this.getWorkAnniversaries();
        },
        'filter.page_length': function filterPage_length(val) {
            this.getWorkAnniversaries();
        }
    },
    computed: {
        authToken: function authToken() {
            return helper.getAuthToken();
        }
    }
};

/***/ }),

/***/ 1484:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-titles" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("h3", { staticClass: "text-themecolor" }, [
            _vm._v(
              _vm._s(_vm.trans("calendar.work_anniversary")) +
                "\n                    "
            ),
            _vm.work_anniversaries.total
              ? _c("span", { staticClass: "card-subtitle" }, [
                  _c("span", { staticClass: "d-none d-sm-inline" }, [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.total_result_found", {
                          count: _vm.work_anniversaries.total,
                          from: _vm.work_anniversaries.from,
                          to: _vm.work_anniversaries.to
                        })
                      )
                    )
                  ])
                ])
              : _c(
                  "span",
                  { staticClass: "card-subtitle d-none d-sm-inline" },
                  [_vm._v(_vm._s(_vm.trans("general.no_result_found")))]
                )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("div", { staticClass: "action-buttons pull-right" }, [
            !_vm.showFilterPanel
              ? _c(
                  "button",
                  {
                    staticClass: "btn btn-info btn-sm",
                    on: {
                      click: function($event) {
                        _vm.showFilterPanel = !_vm.showFilterPanel
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-filter" }),
                    _vm._v(" "),
                    _c("span", { staticClass: "d-none d-sm-inline" }, [
                      _vm._v(" " + _vm._s(_vm.trans("general.filter")))
                    ])
                  ]
                )
              : _vm._e(),
            _vm._v(" "),
            _c("div", { staticClass: "btn-group" }, [
              _c(
                "button",
                {
                  directives: [
                    {
                      name: "tooltip",
                      rawName: "v-tooltip",
                      value: _vm.trans("general.more_option"),
                      expression: "trans('general.more_option')"
                    }
                  ],
                  staticClass: "btn btn-info btn-sm dropdown-toggle no-caret ",
                  attrs: {
                    type: "button",
                    role: "menu",
                    id: "moreOption",
                    "data-toggle": "dropdown",
                    "aria-haspopup": "true",
                    "aria-expanded": "false"
                  }
                },
                [
                  _c("i", { staticClass: "fas fa-ellipsis-h" }),
                  _vm._v(" "),
                  _c("span", { staticClass: "d-none d-sm-inline" })
                ]
              ),
              _vm._v(" "),
              _c(
                "div",
                {
                  class: [
                    "dropdown-menu",
                    _vm.getConfig("direction") == "ltr"
                      ? "dropdown-menu-right"
                      : ""
                  ],
                  attrs: { "aria-labelledby": "moreOption" }
                },
                [
                  _c(
                    "button",
                    {
                      staticClass: "dropdown-item custom-dropdown",
                      on: { click: _vm.print }
                    },
                    [
                      _c("i", { staticClass: "fas fa-print" }),
                      _vm._v(" " + _vm._s(_vm.trans("general.print")))
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      staticClass: "dropdown-item custom-dropdown",
                      on: { click: _vm.pdf }
                    },
                    [
                      _c("i", { staticClass: "fas fa-file-pdf" }),
                      _vm._v(" " + _vm._s(_vm.trans("general.generate_pdf")))
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      staticClass: "dropdown-item custom-dropdown",
                      on: {
                        click: function($event) {
                          _vm.$router.push("/calendar/celebration/birthday")
                        }
                      }
                    },
                    [
                      _c("i", { staticClass: "fas fa-birthday-cake" }),
                      _vm._v(" " + _vm._s(_vm.trans("calendar.birthday")))
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      staticClass: "dropdown-item custom-dropdown",
                      on: {
                        click: function($event) {
                          _vm.$router.push("/calendar/celebration/anniversary")
                        }
                      }
                    },
                    [
                      _c("i", { staticClass: "fas fa-heartbeat" }),
                      _vm._v(" " + _vm._s(_vm.trans("calendar.anniversary")))
                    ]
                  )
                ]
              )
            ])
          ])
        ])
      ])
    ]),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "container-fluid" },
      [
        _c("transition", { attrs: { name: "fade" } }, [
          _vm.showFilterPanel
            ? _c("div", { staticClass: "card border-left border-bottom" }, [
                _c("div", { staticClass: "card-body p-4" }, [
                  _c("h4", { staticClass: "card-title" }, [
                    _vm._v(
                      _vm._s(_vm.trans("general.filter")) +
                        "\n                        "
                    ),
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-danger btn-sm pull-right",
                        attrs: { type: "button" },
                        on: {
                          click: function($event) {
                            _vm.showFilterPanel = false
                          }
                        }
                      },
                      [_vm._v(_vm._s(_vm.trans("general.cancel")))]
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "row" }, [
                    _c("div", { staticClass: "col-12 col-sm-8" }, [
                      _c(
                        "div",
                        { staticClass: "form-group" },
                        [
                          _c("date-range-picker", {
                            attrs: {
                              "start-date": _vm.filter.start_date,
                              "end-date": _vm.filter.end_date,
                              label: _vm.trans("general.date_between")
                            },
                            on: {
                              "update:startDate": function($event) {
                                _vm.$set(_vm.filter, "start_date", $event)
                              },
                              "update:endDate": function($event) {
                                _vm.$set(_vm.filter, "end_date", $event)
                              }
                            }
                          })
                        ],
                        1
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      staticClass:
                        "btn btn-info waves-effect waves-light pull-right",
                      attrs: { type: "button" },
                      on: { click: _vm.getWorkAnniversaries }
                    },
                    [_vm._v(_vm._s(_vm.trans("general.filter")))]
                  )
                ])
              ])
            : _vm._e()
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "card" }, [
          _c(
            "div",
            { staticClass: "card-body" },
            [
              _vm.filter.start_date && _vm.filter.end_date
                ? _c("h6", { staticClass: "p-3" }, [
                    _vm._v(
                      _vm._s(
                        _vm.trans("calendar.work_anniversary_between", {
                          start_date: _vm.showDate(_vm.filter.start_date),
                          end_date: _vm.showDate(_vm.filter.end_date)
                        })
                      )
                    )
                  ])
                : _vm._e(),
              _vm._v(" "),
              _vm.work_anniversaries.total
                ? _c("div", { staticClass: "table-responsive" }, [
                    _c("table", { staticClass: "table table-sm" }, [
                      _c("thead", [
                        _c("tr", [
                          _c("th", [
                            _vm._v(
                              _vm._s(
                                _vm.trans("employee.date_of_work_anniversary")
                              )
                            )
                          ]),
                          _vm._v(" "),
                          _c("th", [
                            _vm._v(_vm._s(_vm.trans("employee.name")))
                          ]),
                          _vm._v(" "),
                          _c("th", [
                            _vm._v(_vm._s(_vm.trans("employee.code")))
                          ]),
                          _vm._v(" "),
                          _c("th", [
                            _vm._v(_vm._s(_vm.trans("employee.designation")))
                          ]),
                          _vm._v(" "),
                          _c("th", [
                            _vm._v(_vm._s(_vm.trans("employee.contact_number")))
                          ])
                        ])
                      ]),
                      _vm._v(" "),
                      _c(
                        "tbody",
                        _vm._l(_vm.work_anniversaries.data, function(
                          work_anniversary
                        ) {
                          return _c("tr", [
                            _c("td", [
                              _vm._v(
                                _vm._s(
                                  _vm._f("moment")(
                                    work_anniversary.date_of_joining
                                  )
                                ) +
                                  " (" +
                                  _vm._s(
                                    _vm.getCount(
                                      work_anniversary.date_of_joining
                                    ) +
                                      " " +
                                      _vm.trans("general.years")
                                  ) +
                                  ")"
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(
                                _vm._s(
                                  _vm.getEmployeeName(work_anniversary.employee)
                                )
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(
                                _vm._s(
                                  _vm.getEmployeeCode(work_anniversary.employee)
                                )
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(
                                _vm._s(
                                  _vm.getEmployeeDesignationOnDate(
                                    work_anniversary.employee
                                  )
                                )
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(
                                _vm._s(work_anniversary.employee.contact_number)
                              )
                            ])
                          ])
                        })
                      )
                    ])
                  ])
                : _vm._e(),
              _vm._v(" "),
              !_vm.work_anniversaries.total
                ? _c("module-info", {
                    attrs: {
                      module: "calendar",
                      title: "work_anniversary_module_title",
                      description: "work_anniversary_module_description",
                      icon: "list"
                    }
                  })
                : _vm._e(),
              _vm._v(" "),
              _c("pagination-record", {
                attrs: {
                  "page-length": _vm.filter.page_length,
                  records: _vm.work_anniversaries
                },
                on: {
                  "update:pageLength": function($event) {
                    _vm.$set(_vm.filter, "page_length", $event)
                  },
                  updateRecords: _vm.getWorkAnniversaries
                }
              })
            ],
            1
          )
        ])
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-4edd93ca", module.exports)
  }
}

/***/ }),

/***/ 430:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1483)
/* template */
var __vue_template__ = __webpack_require__(1484)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/calendar/celebration/work-anniversary.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-4edd93ca", Component.options)
  } else {
    hotAPI.reload("data-v-4edd93ca", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ })

});
//# sourceMappingURL=work-anniversary.js.map