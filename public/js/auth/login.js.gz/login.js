webpackJsonp([7],{

/***/ 1001:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _guestFooter = __webpack_require__(576);

var _guestFooter2 = _interopRequireDefault(_guestFooter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    data: function data() {
        return {
            loginForm: new Form({
                email_or_username: '',
                password: ''
            })
        };
    },

    components: {
        guestFooter: _guestFooter2.default
    },
    mounted: function mounted() {
        helper.showDemoNotification(['login', 'login_with_different_role']);
    },

    methods: {
        submit: function submit() {
            var _this = this;

            var loader = this.$loading.show();
            this.loginForm.post('/api/auth/login').then(function (response) {
                _this.$cookie.set('auth_token', response.token, 1);
                axios.defaults.headers.common['Authorization'] = 'Bearer ' + response.token;
                _this.$store.dispatch('setConfig', response.config);
                _this.$store.dispatch('setAuthUserDetail', {
                    id: response.user.id,
                    email: response.user.email,
                    username: response.user.username,
                    roles: response.user.user_roles,
                    permissions: response.user.user_permissions,
                    two_factor_code: response.user.two_factor_code,
                    color_theme: response.user.user_preference.color_theme || _this.getConfig('color_theme'),
                    locale: response.user.user_preference.locale || _this.getConfig('locale'),
                    direction: response.user.user_preference.direction || _this.getConfig('direction'),
                    sidebar: response.user.user_preference.sidebar || _this.getConfig('sidebar')
                });
                _this.$store.dispatch('setAcademicSession', response.academic_sessions);
                _this.$store.dispatch('setDefaultAcademicSession', response.default_academic_session);

                toastr.success(response.message);

                if (helper.getConfig('two_factor_security') && response.user.two_factor_code) {
                    _this.$router.push('/auth/security');
                } else {
                    var redirect_path = response.reload ? '/dashboard?reload=1' : '/dashboard';

                    var role = response.user.roles.find(function (o) {
                        return o.name == 'admin';
                    });
                    if (role && helper.getConfig('setup_wizard')) redirect_path = '/setup';

                    _this.$store.dispatch('resetTwoFactorCode');
                    _this.$router.push(redirect_path);
                }
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        loginAs: function loginAs(role) {
            this.loginForm.email_or_username = role + '@' + role + '.com';
            this.loginForm.password = 'password';
            this.submit();
        },
        getConfig: function getConfig(config) {
            return helper.getConfig(config);
        }
    },
    computed: {
        getLogo: function getLogo() {
            return helper.getLogo();
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1002:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("section", { attrs: { id: "wrapper" } }, [
    _c("div", { staticClass: "login-register guest-page" }, [
      _c(
        "div",
        { staticClass: "login-box card guest-box" },
        [
          _c("div", { staticClass: "card-body p-4" }, [
            _c("img", { staticClass: "org-logo", attrs: { src: _vm.getLogo } }),
            _vm._v(" "),
            _c(
              "form",
              {
                staticClass: "form-horizontal form-material",
                attrs: { id: "loginform" },
                on: {
                  submit: function($event) {
                    $event.preventDefault()
                    return _vm.submit($event)
                  },
                  keydown: function($event) {
                    _vm.loginForm.errors.clear($event.target.name)
                  }
                }
              },
              [
                _c("h3", { staticClass: "box-title m-t-20 m-b-10" }, [
                  _vm._v(_vm._s(_vm.trans("auth.login")))
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "form-group " },
                  [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.loginForm.email_or_username,
                          expression: "loginForm.email_or_username"
                        }
                      ],
                      staticClass: "form-control",
                      attrs: {
                        type: "text",
                        name: "email_or_username",
                        placeholder: _vm.trans("auth.email_or_username")
                      },
                      domProps: { value: _vm.loginForm.email_or_username },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.loginForm,
                            "email_or_username",
                            $event.target.value
                          )
                        }
                      }
                    }),
                    _vm._v(" "),
                    _c("show-error", {
                      attrs: {
                        "form-name": _vm.loginForm,
                        "prop-name": "email_or_username"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "form-group" },
                  [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.loginForm.password,
                          expression: "loginForm.password"
                        }
                      ],
                      staticClass: "form-control",
                      attrs: {
                        type: "password",
                        name: "password",
                        placeholder: _vm.trans("auth.password")
                      },
                      domProps: { value: _vm.loginForm.password },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.loginForm,
                            "password",
                            $event.target.value
                          )
                        }
                      }
                    }),
                    _vm._v(" "),
                    _c("show-error", {
                      attrs: {
                        "form-name": _vm.loginForm,
                        "prop-name": "password"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _vm.getConfig("recaptcha") && _vm.getConfig("login_recaptcha")
                  ? _c("div", {
                      staticClass: "g-recaptcha",
                      attrs: { "data-sitekey": _vm.getConfig("recaptcha_key") }
                    })
                  : _vm._e(),
                _vm._v(" "),
                _c("div", { staticClass: "form-group text-center m-t-20" }, [
                  _c(
                    "button",
                    {
                      staticClass:
                        "btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light",
                      attrs: { type: "submit" }
                    },
                    [_vm._v(_vm._s(_vm.trans("auth.sign_in")))]
                  )
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "form-group m-b-0" }, [
                  _c("div", { staticClass: "col-sm-12 text-center" }, [
                    _vm.getConfig("reset_password")
                      ? _c(
                          "p",
                          [
                            _vm._v(
                              _vm._s(_vm.trans("auth.forgot_your_password?")) +
                                " "
                            ),
                            _c(
                              "router-link",
                              {
                                staticClass: "text-info m-l-5",
                                attrs: { to: "/password" }
                              },
                              [
                                _c("b", [
                                  _vm._v(_vm._s(_vm.trans("auth.reset_here!")))
                                ])
                              ]
                            )
                          ],
                          1
                        )
                      : _vm._e()
                  ])
                ]),
                _vm._v(" "),
                !_vm.getConfig("mode")
                  ? _c(
                      "div",
                      { staticClass: "row m-t-10 justify-content-center" },
                      [
                        _c("div", { staticClass: "col-6 text-center" }, [
                          _vm._m(0),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              class: [
                                "dropdown-menu",
                                _vm.getConfig("direction") == "ltr"
                                  ? "dropdown-menu-right"
                                  : ""
                              ],
                              attrs: { "aria-labelledby": "loginAs" }
                            },
                            [
                              _c(
                                "button",
                                {
                                  staticClass: "dropdown-item",
                                  staticStyle: { cursor: "pointer" },
                                  attrs: { type: "button" },
                                  on: {
                                    click: function($event) {
                                      _vm.loginAs("admin")
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    "\n                                    Admin Role\n                                "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "button",
                                {
                                  staticClass: "dropdown-item",
                                  staticStyle: { cursor: "pointer" },
                                  attrs: { type: "button" },
                                  on: {
                                    click: function($event) {
                                      _vm.loginAs("manager")
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    "\n                                    Manager Role\n                                "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "button",
                                {
                                  staticClass: "dropdown-item",
                                  staticStyle: { cursor: "pointer" },
                                  attrs: { type: "button" },
                                  on: {
                                    click: function($event) {
                                      _vm.loginAs("principal")
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    "\n                                    Principal Role\n                                "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "button",
                                {
                                  staticClass: "dropdown-item",
                                  staticStyle: { cursor: "pointer" },
                                  attrs: { type: "button" },
                                  on: {
                                    click: function($event) {
                                      _vm.loginAs("staff")
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    "\n                                    Staff Role\n                                "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "button",
                                {
                                  staticClass: "dropdown-item",
                                  staticStyle: { cursor: "pointer" },
                                  attrs: { type: "button" },
                                  on: {
                                    click: function($event) {
                                      _vm.loginAs("accountant")
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    "\n                                    Accountant Role\n                                "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "button",
                                {
                                  staticClass: "dropdown-item",
                                  staticStyle: { cursor: "pointer" },
                                  attrs: { type: "button" },
                                  on: {
                                    click: function($event) {
                                      _vm.loginAs("librarian")
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    "\n                                    Librarian Role\n                                "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "button",
                                {
                                  staticClass: "dropdown-item",
                                  staticStyle: { cursor: "pointer" },
                                  attrs: { type: "button" },
                                  on: {
                                    click: function($event) {
                                      _vm.loginAs("student")
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    "\n                                    Student Role\n                                "
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "button",
                                {
                                  staticClass: "dropdown-item",
                                  staticStyle: { cursor: "pointer" },
                                  attrs: { type: "button" },
                                  on: {
                                    click: function($event) {
                                      _vm.loginAs("parent")
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    "\n                                    Parent Role\n                                "
                                  )
                                ]
                              )
                            ]
                          )
                        ])
                      ]
                    )
                  : _vm._e()
              ]
            )
          ]),
          _vm._v(" "),
          _c("guest-footer")
        ],
        1
      )
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "btn btn-success text-uppercase btn-block dropup",
        attrs: {
          type: "button",
          href: "#",
          role: "button",
          id: "loginAs",
          "data-toggle": "dropdown",
          "aria-haspopup": "true",
          "aria-expanded": "false"
        }
      },
      [
        _vm._v("\n                                Auto Login As "),
        _c("i", { staticClass: "fas fa-chevron-up m-l-5" })
      ]
    )
  }
]
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-6517b581", module.exports)
  }
}

/***/ }),

/***/ 50:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1001)
/* template */
var __vue_template__ = __webpack_require__(1002)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/auth/login.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-6517b581", Component.options)
  } else {
    hotAPI.reload("data-v-6517b581", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 576:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(577)
/* template */
var __vue_template__ = __webpack_require__(578)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/layouts/partials/guest-footer.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-16cd12f9", Component.options)
  } else {
    hotAPI.reload("data-v-16cd12f9", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 577:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});
//
//
//
//
//
//

exports.default = {
	methods: {
		getConfig: function getConfig(config) {
			return helper.getConfig(config);
		}
	}
};

/***/ }),

/***/ 578:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("p", { staticClass: "text-center" }, [
      _c("small", [
        _vm._v(
          _vm._s(_vm.getConfig("footer_credit")) +
            " " +
            _vm._s(_vm.trans("general.version") + " " + _vm.getConfig("v"))
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-16cd12f9", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=login.js.map