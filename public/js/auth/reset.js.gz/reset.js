webpackJsonp([220],{

/***/ 1005:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _guestFooter = __webpack_require__(576);

var _guestFooter2 = _interopRequireDefault(_guestFooter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    data: function data() {
        return {
            resetForm: new Form({
                email: '',
                password: '',
                password_confirmation: '',
                token: this.$route.params.token
            }),
            message: '',
            status: true,
            showMessage: false
        };
    },

    components: {
        guestFooter: _guestFooter2.default
    },
    mounted: function mounted() {
        if (!helper.featureAvailable('reset_password')) {
            helper.featureNotAvailableMsg();
            return this.$router.push('/dashboard');
        }

        this.validate();
    },

    methods: {
        validate: function validate() {
            var _this = this;

            var loader = this.$loading.show();
            axios.post('/api/auth/validate-password-reset', {
                token: this.resetForm.token
            }).then(function (response) {
                _this.showMessage = false;
                loader.hide();
            }).catch(function (error) {
                _this.message = helper.fetchDataErrorMsg(error);
                _this.showMessage = true;
                _this.status = false;
                loader.hide();
            });
        },
        submit: function submit(e) {
            var _this2 = this;

            var loader = this.$loading.show();
            this.resetForm.post('/api/auth/reset').then(function (response) {
                _this2.message = response.message;
                _this2.showMessage = true;
                _this2.status = true;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    },
    computed: {
        getLogo: function getLogo() {
            return helper.getLogo();
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1006:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("section", { attrs: { id: "wrapper" } }, [
    _c("div", { staticClass: "login-register guest-page" }, [
      _c(
        "div",
        { staticClass: "login-box card guest-box" },
        [
          _c("div", { staticClass: "card-body p-4" }, [
            _c("img", {
              staticClass: "mx-auto d-block",
              staticStyle: { "max-width": "250px" },
              attrs: { src: _vm.getLogo }
            }),
            _vm._v(" "),
            _c("h3", { staticClass: "box-title m-t-20 m-b-10" }, [
              _vm._v(_vm._s(_vm.trans("passwords.reset_password")))
            ]),
            _vm._v(" "),
            !_vm.showMessage
              ? _c("div", [
                  _c(
                    "form",
                    {
                      staticClass: "form-horizontal form-material",
                      attrs: { id: "resetform" },
                      on: {
                        submit: function($event) {
                          $event.preventDefault()
                          return _vm.submit($event)
                        },
                        keydown: function($event) {
                          _vm.resetForm.errors.clear($event.target.name)
                        }
                      }
                    },
                    [
                      _c(
                        "div",
                        { staticClass: "form-group " },
                        [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.resetForm.email,
                                expression: "resetForm.email"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "text",
                              name: "email",
                              placeholder: _vm.trans("auth.email")
                            },
                            domProps: { value: _vm.resetForm.email },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.resetForm,
                                  "email",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c("show-error", {
                            attrs: {
                              "form-name": _vm.resetForm,
                              "prop-name": "email"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "form-group" },
                        [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.resetForm.password,
                                expression: "resetForm.password"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "password",
                              name: "password",
                              placeholder: _vm.trans("auth.password")
                            },
                            domProps: { value: _vm.resetForm.password },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.resetForm,
                                  "password",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c("show-error", {
                            attrs: {
                              "form-name": _vm.resetForm,
                              "prop-name": "password"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "form-group" },
                        [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.resetForm.password_confirmation,
                                expression: "resetForm.password_confirmation"
                              }
                            ],
                            staticClass: "form-control",
                            attrs: {
                              type: "password",
                              name: "password",
                              placeholder: _vm.trans("auth.confirm_password")
                            },
                            domProps: {
                              value: _vm.resetForm.password_confirmation
                            },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.resetForm,
                                  "password_confirmation",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c("show-error", {
                            attrs: {
                              "form-name": _vm.resetForm,
                              "prop-name": "password_confirmation"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "form-group text-center m-t-20" },
                        [
                          _c(
                            "button",
                            {
                              staticClass:
                                "btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light",
                              attrs: { type: "submit" }
                            },
                            [
                              _vm._v(
                                _vm._s(_vm.trans("passwords.reset_password"))
                              )
                            ]
                          )
                        ]
                      )
                    ]
                  )
                ])
              : _c("div", { staticClass: "text-center" }, [
                  _vm.status
                    ? _c("h4", {
                        staticClass: "alert alert-success",
                        domProps: { textContent: _vm._s(_vm.message) }
                      })
                    : _c("h4", {
                        staticClass: "alert alert-danger",
                        domProps: { textContent: _vm._s(_vm.message) }
                      })
                ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group m-b-0" }, [
              _c("div", { staticClass: "col-sm-12 text-center" }, [
                _c(
                  "p",
                  [
                    _vm._v(_vm._s(_vm.trans("auth.back_to_login?")) + " "),
                    _c(
                      "router-link",
                      {
                        staticClass: "text-info m-l-5",
                        attrs: { to: "/login" }
                      },
                      [_c("b", [_vm._v(_vm._s(_vm.trans("auth.sign_in")))])]
                    )
                  ],
                  1
                )
              ])
            ])
          ]),
          _vm._v(" "),
          _c("guest-footer")
        ],
        1
      )
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-44328067", module.exports)
  }
}

/***/ }),

/***/ 262:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1005)
/* template */
var __vue_template__ = __webpack_require__(1006)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/auth/reset.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-44328067", Component.options)
  } else {
    hotAPI.reload("data-v-44328067", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 576:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(577)
/* template */
var __vue_template__ = __webpack_require__(578)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/layouts/partials/guest-footer.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-16cd12f9", Component.options)
  } else {
    hotAPI.reload("data-v-16cd12f9", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 577:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});
//
//
//
//
//
//

exports.default = {
	methods: {
		getConfig: function getConfig(config) {
			return helper.getConfig(config);
		}
	}
};

/***/ }),

/***/ 578:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("p", { staticClass: "text-center" }, [
      _c("small", [
        _vm._v(
          _vm._s(_vm.getConfig("footer_credit")) +
            " " +
            _vm._s(_vm.trans("general.version") + " " + _vm.getConfig("v"))
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-16cd12f9", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=reset.js.map