webpackJsonp([219],{

/***/ 1879:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _guestFooter = __webpack_require__(576);

var _guestFooter2 = _interopRequireDefault(_guestFooter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: { guestFooter: _guestFooter2.default },
    data: function data() {
        return {
            twoFactorForm: new Form({
                two_factor_code: ''
            })
        };
    },
    mounted: function mounted() {
        if (!helper.getConfig('two_factor_security') || !helper.getAuthUser('two_factor_code')) this.$router.push('/dashboard');

        if (!helper.getConfig('mode')) this.twoFactorForm.two_factor_code = helper.getAuthUser('two_factor_code');
    },

    methods: {
        logout: function logout() {
            var _this = this;

            helper.logout().then(function () {
                _this.$store.dispatch('resetAuthUserDetail');
                _this.$router.push('/login');
            });
        },
        submit: function submit() {
            var loader = this.$loading.show();
            if (this.twoFactorForm.two_factor_code == helper.getAuthUser('two_factor_code')) {
                this.$store.dispatch('resetTwoFactorCode');
                toastr.success(i18n.auth.two_factor_security_verified);
                loader.hide();

                var redirect_path = '/dashboard';
                if (helper.hasRole('admin') && helper.getConfig('setup_wizard')) redirect_path = '/setup';

                this.$router.push(redirect_path);
            } else {
                toastr.error(i18n.auth.invalid_two_factor_code);
                loader.hide();
            }
        },
        getAuthUser: function getAuthUser(name) {
            return helper.getAuthUser(name);
        }
    },
    computed: {
        getLogo: function getLogo() {
            return helper.getLogo();
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1880:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("section", { attrs: { id: "wrapper" } }, [
    _c("div", { staticClass: "login-register guest-page" }, [
      _c(
        "div",
        { staticClass: "login-box card guest-box" },
        [
          _c(
            "div",
            { staticClass: "card-body p-4" },
            [
              _c("img", {
                staticClass: "mx-auto d-block",
                staticStyle: { "max-width": "250px" },
                attrs: { src: _vm.getLogo }
              }),
              _vm._v(" "),
              _c("center", { staticClass: "m-t-30" }, [
                _c("h4", { staticClass: "card-title m-t-10" }, [
                  _vm._v(_vm._s(_vm.getAuthUser("full_name")))
                ])
              ]),
              _vm._v(" "),
              _c(
                "form",
                {
                  staticClass: "form-horizontal form-material",
                  attrs: { id: "twoFactorForm" },
                  on: {
                    submit: function($event) {
                      $event.preventDefault()
                      return _vm.submit($event)
                    },
                    keydown: function($event) {
                      _vm.twoFactorForm.errors.clear($event.target.name)
                    }
                  }
                },
                [
                  _c("h3", { staticClass: "box-title m-b-20 text-center" }, [
                    _vm._v(_vm._s(_vm.trans("auth.two_factor_security")))
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "form-group " },
                    [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.twoFactorForm.two_factor_code,
                            expression: "twoFactorForm.two_factor_code"
                          }
                        ],
                        staticClass: "form-control text-center",
                        attrs: {
                          type: "text",
                          name: "two_factor_code",
                          placeholder: _vm.trans("auth.two_factor_code")
                        },
                        domProps: { value: _vm.twoFactorForm.two_factor_code },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.twoFactorForm,
                              "two_factor_code",
                              $event.target.value
                            )
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.twoFactorForm,
                          "prop-name": "two_factor_code"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group text-center m-t-20" }, [
                    _c("div", { staticClass: "col-xs-12" }, [
                      _c(
                        "button",
                        {
                          staticClass:
                            "btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light",
                          attrs: { type: "submit" }
                        },
                        [_vm._v(_vm._s(_vm.trans("auth.confirm")))]
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group m-b-0" }, [
                    _c("div", { staticClass: "col-sm-12 text-center" }, [
                      _c("p", [
                        _c(
                          "a",
                          {
                            attrs: { href: "#" },
                            on: {
                              click: function($event) {
                                $event.preventDefault()
                                return _vm.logout($event)
                              }
                            }
                          },
                          [
                            _c("i", { staticClass: "fas fa-power-off" }),
                            _vm._v(" " + _vm._s(_vm.trans("auth.logout")))
                          ]
                        )
                      ])
                    ])
                  ])
                ]
              )
            ],
            1
          ),
          _vm._v(" "),
          _c("guest-footer")
        ],
        1
      )
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-d35acc50", module.exports)
  }
}

/***/ }),

/***/ 544:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1879)
/* template */
var __vue_template__ = __webpack_require__(1880)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/auth/security.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-d35acc50", Component.options)
  } else {
    hotAPI.reload("data-v-d35acc50", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 576:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(577)
/* template */
var __vue_template__ = __webpack_require__(578)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/layouts/partials/guest-footer.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-16cd12f9", Component.options)
  } else {
    hotAPI.reload("data-v-16cd12f9", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 577:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});
//
//
//
//
//
//

exports.default = {
	methods: {
		getConfig: function getConfig(config) {
			return helper.getConfig(config);
		}
	}
};

/***/ }),

/***/ 578:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("p", { staticClass: "text-center" }, [
      _c("small", [
        _vm._v(
          _vm._s(_vm.getConfig("footer_credit")) +
            " " +
            _vm._s(_vm.trans("general.version") + " " + _vm.getConfig("v"))
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-16cd12f9", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=security.js.map