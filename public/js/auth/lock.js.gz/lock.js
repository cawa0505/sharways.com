webpackJsonp([222],{

/***/ 1881:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _guestFooter = __webpack_require__(576);

var _guestFooter2 = _interopRequireDefault(_guestFooter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: { guestFooter: _guestFooter2.default },
    data: function data() {
        return {
            lockScreenForm: new Form({
                password: ''
            })
        };
    },
    mounted: function mounted() {
        if (!helper.getConfig('lock_screen') || !helper.isScreenLocked()) this.$router.push('/dashboard');

        if (!helper.getConfig('mode')) this.lockScreenForm.password = 'abcd1234';
    },

    methods: {
        logout: function logout() {
            var _this = this;

            helper.logout().then(function () {
                _this.$router.push('/login');
            });
        },
        submit: function submit() {
            var _this2 = this;

            var loader = this.$loading.show();
            this.lockScreenForm.post('/api/auth/lock').then(function (response) {
                _this2.$store.dispatch('setLastActivity');
                toastr.success(response.message);
                loader.hide();
                _this2.$router.push('/dashboard');
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getAuthUser: function getAuthUser(name) {
            return helper.getAuthUser(name);
        }
    },
    computed: {
        getLogo: function getLogo() {
            return helper.getLogo();
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1882:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("section", { attrs: { id: "wrapper" } }, [
    _c("div", { staticClass: "login-register guest-page" }, [
      _c(
        "div",
        { staticClass: "login-box card guest-box" },
        [
          _c(
            "div",
            { staticClass: "card-body p-4" },
            [
              _c("img", {
                staticClass: "mx-auto d-block",
                staticStyle: { "max-width": "250px" },
                attrs: { src: _vm.getLogo }
              }),
              _vm._v(" "),
              _c("center", { staticClass: "m-t-30" }, [
                _c("h4", { staticClass: "card-title m-t-10" }, [
                  _vm._v(_vm._s(_vm.getAuthUser("full_name")))
                ])
              ]),
              _vm._v(" "),
              _c(
                "form",
                {
                  staticClass: "form-horizontal form-material",
                  attrs: { id: "lockScreenForm" },
                  on: {
                    submit: function($event) {
                      $event.preventDefault()
                      return _vm.submit($event)
                    },
                    keydown: function($event) {
                      _vm.lockScreenForm.errors.clear($event.target.name)
                    }
                  }
                },
                [
                  _c("h3", { staticClass: "box-title m-b-20 text-center" }, [
                    _vm._v(_vm._s(_vm.trans("auth.password")))
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "form-group " },
                    [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.lockScreenForm.password,
                            expression: "lockScreenForm.password"
                          }
                        ],
                        staticClass: "form-control text-center",
                        attrs: {
                          type: "password",
                          name: "password",
                          placeholder: _vm.trans("auth.password")
                        },
                        domProps: { value: _vm.lockScreenForm.password },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.lockScreenForm,
                              "password",
                              $event.target.value
                            )
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.lockScreenForm,
                          "prop-name": "password"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group text-center m-t-20" }, [
                    _c(
                      "button",
                      {
                        staticClass:
                          "btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light",
                        attrs: { type: "submit" }
                      },
                      [_vm._v(_vm._s(_vm.trans("auth.confirm")))]
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "form-group m-b-0" }, [
                    _c("div", { staticClass: "col-sm-12 text-center" }, [
                      _c("p", [
                        _c(
                          "a",
                          {
                            attrs: { href: "#" },
                            on: {
                              click: function($event) {
                                $event.preventDefault()
                                return _vm.logout($event)
                              }
                            }
                          },
                          [
                            _c("i", { staticClass: "fas fa-power-off" }),
                            _vm._v(" " + _vm._s(_vm.trans("auth.logout")))
                          ]
                        )
                      ])
                    ])
                  ])
                ]
              )
            ],
            1
          ),
          _vm._v(" "),
          _c("guest-footer")
        ],
        1
      )
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-2dfbfa43", module.exports)
  }
}

/***/ }),

/***/ 545:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1881)
/* template */
var __vue_template__ = __webpack_require__(1882)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/auth/lock.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-2dfbfa43", Component.options)
  } else {
    hotAPI.reload("data-v-2dfbfa43", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 576:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(577)
/* template */
var __vue_template__ = __webpack_require__(578)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/layouts/partials/guest-footer.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-16cd12f9", Component.options)
  } else {
    hotAPI.reload("data-v-16cd12f9", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 577:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});
//
//
//
//
//
//

exports.default = {
	methods: {
		getConfig: function getConfig(config) {
			return helper.getConfig(config);
		}
	}
};

/***/ }),

/***/ 578:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("p", { staticClass: "text-center" }, [
      _c("small", [
        _vm._v(
          _vm._s(_vm.getConfig("footer_credit")) +
            " " +
            _vm._s(_vm.trans("general.version") + " " + _vm.getConfig("v"))
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-16cd12f9", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=lock.js.map