webpackJsonp([224],{

/***/ 253:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(967)
}
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(969)
/* template */
var __vue_template__ = __webpack_require__(970)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/pages/themes/default/contact.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-1e662337", Component.options)
  } else {
    hotAPI.reload("data-v-1e662337", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 967:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(968);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(14)("20a053bd", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-1e662337\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../../node_modules/sass-loader/lib/loader.js!../../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./contact.vue", function() {
     var newContent = require("!!../../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-1e662337\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../../node_modules/sass-loader/lib/loader.js!../../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./contact.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 968:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(8)(true);
// imports


// module
exports.push([module.i, "\n.contact-info-box .comma:before {\n  content: \", \";\n}\n", "", {"version":3,"sources":["D:/Projects/jacob/resources/js/views/pages/themes/default/contact.vue"],"names":[],"mappings":";AAAA;EACE,cAAc;CAAE","file":"contact.vue","sourcesContent":[".contact-info-box .comma:before {\n  content: \", \"; }\n"],"sourceRoot":""}]);

// exports


/***/ }),

/***/ 969:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    data: function data() {
        return {
            page: {},
            contactForm: new Form({
                name: '',
                email: '',
                contact_number: '',
                subject: '',
                message: ''
            })
        };
    },
    mounted: function mounted() {
        this.getData();
    },

    methods: {
        getData: function getData() {
            var _this = this;

            var loader = this.$loading.show();
            axios.get('/api/frontend/page/contact/content').then(function (response) {
                _this.page = response.page;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);

                if (error.response.status == 422) _this.$router.push('/');
            });
        },
        getConfig: function getConfig(config) {
            return helper.getConfig(config);
        },
        submit: function submit() {
            var loader = this.$loading.show();
            this.contactForm.post('/api/frontend/contact').then(function (response) {
                toastr.success(response.message);
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    },
    filters: {
        moment: function moment(date) {
            return helper.formatDate(date);
        },
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        }
    }
};

/***/ }),

/***/ 970:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-title" }, [
      _c("div", { staticClass: "fix-width fix-width-mobile" }, [
        _c("h2", [_vm._v(_vm._s(_vm.page.title))])
      ])
    ]),
    _vm._v(" "),
    _vm.page.body
      ? _c("div", { staticClass: "fix-width fix-width-mobile p-t-80" }, [
          _c("div", {
            staticClass: "page-body",
            domProps: { innerHTML: _vm._s(_vm.page.body) }
          })
        ])
      : _vm._e(),
    _vm._v(" "),
    _c("div", { staticClass: "fix-width fix-width-mobile p-t-80" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-md-7" }, [
          _c(
            "form",
            {
              on: {
                submit: function($event) {
                  $event.preventDefault()
                  return _vm.submit($event)
                },
                keydown: function($event) {
                  _vm.contactForm.errors.clear($event.target.name)
                }
              }
            },
            [
              _c(
                "div",
                { staticClass: "form-group" },
                [
                  _c("label", { attrs: { for: "" } }, [
                    _vm._v(_vm._s(_vm.trans("frontend.contact_name")))
                  ]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.contactForm.name,
                        expression: "contactForm.name"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "name",
                      placeholder: _vm.trans("frontend.contact_name")
                    },
                    domProps: { value: _vm.contactForm.name },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.contactForm, "name", $event.target.value)
                      }
                    }
                  }),
                  _vm._v(" "),
                  _c("show-error", {
                    attrs: { "form-name": _vm.contactForm, "prop-name": "name" }
                  })
                ],
                1
              ),
              _vm._v(" "),
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-12 div col-lg-6" }, [
                  _c(
                    "div",
                    { staticClass: "form-group" },
                    [
                      _c("label", { attrs: { for: "" } }, [
                        _vm._v(_vm._s(_vm.trans("frontend.contact_email")))
                      ]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.contactForm.email,
                            expression: "contactForm.email"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "email",
                          placeholder: _vm.trans("frontend.contact_email")
                        },
                        domProps: { value: _vm.contactForm.email },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.contactForm,
                              "email",
                              $event.target.value
                            )
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.contactForm,
                          "prop-name": "email"
                        }
                      })
                    ],
                    1
                  )
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-12 div col-lg-6" }, [
                  _c(
                    "div",
                    { staticClass: "form-group" },
                    [
                      _c("label", { attrs: { for: "" } }, [
                        _vm._v(_vm._s(_vm.trans("frontend.contact_number")))
                      ]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.contactForm.contact_number,
                            expression: "contactForm.contact_number"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          name: "contact_number",
                          placeholder: _vm.trans("frontend.contact_number")
                        },
                        domProps: { value: _vm.contactForm.contact_number },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.contactForm,
                              "contact_number",
                              $event.target.value
                            )
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("show-error", {
                        attrs: {
                          "form-name": _vm.contactForm,
                          "prop-name": "contact_number"
                        }
                      })
                    ],
                    1
                  )
                ])
              ]),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "form-group" },
                [
                  _c("label", { attrs: { for: "" } }, [
                    _vm._v(_vm._s(_vm.trans("frontend.contact_subject")))
                  ]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.contactForm.subject,
                        expression: "contactForm.subject"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: {
                      type: "text",
                      name: "subject",
                      placeholder: _vm.trans("frontend.contact_subject")
                    },
                    domProps: { value: _vm.contactForm.subject },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(
                          _vm.contactForm,
                          "subject",
                          $event.target.value
                        )
                      }
                    }
                  }),
                  _vm._v(" "),
                  _c("show-error", {
                    attrs: {
                      "form-name": _vm.contactForm,
                      "prop-name": "subject"
                    }
                  })
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "form-group" },
                [
                  _c("label", { attrs: { for: "" } }, [
                    _vm._v(_vm._s(_vm.trans("frontend.contact_message")))
                  ]),
                  _vm._v(" "),
                  _c("autosize-textarea", {
                    staticClass: "form-control",
                    attrs: {
                      rows: "5",
                      placeholder: _vm.trans("frontend.contact_message"),
                      name: "message"
                    },
                    model: {
                      value: _vm.contactForm.message,
                      callback: function($$v) {
                        _vm.$set(_vm.contactForm, "message", $$v)
                      },
                      expression: "contactForm.message"
                    }
                  }),
                  _vm._v(" "),
                  _c("show-error", {
                    attrs: {
                      "form-name": _vm.contactForm,
                      "prop-name": "message"
                    }
                  })
                ],
                1
              ),
              _vm._v(" "),
              _c("div", { staticClass: "form-group" }, [
                _c(
                  "button",
                  {
                    staticClass:
                      "btn btn-info btn-lg waves-effect waves-light m-t-10",
                    attrs: { type: "submit" }
                  },
                  [_vm._v(_vm._s(_vm.trans("general.submit")))]
                )
              ])
            ]
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-md-1" }),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-md-4" }, [
          _c("h3", { staticClass: "m-b-20 p-b-20 border-bottom" }, [
            _vm._v(
              " " + _vm._s(_vm.trans("configuration.contact_information")) + " "
            )
          ]),
          _vm._v(" "),
          _c("h4", { staticClass: "m-b-10" }, [
            _vm._v(" " + _vm._s(_vm.getConfig("institute_name")) + " ")
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "contact-info-box" }, [
            _c("p", [
              _c("i", { staticClass: "fas fa-map-marker-alt m-r-5" }),
              _vm._v(" "),
              _c("span", [_vm._v(_vm._s(_vm.getConfig("address_line_1")))]),
              _vm._v(" "),
              _vm.getConfig("address_line_2")
                ? _c("span", { staticClass: "comma" }, [
                    _vm._v(_vm._s(_vm.getConfig("address_line_2")))
                  ])
                : _vm._e(),
              _vm._v(" "),
              _vm.getConfig("city")
                ? _c("span", { staticClass: "comma" }, [
                    _vm._v(_vm._s(_vm.getConfig("city")))
                  ])
                : _vm._e(),
              _vm._v(" "),
              _vm.getConfig("state")
                ? _c("span", { staticClass: "comma" }, [
                    _vm._v(_vm._s(_vm.getConfig("state")))
                  ])
                : _vm._e(),
              _vm._v(" "),
              _vm.getConfig("zipcode")
                ? _c("span", { staticClass: "comma" }, [
                    _vm._v(_vm._s(_vm.getConfig("zipcode")))
                  ])
                : _vm._e(),
              _vm._v(" "),
              _vm.getConfig("country")
                ? _c("span", { staticClass: "d-block" }, [
                    _vm._v(_vm._s(_vm.getConfig("country")))
                  ])
                : _vm._e()
            ]),
            _vm._v(" "),
            _c("p", [
              _c("i", { staticClass: "fas fa-phone m-r-5" }),
              _vm._v(
                "\n                        " +
                  _vm._s(_vm.getConfig("phone")) +
                  "\n                    "
              )
            ]),
            _vm._v(" "),
            _c("p", [
              _c("i", { staticClass: "fas fa-envelope m-r-5" }),
              _vm._v(
                "\n                        " +
                  _vm._s(_vm.getConfig("email")) +
                  "\n                    "
              )
            ]),
            _vm._v(" "),
            _c("p", [
              _c("i", { staticClass: "fas fa-globe m-r-5" }),
              _vm._v(
                "\n                        " +
                  _vm._s(_vm.getConfig("website")) +
                  "\n                    "
              )
            ])
          ])
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-1e662337", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=contact.js.map