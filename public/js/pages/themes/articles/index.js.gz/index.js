webpackJsonp([113],{

/***/ 258:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(993)
/* template */
var __vue_template__ = __webpack_require__(994)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/pages/themes/default/articles/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-181837b9", Component.options)
  } else {
    hotAPI.reload("data-v-181837b9", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 693:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(694)
}
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(696)
/* template */
var __vue_template__ = __webpack_require__(697)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-485d96e5"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/widgets/article-card.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-485d96e5", Component.options)
  } else {
    hotAPI.reload("data-v-485d96e5", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 694:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(695);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(14)("f9ed0e9e", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js?sourceMap!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-485d96e5\",\"scoped\":true,\"hasInlineConfig\":true}!../../../node_modules/sass-loader/lib/loader.js!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./article-card.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js?sourceMap!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-485d96e5\",\"scoped\":true,\"hasInlineConfig\":true}!../../../node_modules/sass-loader/lib/loader.js!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./article-card.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 695:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(8)(true);
// imports


// module
exports.push([module.i, "\n.card.article-card[data-v-485d96e5] {\n  opacity: 0.9;\n  -webkit-transition: all 0.3s ease-in-out;\n  transition: all 0.3s ease-in-out;\n  cursor: pointer;\n}\n.card.article-card header[data-v-485d96e5] {\n    margin-bottom: 0.75rem;\n    padding-bottom: 0.75rem;\n    border-bottom: 1px dotted #f1f2f3;\n}\n.card.article-card header .h5[data-v-485d96e5] {\n      margin-bottom: 0.75rem;\n      display: block;\n}\n.card.article-card header .article-meta small + small[data-v-485d96e5] {\n      margin-left: 0.5rem;\n}\n.card.article-card .article-content[data-v-485d96e5] {\n    font-size: 95%;\n    margin-bottom: 1rem;\n}\n.card.article-card footer[data-v-485d96e5] {\n    margin-top: 0.75rem;\n    padding-top: 0.75rem;\n    border-top: 1px dotted #f1f2f3;\n}\n.card.article-card footer .article-author .author-thumb[data-v-485d96e5] {\n      float: left;\n      width: 50px;\n      height: 50px;\n      border-radius: 50%;\n      background: #f1f2f3;\n      margin-right: 10px;\n      text-align: center;\n}\n.card.article-card footer .article-author .author-thumb i[data-v-485d96e5] {\n        padding-top: 15px;\n}\n.card.article-card footer .article-author .author-thumb img[data-v-485d96e5] {\n        width: 100%;\n}\n.card.article-card footer .article-author p[data-v-485d96e5] {\n      margin-bottom: 0;\n}\n.card.article-card footer .article-author p span[data-v-485d96e5] {\n        display: block;\n}\n.card.article-card footer .article-author p span.author[data-v-485d96e5] {\n          font-weight: 500;\n}\n.card.article-card footer .cta[data-v-485d96e5] {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: end;\n          -ms-flex-pack: end;\n              justify-content: flex-end;\n      -webkit-box-align: end;\n          -ms-flex-align: end;\n              align-items: flex-end;\n      height: 50px;\n}\n", "", {"version":3,"sources":["D:/Projects/jacob/resources/js/widgets/article-card.vue"],"names":[],"mappings":";AAAA;EACE,aAAa;EACb,yCAAiC;EAAjC,iCAAiC;EACjC,gBAAgB;CAAE;AAClB;IACE,uBAAuB;IACvB,wBAAwB;IACxB,kCAAkC;CAAE;AACpC;MACE,uBAAuB;MACvB,eAAe;CAAE;AACnB;MACE,oBAAoB;CAAE;AAC1B;IACE,eAAe;IACf,oBAAoB;CAAE;AACxB;IACE,oBAAoB;IACpB,qBAAqB;IACrB,+BAA+B;CAAE;AACjC;MACE,YAAY;MACZ,YAAY;MACZ,aAAa;MACb,mBAAmB;MACnB,oBAAoB;MACpB,mBAAmB;MACnB,mBAAmB;CAAE;AACrB;QACE,kBAAkB;CAAE;AACtB;QACE,YAAY;CAAE;AAClB;MACE,iBAAiB;CAAE;AACnB;QACE,eAAe;CAAE;AACjB;UACE,iBAAiB;CAAE;AACzB;MACE,qBAAc;MAAd,qBAAc;MAAd,cAAc;MACd,sBAA0B;UAA1B,mBAA0B;cAA1B,0BAA0B;MAC1B,uBAAsB;UAAtB,oBAAsB;cAAtB,sBAAsB;MACtB,aAAa;CAAE","file":"article-card.vue","sourcesContent":[".card.article-card {\n  opacity: 0.9;\n  transition: all 0.3s ease-in-out;\n  cursor: pointer; }\n  .card.article-card header {\n    margin-bottom: 0.75rem;\n    padding-bottom: 0.75rem;\n    border-bottom: 1px dotted #f1f2f3; }\n    .card.article-card header .h5 {\n      margin-bottom: 0.75rem;\n      display: block; }\n    .card.article-card header .article-meta small + small {\n      margin-left: 0.5rem; }\n  .card.article-card .article-content {\n    font-size: 95%;\n    margin-bottom: 1rem; }\n  .card.article-card footer {\n    margin-top: 0.75rem;\n    padding-top: 0.75rem;\n    border-top: 1px dotted #f1f2f3; }\n    .card.article-card footer .article-author .author-thumb {\n      float: left;\n      width: 50px;\n      height: 50px;\n      border-radius: 50%;\n      background: #f1f2f3;\n      margin-right: 10px;\n      text-align: center; }\n      .card.article-card footer .article-author .author-thumb i {\n        padding-top: 15px; }\n      .card.article-card footer .article-author .author-thumb img {\n        width: 100%; }\n    .card.article-card footer .article-author p {\n      margin-bottom: 0; }\n      .card.article-card footer .article-author p span {\n        display: block; }\n        .card.article-card footer .article-author p span.author {\n          font-weight: 500; }\n    .card.article-card footer .cta {\n      display: flex;\n      justify-content: flex-end;\n      align-items: flex-end;\n      height: 50px; }\n"],"sourceRoot":""}]);

// exports


/***/ }),

/***/ 696:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    props: {
        article: {
            type: Object,
            default: function _default() {
                return {};
            }
        },
        bodyClass: String
    },
    components: {},
    data: function data() {
        return {};
    },

    methods: {
        getEmployeePhoto: function getEmployeePhoto(employee) {
            return '/' + employee.photo;
        },
        getEmployeeName: function getEmployeeName(employee) {
            return helper.getEmployeeName(employee);
        },
        getEmployeeDesignationOnly: function getEmployeeDesignationOnly(employee) {
            return helper.getEmployeeDesignationOnly(employee);
        },
        getExcerpts: function getExcerpts(content) {
            return helper.getExcerpts(content);
        },
        truncateWords: function truncateWords(text, length, suffix) {
            return helper.truncateWords(text, length, suffix);
        }
    },
    filters: {
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        },
        moment: function moment(date) {
            return helper.formatDate(date);
        },
        momentTime: function momentTime(time) {
            return helper.formatTime(time);
        }
    }
};

/***/ }),

/***/ 697:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "article",
    { staticClass: "card card-box with-shadow article-card" },
    [
      _c("div", { staticClass: "card-body" }, [
        _c("header", [
          _c("h5", { staticClass: "h5 card-title" }, [
            _vm._v(_vm._s(_vm.article.title))
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "article-meta" }, [
            _c("small", { staticClass: "type text-muted" }, [
              _c("i", { staticClass: "fas fa-hashtag" }),
              _vm._v(" " + _vm._s(_vm.article.article_type.name))
            ]),
            _vm._v(" "),
            _c("small", { staticClass: "date text-muted" }, [
              _c("i", { staticClass: "far fa-clock" }),
              _vm._v(
                " " + _vm._s(_vm._f("moment")(_vm.article.date_of_article))
              )
            ])
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "article-content" }, [
          _c("p", {
            staticClass: "card-text",
            domProps: { innerHTML: _vm._s(_vm.article.excerpt) }
          })
        ]),
        _vm._v(" "),
        _c("footer", [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-8" }, [
              _c("div", { staticClass: "article-author" }, [
                _c(
                  "span",
                  { staticClass: "author-thumb pull-left" },
                  [
                    !_vm.article.user.employee.photo
                      ? [_c("i", { staticClass: "fas fa-user" })]
                      : [
                          _c("img", {
                            staticClass: "img-circle",
                            attrs: {
                              src: _vm.getEmployeePhoto(
                                _vm.article.user.employee
                              )
                            }
                          })
                        ]
                  ],
                  2
                ),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticClass: "author" }, [
                    _vm._v(
                      _vm._s(_vm.getEmployeeName(_vm.article.user.employee))
                    )
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "designation small text-muted" }, [
                    _vm._v(
                      _vm._s(
                        _vm.getEmployeeDesignationOnly(
                          _vm.article.user.employee
                        )
                      )
                    )
                  ])
                ])
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-4" }, [
              _c("div", { staticClass: "cta text-right" }, [
                _c(
                  "button",
                  { staticClass: "btn btn-info", attrs: { type: "button" } },
                  [_vm._v(_vm._s(_vm.trans("general.read_more")))]
                )
              ])
            ])
          ])
        ])
      ])
    ]
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-485d96e5", module.exports)
  }
}

/***/ }),

/***/ 993:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _articleCard = __webpack_require__(693);

var _articleCard2 = _interopRequireDefault(_articleCard);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: {
        ArticleCard: _articleCard2.default
    },
    data: function data() {
        return {
            page: {},
            articles: {
                total: 0,
                data: []
            },
            filter: {
                sort_by: 'date_of_article',
                order: 'desc',
                keyword: '',
                article_type_id: [],
                date_of_article_start_date: '',
                date_of_article_end_date: '',
                page_length: helper.getConfig('page_length')
            },
            orderByOptions: [{
                value: 'date_of_article',
                translation: i18n.post.date_of_article
            }, {
                value: 'title',
                translation: i18n.post.article_title
            }],
            article_types: [],
            selected_article_types: null
        };
    },
    mounted: function mounted() {
        this.getData();
        this.getArticles();

        helper.showDemoNotification(['frontend_article']);
    },

    methods: {
        getData: function getData() {
            var _this = this;

            var loader = this.$loading.show();
            axios.get('/api/frontend/page/articles/content').then(function (response) {
                _this.page = response.page;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);

                if (error.response.status == 422) _this.$router.push('/');
            });
        },
        getArticles: function getArticles(page) {
            var _this2 = this;

            var loader = this.$loading.show();
            if (typeof page !== 'number') {
                page = 1;
            }
            var url = helper.getFilterURL(this.filter);
            axios.get('/api/frontend/article/list?page=' + page + url).then(function (response) {
                _this2.articles = response.articles;
                _this2.article_types = response.article_types;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getConfig: function getConfig(config) {
            return helper.getConfig(config);
        }
    },
    filters: {
        moment: function moment(date) {
            return helper.formatDate(date);
        },
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        }
    },
    watch: {
        'filter.sort_by': function filterSort_by(val) {
            this.getArticles();
        },
        'filter.order': function filterOrder(val) {
            this.getArticles();
        },
        'filter.page_length': function filterPage_length(val) {
            this.getArticles();
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 994:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-title" }, [
      _c("div", { staticClass: "fix-width fix-width-mobile" }, [
        _c("h2", [_vm._v(_vm._s(_vm.page.title))])
      ])
    ]),
    _vm._v(" "),
    _vm.page.body
      ? _c("div", { staticClass: "fix-width fix-width-mobile p-t-80" }, [
          _c("div", {
            staticClass: "page-body",
            domProps: { innerHTML: _vm._s(_vm.page.body) }
          })
        ])
      : _vm._e(),
    _vm._v(" "),
    _c("div", { staticClass: "fix-width fix-width-mobile p-y-80" }, [
      _c("div", { staticClass: "row" }, [
        _c(
          "div",
          { staticClass: "col-12" },
          [
            _vm.articles.total
              ? _c(
                  "div",
                  { staticClass: "article-feed card-columns" },
                  _vm._l(_vm.articles.data, function(article) {
                    return _c(
                      "router-link",
                      {
                        key: article.uuid,
                        staticClass: "article-item",
                        attrs: { to: "/articles/" + article.uuid }
                      },
                      [_c("article-card", { attrs: { article: article } })],
                      1
                    )
                  })
                )
              : _vm._e(),
            _vm._v(" "),
            _c("pagination-record", {
              attrs: {
                "page-length": _vm.filter.page_length,
                records: _vm.articles
              },
              on: {
                "update:pageLength": function($event) {
                  _vm.$set(_vm.filter, "page_length", $event)
                },
                updateRecords: _vm.getArticles
              }
            })
          ],
          1
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-181837b9", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=index.js.map