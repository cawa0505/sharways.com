webpackJsonp([225],{

/***/ 259:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(995)
}
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(997)
/* template */
var __vue_template__ = __webpack_require__(998)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-30224be6"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/pages/themes/default/articles/show.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-30224be6", Component.options)
  } else {
    hotAPI.reload("data-v-30224be6", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 995:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(996);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(14)("5f01baf8", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-30224be6\",\"scoped\":true,\"hasInlineConfig\":true}!../../../../../../../node_modules/sass-loader/lib/loader.js!../../../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./show.vue", function() {
     var newContent = require("!!../../../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-30224be6\",\"scoped\":true,\"hasInlineConfig\":true}!../../../../../../../node_modules/sass-loader/lib/loader.js!../../../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./show.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 996:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(8)(true);
// imports


// module
exports.push([module.i, "\n.page-title[data-v-30224be6] {\n  margin-bottom: 0.75rem;\n}\n.page-title h1[data-v-30224be6] {\n    margin-bottom: 0.75rem;\n    display: block;\n    color: #ffffff;\n}\n.page-title .article-meta[data-v-30224be6] {\n    font-size: 130%;\n}\n.page-title .article-meta small + small[data-v-30224be6] {\n    margin-left: 0.5rem;\n}\n.article-content[data-v-30224be6] {\n  margin-bottom: 1rem;\n  font-size: 110%;\n}\n.article-content p[data-v-30224be6] {\n    text-align: justify;\n}\n.article-content p + p[data-v-30224be6] {\n    margin-top: 1rem;\n}\nfooter[data-v-30224be6] {\n  margin-top: 2.5rem;\n  padding-top: 2.5rem;\n  border-top: 1px dotted #e1e2e3;\n}\nfooter .article-author .author-thumb[data-v-30224be6] {\n    float: left;\n    width: 100px;\n    height: 100px;\n    border-radius: 50%;\n    background: #e1e2e3;\n    margin-right: 20px;\n    text-align: center;\n}\nfooter .article-author .author-thumb i[data-v-30224be6] {\n      padding-top: 25px;\n      font-size: 50px;\n}\nfooter .article-author .author-thumb img[data-v-30224be6] {\n      width: 100%;\n}\nfooter .article-author p[data-v-30224be6] {\n    padding-top: 20px;\n    margin-bottom: 0;\n}\nfooter .article-author p span[data-v-30224be6] {\n      display: block;\n}\nfooter .article-author p span.author[data-v-30224be6] {\n        font-size: 140%;\n        font-weight: 500;\n}\nfooter .article-author p span.designation[data-v-30224be6] {\n        font-size: 100%;\n}\n", "", {"version":3,"sources":["D:/Projects/jacob/resources/js/views/pages/themes/default/articles/show.vue"],"names":[],"mappings":";AAAA;EACE,uBAAuB;CAAE;AACzB;IACE,uBAAuB;IACvB,eAAe;IACf,eAAe;CAAE;AACnB;IACE,gBAAgB;CAAE;AACpB;IACE,oBAAoB;CAAE;AAE1B;EACE,oBAAoB;EACpB,gBAAgB;CAAE;AAClB;IACE,oBAAoB;CAAE;AACxB;IACE,iBAAiB;CAAE;AAEvB;EACE,mBAAmB;EACnB,oBAAoB;EACpB,+BAA+B;CAAE;AACjC;IACE,YAAY;IACZ,aAAa;IACb,cAAc;IACd,mBAAmB;IACnB,oBAAoB;IACpB,mBAAmB;IACnB,mBAAmB;CAAE;AACrB;MACE,kBAAkB;MAClB,gBAAgB;CAAE;AACpB;MACE,YAAY;CAAE;AAClB;IACE,kBAAkB;IAClB,iBAAiB;CAAE;AACnB;MACE,eAAe;CAAE;AACjB;QACE,gBAAgB;QAChB,iBAAiB;CAAE;AACrB;QACE,gBAAgB;CAAE","file":"show.vue","sourcesContent":[".page-title {\n  margin-bottom: 0.75rem; }\n  .page-title h1 {\n    margin-bottom: 0.75rem;\n    display: block;\n    color: #ffffff; }\n  .page-title .article-meta {\n    font-size: 130%; }\n  .page-title .article-meta small + small {\n    margin-left: 0.5rem; }\n\n.article-content {\n  margin-bottom: 1rem;\n  font-size: 110%; }\n  .article-content p {\n    text-align: justify; }\n  .article-content p + p {\n    margin-top: 1rem; }\n\nfooter {\n  margin-top: 2.5rem;\n  padding-top: 2.5rem;\n  border-top: 1px dotted #e1e2e3; }\n  footer .article-author .author-thumb {\n    float: left;\n    width: 100px;\n    height: 100px;\n    border-radius: 50%;\n    background: #e1e2e3;\n    margin-right: 20px;\n    text-align: center; }\n    footer .article-author .author-thumb i {\n      padding-top: 25px;\n      font-size: 50px; }\n    footer .article-author .author-thumb img {\n      width: 100%; }\n  footer .article-author p {\n    padding-top: 20px;\n    margin-bottom: 0; }\n    footer .article-author p span {\n      display: block; }\n      footer .article-author p span.author {\n        font-size: 140%;\n        font-weight: 500; }\n      footer .article-author p span.designation {\n        font-size: 100%; }\n"],"sourceRoot":""}]);

// exports


/***/ }),

/***/ 997:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    mounted: function mounted() {
        this.get();
    },
    data: function data() {
        return {
            uuid: this.$route.params.uuid,
            article: [],
            attachments: []
        };
    },

    methods: {
        get: function get() {
            var _this = this;

            var loader = this.$loading.show();
            var articleUrl = '/api/frontend/article/' + this.uuid + '/detail';
            axios.get(articleUrl).then(function (response) {
                _this.article = response.article;
                _this.attachments = response.attachments;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);

                if (error.response.status == 422) _this.$router.push('/');
            });
        },
        getEmployeeName: function getEmployeeName(employee) {
            return helper.getEmployeeName(employee);
        },
        getEmployeeDesignationOnly: function getEmployeeDesignationOnly(employee) {
            return helper.getEmployeeDesignationOnly(employee);
        },
        getEmployeePhoto: function getEmployeePhoto(employee) {
            return '/' + employee.photo;
        }
    },
    computed: {
        authToken: function authToken() {
            return helper.getAuthToken();
        }
    },
    filters: {
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        },
        moment: function moment(date) {
            return helper.formatDate(date);
        }
    }
};

/***/ }),

/***/ 998:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.article.uuid
    ? _c("div", [
        _c("div", { staticClass: "page-title" }, [
          _c("div", { staticClass: "fix-width fix-width-mobile" }, [
            _c("h1", [_vm._v(_vm._s(_vm.article.title))]),
            _vm._v(" "),
            _c("div", { staticClass: "article-meta" }, [
              _c("small", { staticClass: "type text-muted" }, [
                _c("i", { staticClass: "fas fa-hashtag" }),
                _vm._v(" " + _vm._s(_vm.article.article_type.name))
              ]),
              _vm._v(" "),
              _c("small", { staticClass: "date text-muted" }, [
                _c("i", { staticClass: "far fa-clock" }),
                _vm._v(
                  " " + _vm._s(_vm._f("moment")(_vm.article.date_of_article))
                )
              ])
            ])
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "fix-width fix-width-mobile p-t-80" }, [
          _c("div", {
            staticClass: "page-body article-content",
            domProps: { innerHTML: _vm._s(_vm.article.description) }
          }),
          _vm._v(" "),
          _vm.attachments.length
            ? _c("div", [
                _c(
                  "ul",
                  {
                    staticClass: "m-t-10",
                    staticStyle: { "list-style": "none", padding: "0" }
                  },
                  _vm._l(_vm.attachments, function(attachment) {
                    return _c("li", [
                      _c(
                        "a",
                        {
                          attrs: {
                            href:
                              "/post/article/" +
                              _vm.article.uuid +
                              "/attachment/" +
                              attachment.uuid +
                              "/download?token=" +
                              _vm.authToken
                          }
                        },
                        [
                          _c("i", { staticClass: "fas fa-paperclip" }),
                          _vm._v(" " + _vm._s(attachment.user_filename))
                        ]
                      )
                    ])
                  })
                )
              ])
            : _vm._e(),
          _vm._v(" "),
          _c("footer", [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col" }, [
                _c("div", { staticClass: "article-author" }, [
                  _c(
                    "span",
                    { staticClass: "author-thumb pull-left" },
                    [
                      !_vm.article.user.employee.photo
                        ? [_c("i", { staticClass: "fas fa-user" })]
                        : [
                            _c("img", {
                              staticClass: "img-circle",
                              attrs: {
                                src: _vm.getEmployeePhoto(
                                  _vm.article.user.employee
                                )
                              }
                            })
                          ]
                    ],
                    2
                  ),
                  _vm._v(" "),
                  _c("p", [
                    _c("span", { staticClass: "author" }, [
                      _vm._v(
                        _vm._s(_vm.getEmployeeName(_vm.article.user.employee))
                      )
                    ]),
                    _vm._v(" "),
                    _c(
                      "span",
                      { staticClass: "designation small text-muted" },
                      [
                        _vm._v(
                          _vm._s(
                            _vm.getEmployeeDesignationOnly(
                              _vm.article.user.employee
                            )
                          )
                        )
                      ]
                    )
                  ])
                ])
              ])
            ])
          ])
        ])
      ])
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-30224be6", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=show.js.map