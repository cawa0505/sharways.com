webpackJsonp([17],{

/***/ 1000:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("div", { staticClass: "page-title" }, [
        _c("div", { staticClass: "fix-width fix-width-mobile" }, [
          _c("h2", [_vm._v(_vm._s(_vm.page.title))])
        ])
      ]),
      _vm._v(" "),
      _vm.page.body
        ? _c("div", { staticClass: "fix-width fix-width-mobile p-t-80" }, [
            _c("div", {
              staticClass: "page-body",
              domProps: { innerHTML: _vm._s(_vm.page.body) }
            }),
            _vm._v(" "),
            _vm.attachments.length
              ? _c("div", [
                  _c(
                    "ul",
                    {
                      staticClass: "m-t-10",
                      staticStyle: { "list-style": "none", padding: "0" }
                    },
                    _vm._l(_vm.attachments, function(attachment) {
                      return _c("li", [
                        _c(
                          "a",
                          {
                            attrs: {
                              href:
                                "/frontend/page/" +
                                _vm.page.uuid +
                                "/attachment/" +
                                attachment.uuid +
                                "/download?token=" +
                                _vm.authToken
                            }
                          },
                          [
                            _c("i", { staticClass: "fas fa-paperclip" }),
                            _vm._v(" " + _vm._s(attachment.user_filename))
                          ]
                        )
                      ])
                    })
                  )
                ])
              : _vm._e()
          ])
        : _vm._e(),
      _vm._v(" "),
      _vm.page.options
        ? [
            _vm.page.options.show_blocks
              ? _c("row-blocks", { attrs: { blocks: _vm.blocks } })
              : _vm._e(),
            _vm._v(" "),
            _vm.page.options.show_latest_articles
              ? _c("row-articles", { attrs: { articles: _vm.articles } })
              : _vm._e()
          ]
        : _vm._e()
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-efaf7cf0", module.exports)
  }
}

/***/ }),

/***/ 260:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(999)
/* template */
var __vue_template__ = __webpack_require__(1000)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/pages/themes/default/page.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-efaf7cf0", Component.options)
  } else {
    hotAPI.reload("data-v-efaf7cf0", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 561:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(562)
/* template */
var __vue_template__ = __webpack_require__(563)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/post/article/show.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-04333416", Component.options)
  } else {
    hotAPI.reload("data-v-04333416", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 562:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    props: ['uuid', 'url'],
    mounted: function mounted() {
        if (this.uuid) this.get();
    },
    data: function data() {
        return {
            article: [],
            attachments: []
        };
    },

    methods: {
        get: function get() {
            var _this = this;

            var loader = this.$loading.show();
            var articleUrl = this.url ? '/api' + this.url : '/api/article/' + this.uuid;
            axios.get(articleUrl).then(function (response) {
                _this.article = response.article;
                _this.attachments = response.attachments;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getEmployeeName: function getEmployeeName(employee) {
            return helper.getEmployeeName(employee);
        },
        getEmployeeDesignation: function getEmployeeDesignation(employee, date) {
            return helper.getEmployeeDesignation(employee, date);
        }
    },
    computed: {
        authToken: function authToken() {
            return helper.getAuthToken();
        }
    },
    filters: {
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        },
        moment: function moment(date) {
            return helper.formatDate(date);
        }
    }
};

/***/ }),

/***/ 563:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("transition", { attrs: { name: "modal" } }, [
    _c("div", { staticClass: "modal-mask" }, [
      _c("div", { staticClass: "modal-wrapper" }, [
        _c("div", { staticClass: "modal-container modal-lg" }, [
          _vm.article.id
            ? _c(
                "div",
                { staticClass: "modal-header" },
                [
                  _vm._t("header", [
                    _c("span", [
                      _vm._v(_vm._s(_vm.article.title) + " "),
                      _vm.article.is_public
                        ? _c("span", { staticClass: "label label-success" }, [
                            _vm._v(_vm._s(_vm.trans("post.article_public")))
                          ])
                        : _vm._e()
                    ]),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        staticClass: "float-right pointer",
                        on: {
                          click: function($event) {
                            _vm.$emit("close")
                          }
                        }
                      },
                      [_vm._v("x")]
                    )
                  ])
                ],
                2
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.article.id
            ? _c(
                "div",
                { staticClass: "modal-body" },
                [
                  _vm._t("body", [
                    _c("h6", { staticClass: "card-title" }, [
                      _vm._v(
                        "\n                            " +
                          _vm._s(_vm.trans("post.date_of_article")) +
                          ": " +
                          _vm._s(
                            _vm._f("moment")(_vm.article.date_of_article)
                          ) +
                          " \n                            "
                      ),
                      _vm.article.user
                        ? _c("p", { staticClass: "pull-right" }, [
                            _c("strong", [
                              _vm._v(
                                _vm._s(_vm.trans("post.article_posted_by")) +
                                  ":"
                              )
                            ]),
                            _vm._v(
                              " " +
                                _vm._s(
                                  _vm.getEmployeeName(_vm.article.user.employee)
                                ) +
                                " " +
                                _vm._s(
                                  _vm.getEmployeeDesignation(
                                    _vm.article.user.employee,
                                    _vm.article.date_of_article
                                  )
                                ) +
                                "\n                            "
                            )
                          ])
                        : _vm._e()
                    ]),
                    _vm._v(" "),
                    _c("div", {
                      staticClass: "m-t-20",
                      domProps: { innerHTML: _vm._s(_vm.article.description) }
                    }),
                    _vm._v(" "),
                    _vm.attachments.length
                      ? _c("div", [
                          _c(
                            "ul",
                            {
                              staticClass: "m-t-10",
                              staticStyle: {
                                "list-style": "none",
                                padding: "0"
                              }
                            },
                            _vm._l(_vm.attachments, function(attachment) {
                              return _c("li", [
                                _c(
                                  "a",
                                  {
                                    attrs: {
                                      href:
                                        "/post/article/" +
                                        _vm.article.uuid +
                                        "/attachment/" +
                                        attachment.uuid +
                                        "/download?token=" +
                                        _vm.authToken
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fas fa-paperclip"
                                    }),
                                    _vm._v(
                                      " " + _vm._s(attachment.user_filename)
                                    )
                                  ]
                                )
                              ])
                            })
                          )
                        ])
                      : _vm._e(),
                    _vm._v(" "),
                    _c("hr"),
                    _vm._v(" "),
                    _c("p", [
                      _c("i", { staticClass: "far fa-clock" }),
                      _vm._v(" "),
                      _c("small", [
                        _vm._v(
                          _vm._s(_vm.trans("general.created_at")) +
                            " " +
                            _vm._s(
                              _vm._f("momentDateTime")(_vm.article.created_at)
                            )
                        )
                      ]),
                      _vm._v(" "),
                      _c("span", { staticClass: "pull-right" }, [
                        _c("i", { staticClass: "far fa-clock" }),
                        _vm._v(" "),
                        _c("small", [
                          _vm._v(
                            _vm._s(_vm.trans("general.updated_at")) +
                              " " +
                              _vm._s(
                                _vm._f("momentDateTime")(_vm.article.updated_at)
                              )
                          )
                        ])
                      ])
                    ])
                  ])
                ],
                2
              )
            : _vm._e()
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-04333416", module.exports)
  }
}

/***/ }),

/***/ 583:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(584)
/* template */
var __vue_template__ = __webpack_require__(585)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/widgets/articles-list.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-00e20c40", Component.options)
  } else {
    hotAPI.reload("data-v-00e20c40", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 584:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _show = __webpack_require__(561);

var _show2 = _interopRequireDefault(_show);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    props: {
        articles: {
            type: Array,
            default: function _default() {
                return [];
            }
        },
        type: String,
        bodyClass: String,
        viewMoreLink: String,
        source: {
            type: String,
            default: "dashboard"
        }
    },
    components: {
        ArticleDetail: _show2.default
    },
    data: function data() {
        return {
            showArticleModal: false
        };
    },

    methods: {
        showArticle: function showArticle(article) {
            this.showArticleUuid = article.uuid;
            this.showArticleModal = true;
        }
    },
    filters: {
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        },
        moment: function moment(date) {
            return helper.formatDate(date);
        },
        momentTime: function momentTime(time) {
            return helper.formatTime(time);
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 585:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "card widget articles-widget" },
    [
      _c(
        "div",
        { class: ["card-body", _vm.bodyClass] },
        [
          _c(
            "h4",
            { staticClass: "card-title" },
            [
              _vm.type
                ? [_vm._v(_vm._s(_vm.type))]
                : [_vm._v(_vm._s(_vm.trans("post.recent_articles")))],
              _vm._v(" "),
              _vm.viewMoreLink
                ? _c(
                    "router-link",
                    {
                      staticClass: "btn btn-default btn-sm",
                      attrs: { to: _vm.viewMoreLink }
                    },
                    [_vm._v(_vm._s(_vm.trans("general.view_more")))]
                  )
                : _vm._e()
            ],
            2
          ),
          _vm._v(" "),
          _vm._l(_vm.articles, function(article) {
            return _c(
              "a",
              {
                staticClass: "list-item",
                on: {
                  click: function($event) {
                    $event.preventDefault()
                    _vm.showArticle(article)
                  }
                }
              },
              [
                _c("h5", [_vm._v(_vm._s(article.title))]),
                _vm._v(" "),
                _c("div", { staticClass: "meta-data" }, [
                  _c("span", { staticClass: "type" }, [
                    _vm._v(_vm._s(article.article_type.name))
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "date" }, [
                    _c("i", { staticClass: "far fa-clock" }),
                    _vm._v(
                      " " + _vm._s(_vm._f("moment")(article.date_of_article))
                    )
                  ])
                ])
              ]
            )
          })
        ],
        2
      ),
      _vm._v(" "),
      _vm.showArticleModal
        ? _c("article-detail", {
            attrs: {
              uuid: _vm.showArticleUuid,
              url: "/frontend/article/" + _vm.showArticleUuid + "/detail"
            },
            on: {
              close: function($event) {
                _vm.showArticleModal = false
              }
            }
          })
        : _vm._e()
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-00e20c40", module.exports)
  }
}

/***/ }),

/***/ 607:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(608)
/* template */
var __vue_template__ = __webpack_require__(612)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/pages/partials/row-blocks.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-6f387888", Component.options)
  } else {
    hotAPI.reload("data-v-6f387888", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 608:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _featuredBlock = __webpack_require__(609);

var _featuredBlock2 = _interopRequireDefault(_featuredBlock);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    props: {
        blocks: {
            type: Array,
            default: function _default() {
                return [];
            }
        },
        bodyClass: String
    },
    components: {
        FeaturedBlock: _featuredBlock2.default
    },
    computed: {
        getClass: function getClass() {
            return this.blocks.length > 1 ? this.blocks.length > 2 ? "col-12 col-sm-6 col-md-4" : "col-12 col-sm-6" : "col";
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 609:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(610)
/* template */
var __vue_template__ = __webpack_require__(611)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/widgets/featured-block.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-370d5a8c", Component.options)
  } else {
    hotAPI.reload("data-v-370d5a8c", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 610:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  props: {
    block: {
      type: Object,
      default: function _default() {
        return {};
      }
    }
  }
};

/***/ }),

/***/ 611:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "card featured-block" }, [
    _c("div", { staticClass: "featured" }, [
      _vm.block.featured_image
        ? _c("img", {
            attrs: { src: "/" + _vm.block.featured_image, alt: _vm.block.title }
          })
        : _c("i", { staticClass: "fas fa-image" })
    ]),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "card-body p-4" },
      [
        _c("h3", { staticClass: "card-title" }, [
          _vm._v(_vm._s(_vm.block.title))
        ]),
        _vm._v(" "),
        _c("p", [_vm._v(_vm._s(_vm.block.body))]),
        _vm._v(" "),
        _vm.block.menu
          ? _c(
              "router-link",
              {
                staticClass: "btn btn-info",
                attrs: {
                  to:
                    _vm.block.menu.options && _vm.block.menu.options.is_default
                      ? "/" + _vm.block.menu.slug
                      : "/page/" + _vm.block.menu.slug
                }
              },
              [_vm._v(_vm._s(_vm.trans("general.view_more")))]
            )
          : _vm._e(),
        _vm._v(" "),
        _vm.block.url
          ? _c(
              "a",
              {
                staticClass: "btn btn-info",
                attrs: { href: _vm.block.url, target: "_blank" }
              },
              [_vm._v(_vm._s(_vm.trans("general.view_more")))]
            )
          : _vm._e()
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-370d5a8c", module.exports)
  }
}

/***/ }),

/***/ 612:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "row light-grey m-t-80 p-t-80 p-b-60" }, [
    _c("div", { staticClass: "col-md-12" }, [
      _c("div", { staticClass: "fix-width fix-width-mobile" }, [
        _c(
          "div",
          { staticClass: "row justify-content-center" },
          _vm._l(_vm.blocks, function(block) {
            return _vm.blocks.length
              ? _c(
                  "div",
                  { class: _vm.getClass },
                  [_c("featured-block", { attrs: { block: block } })],
                  1
                )
              : _vm._e()
          })
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-6f387888", module.exports)
  }
}

/***/ }),

/***/ 613:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(614)
/* template */
var __vue_template__ = __webpack_require__(615)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/pages/partials/row-articles.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-c11d351a", Component.options)
  } else {
    hotAPI.reload("data-v-c11d351a", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 614:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _articlesList = __webpack_require__(583);

var _articlesList2 = _interopRequireDefault(_articlesList);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    props: {
        articles: {
            type: Object,
            default: function _default() {
                return {};
            }
        },
        bodyClass: String
    },
    components: {
        ArticlesList: _articlesList2.default
    },
    data: function data() {
        return {
            showEventModal: false
        };
    },

    methods: {
        getClass: function getClass(articles) {
            return this.articles.length > 1 ? this.articles.length > 2 ? "col-12 col-sm-6 col-md-4" : "col-12 col-sm-6" : "col";
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 615:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "row p-y-80" }, [
    _c("div", { staticClass: "col-md-12" }, [
      _c("div", { staticClass: "fix-width fix-width-mobile" }, [
        _c(
          "div",
          { staticClass: "row" },
          [
            _vm._l(_vm.articles, function(articleList, index) {
              return [
                articleList.length
                  ? _c(
                      "div",
                      { class: _vm.getClass(articleList) },
                      [
                        _c("articles-list", {
                          attrs: { type: index, articles: articleList }
                        })
                      ],
                      1
                    )
                  : _vm._e()
              ]
            })
          ],
          2
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-c11d351a", module.exports)
  }
}

/***/ }),

/***/ 999:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _rowBlocks = __webpack_require__(607);

var _rowBlocks2 = _interopRequireDefault(_rowBlocks);

var _rowArticles = __webpack_require__(613);

var _rowArticles2 = _interopRequireDefault(_rowArticles);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {
        RowBlocks: _rowBlocks2.default,
        RowArticles: _rowArticles2.default
    },
    data: function data() {
        return {
            slug: this.$route.params.page,
            page: {},
            attachments: [],
            blocks: [],
            articles: {}
        };
    },
    mounted: function mounted() {
        this.getData();

        helper.showDemoNotification(['frontend_custom']);
    },

    methods: {
        getData: function getData() {
            var _this = this;

            var loader = this.$loading.show();
            axios.get('/api/frontend/page/' + this.$route.params.page + '/content').then(function (response) {
                _this.page = response.page;
                _this.attachments = response.attachments;
                _this.blocks = response.blocks;
                _this.articles = response.articles;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);

                if (error.response.status == 422) _this.$router.push('/');
            });
        },
        getConfig: function getConfig(config) {
            return helper.getConfig(config);
        }
    },
    filters: {
        moment: function moment(date) {
            return helper.formatDate(date);
        },
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        }
    },
    computed: {
        authToken: function authToken() {
            return helper.getAuthToken();
        }
    },
    watch: {
        '$route.params.page': function $routeParamsPage(page) {
            this.getData();
        }
    }
};

/***/ })

});
//# sourceMappingURL=page.js.map