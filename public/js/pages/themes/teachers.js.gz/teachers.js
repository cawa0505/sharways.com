webpackJsonp([99],{

/***/ 257:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(984)
}
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(986)
/* template */
var __vue_template__ = __webpack_require__(992)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/pages/themes/default/teachers.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-612bc64a", Component.options)
  } else {
    hotAPI.reload("data-v-612bc64a", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 984:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(985);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(14)("5f6d6539", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-612bc64a\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../../node_modules/sass-loader/lib/loader.js!../../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./teachers.vue", function() {
     var newContent = require("!!../../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-612bc64a\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../../node_modules/sass-loader/lib/loader.js!../../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./teachers.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 985:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(8)(true);
// imports


// module
exports.push([module.i, "\n.teacher-group-title {\n  font-weight: 500;\n}\n", "", {"version":3,"sources":["D:/Projects/jacob/resources/js/views/pages/themes/default/teachers.vue"],"names":[],"mappings":";AAAA;EACE,iBAAiB;CAAE","file":"teachers.vue","sourcesContent":[".teacher-group-title {\n  font-weight: 500; }\n"],"sourceRoot":""}]);

// exports


/***/ }),

/***/ 986:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _teacherCard = __webpack_require__(987);

var _teacherCard2 = _interopRequireDefault(_teacherCard);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: {
        TeacherCard: _teacherCard2.default
    },
    data: function data() {
        return {
            page: {},
            teachers: {}
        };
    },
    mounted: function mounted() {
        this.getData();
        this.getTeachers();

        helper.showDemoNotification(['frontend_teacher']);
    },

    methods: {
        getData: function getData() {
            var _this = this;

            var loader = this.$loading.show();
            axios.get('/api/frontend/page/teachers/content').then(function (response) {
                _this.page = response.page;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);

                if (error.response.status == 422) _this.$router.push('/');
            });
        },
        getTeachers: function getTeachers() {
            var _this2 = this;

            var loader = this.$loading.show();
            axios.get('/api/frontend/teacher/list').then(function (response) {
                _this2.teachers = response.teachers;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getConfig: function getConfig(config) {
            return helper.getConfig(config);
        }
    },
    filters: {
        moment: function moment(date) {
            return helper.formatDate(date);
        },
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 987:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(988)
}
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(990)
/* template */
var __vue_template__ = __webpack_require__(991)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-d112bd0e"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/widgets/teacher-card.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-d112bd0e", Component.options)
  } else {
    hotAPI.reload("data-v-d112bd0e", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 988:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(989);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(14)("4d8bcede", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js?sourceMap!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-d112bd0e\",\"scoped\":true,\"hasInlineConfig\":true}!../../../node_modules/sass-loader/lib/loader.js!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./teacher-card.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js?sourceMap!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-d112bd0e\",\"scoped\":true,\"hasInlineConfig\":true}!../../../node_modules/sass-loader/lib/loader.js!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./teacher-card.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 989:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(8)(true);
// imports


// module
exports.push([module.i, "\n.card.teacher-card[data-v-d112bd0e] {\n  opacity: 0.9;\n  -webkit-transition: all 0.3s ease-in-out;\n  transition: all 0.3s ease-in-out;\n  cursor: pointer;\n}\n.card.teacher-card .teacher-info .teacher-thumb[data-v-d112bd0e] {\n    float: left;\n    width: 100px;\n    height: 100px;\n    border-radius: 50%;\n    background: #e1e2e3;\n    margin-right: 20px;\n    text-align: center;\n    overflow: hidden;\n}\n.card.teacher-card .teacher-info .teacher-thumb i[data-v-d112bd0e] {\n      padding-top: 25px;\n      font-size: 50px;\n}\n.card.teacher-card .teacher-info .teacher-thumb img[data-v-d112bd0e] {\n      width: 100%;\n}\n.card.teacher-card .teacher-info p[data-v-d112bd0e] {\n    padding-top: 10px;\n    margin-bottom: 0;\n    min-height: 100px;\n}\n.card.teacher-card .teacher-info p span[data-v-d112bd0e] {\n      display: block;\n}\n.card.teacher-card .teacher-info p span.teacher-name[data-v-d112bd0e] {\n        font-size: 120%;\n        font-weight: 500;\n}\n.card.teacher-card .teacher-info p span.designation[data-v-d112bd0e] {\n        font-size: 100%;\n}\n.card.teacher-card .teacher-info p span.other[data-v-d112bd0e] {\n        font-size: 90%;\n}\n", "", {"version":3,"sources":["D:/Projects/jacob/resources/js/widgets/teacher-card.vue"],"names":[],"mappings":";AAAA;EACE,aAAa;EACb,yCAAiC;EAAjC,iCAAiC;EACjC,gBAAgB;CAAE;AAClB;IACE,YAAY;IACZ,aAAa;IACb,cAAc;IACd,mBAAmB;IACnB,oBAAoB;IACpB,mBAAmB;IACnB,mBAAmB;IACnB,iBAAiB;CAAE;AACnB;MACE,kBAAkB;MAClB,gBAAgB;CAAE;AACpB;MACE,YAAY;CAAE;AAClB;IACE,kBAAkB;IAClB,iBAAiB;IACjB,kBAAkB;CAAE;AACpB;MACE,eAAe;CAAE;AACjB;QACE,gBAAgB;QAChB,iBAAiB;CAAE;AACrB;QACE,gBAAgB;CAAE;AACpB;QACE,eAAe;CAAE","file":"teacher-card.vue","sourcesContent":[".card.teacher-card {\n  opacity: 0.9;\n  transition: all 0.3s ease-in-out;\n  cursor: pointer; }\n  .card.teacher-card .teacher-info .teacher-thumb {\n    float: left;\n    width: 100px;\n    height: 100px;\n    border-radius: 50%;\n    background: #e1e2e3;\n    margin-right: 20px;\n    text-align: center;\n    overflow: hidden; }\n    .card.teacher-card .teacher-info .teacher-thumb i {\n      padding-top: 25px;\n      font-size: 50px; }\n    .card.teacher-card .teacher-info .teacher-thumb img {\n      width: 100%; }\n  .card.teacher-card .teacher-info p {\n    padding-top: 10px;\n    margin-bottom: 0;\n    min-height: 100px; }\n    .card.teacher-card .teacher-info p span {\n      display: block; }\n      .card.teacher-card .teacher-info p span.teacher-name {\n        font-size: 120%;\n        font-weight: 500; }\n      .card.teacher-card .teacher-info p span.designation {\n        font-size: 100%; }\n      .card.teacher-card .teacher-info p span.other {\n        font-size: 90%; }\n"],"sourceRoot":""}]);

// exports


/***/ }),

/***/ 990:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    props: {
        teacher: {
            type: Object,
            default: function _default() {
                return {};
            }
        }
    },
    methods: {
        getConfig: function getConfig(config) {
            return helper.getConfig(config);
        },
        getEmployeePhoto: function getEmployeePhoto(employee) {
            return '/' + employee.photo;
        },
        getEmployeeName: function getEmployeeName(employee) {
            return helper.getEmployeeName(employee);
        },
        getEmployeeDesignationOnly: function getEmployeeDesignationOnly(employee) {
            return helper.getEmployeeDesignationOnly(employee);
        },
        getEmployeeDateOfJoining: function getEmployeeDateOfJoining(employee) {
            return helper.getEmployeeDateOfJoining(employee);
        }
    }
};

/***/ }),

/***/ 991:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "card card-box with-shadow teacher-card" }, [
    _c("div", { staticClass: "card-body" }, [
      _c("div", { staticClass: "teacher-info" }, [
        _c(
          "span",
          { staticClass: "teacher-thumb pull-left" },
          [
            !_vm.teacher.photo
              ? [_c("i", { staticClass: "fas fa-user" })]
              : [
                  _c("img", {
                    staticClass: "img-circle",
                    attrs: { src: _vm.getEmployeePhoto(_vm.teacher) }
                  })
                ]
          ],
          2
        ),
        _vm._v(" "),
        _c("p", [
          _c("span", { staticClass: "teacher-name" }, [
            _vm._v(_vm._s(_vm.getEmployeeName(_vm.teacher)))
          ]),
          _vm._v(" "),
          _vm.getConfig("show_teacher_contact_number")
            ? _c("span", { staticClass: "other small text-muted" }, [
                _c("i", { staticClass: "fas fa-phone" }),
                _vm._v(" " + _vm._s(_vm.teacher.contact_number))
              ])
            : _vm._e(),
          _vm._v(" "),
          _vm.getConfig("show_teacher_email")
            ? _c("span", { staticClass: "other small text-muted" }, [
                _c("i", { staticClass: "fas fa-envelope" }),
                _vm._v(" " + _vm._s(_vm.teacher.email))
              ])
            : _vm._e(),
          _vm._v(" "),
          _vm.getConfig("show_teacher_date_of_joining")
            ? _c("span", { staticClass: "other small text-muted" }, [
                _c("i", { staticClass: "fas fa-calendar" }),
                _vm._v(
                  " " +
                    _vm._s(_vm.trans("general.since")) +
                    " " +
                    _vm._s(_vm.getEmployeeDateOfJoining(_vm.teacher))
                )
              ])
            : _vm._e()
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-d112bd0e", module.exports)
  }
}

/***/ }),

/***/ 992:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-title" }, [
      _c("div", { staticClass: "fix-width fix-width-mobile" }, [
        _c("h2", [_vm._v(_vm._s(_vm.page.title))])
      ])
    ]),
    _vm._v(" "),
    _vm.page.body
      ? _c("div", { staticClass: "fix-width fix-width-mobile p-t-80" }, [
          _c("div", {
            staticClass: "page-body",
            domProps: { innerHTML: _vm._s(_vm.page.body) }
          })
        ])
      : _vm._e(),
    _vm._v(" "),
    _c("div", { staticClass: "fix-width fix-width-mobile p-y-80" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12" }, [
          _c(
            "div",
            { staticClass: "teacher-feed" },
            _vm._l(_vm.teachers, function(teachers, teacherGroup) {
              return _c(
                "div",
                { key: teacherGroup, staticClass: "row teacher-group m-b-30" },
                [
                  _c("div", { staticClass: "col-12" }, [
                    _c("h2", { staticClass: "teacher-group-title m-b-20" }, [
                      _vm._v(_vm._s(teacherGroup))
                    ])
                  ]),
                  _vm._v(" "),
                  _vm._l(teachers, function(teacher) {
                    return _c(
                      "div",
                      {
                        key: teacher.id,
                        staticClass: "col-12 col-sm-6 col-md-4"
                      },
                      [
                        _c("teacher-card", {
                          staticClass: "teacher-item",
                          attrs: { teacher: teacher }
                        })
                      ],
                      1
                    )
                  })
                ],
                2
              )
            })
          )
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-612bc64a", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=teachers.js.map