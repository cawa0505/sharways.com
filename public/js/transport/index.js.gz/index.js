webpackJsonp([265],{

/***/ 1799:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {};

/***/ }),

/***/ 1800:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-titles" }, [
      _c("h3", { staticClass: "text-themecolor" }, [
        _vm._v(_vm._s(_vm.trans("transport.transport")))
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "container-fluid container-body" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("transport.circle")))
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(_vm.trans("transport.circle_module_description"))
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/transport/circle" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("transport.circle")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("transport.fee")))
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(_vm._s(_vm.trans("transport.fee_module_description")))
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/transport/fee" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("transport.fee")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("transport.vehicle")))
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(_vm.trans("transport.vehicle_module_description"))
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/transport/vehicle" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("transport.vehicle")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("transport.vehicle_document")))
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(
                      _vm.trans("transport.vehicle_document_module_description")
                    )
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/transport/vehicle/document" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("transport.vehicle_document")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("transport.vehicle_fuel")))
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(
                      _vm.trans("transport.vehicle_fuel_module_description")
                    )
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/transport/vehicle/fuel" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("transport.vehicle_fuel")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("transport.vehicle_log")))
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(
                      _vm.trans("transport.vehicle_log_module_description")
                    )
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/transport/vehicle/log" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("transport.vehicle_log")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c("div", { staticClass: "card card-box" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("transport.vehicle_service_record")))
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text font-80pc" }, [
                  _vm._v(
                    _vm._s(
                      _vm.trans(
                        "transport.vehicle_service_record_module_description"
                      )
                    )
                  )
                ]),
                _vm._v(" "),
                _c(
                  "router-link",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: { to: "/transport/vehicle/service/record" }
                  },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.go_to_link", {
                          link: _vm.trans("transport.vehicle_service_record")
                        })
                      )
                    )
                  ]
                )
              ],
              1
            )
          ])
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-c0cfa086", module.exports)
  }
}

/***/ }),

/***/ 511:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1799)
/* template */
var __vue_template__ = __webpack_require__(1800)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/transport/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-c0cfa086", Component.options)
  } else {
    hotAPI.reload("data-v-c0cfa086", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ })

});
//# sourceMappingURL=index.js.map