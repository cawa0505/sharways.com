webpackJsonp([272],{

/***/ 249:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(948)
/* template */
var __vue_template__ = __webpack_require__(949)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/resource/assignment/show.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-e24c5806", Component.options)
  } else {
    hotAPI.reload("data-v-e24c5806", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 948:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    props: ['uuid', 'url'],
    mounted: function mounted() {
        if (this.uuid) this.get();
    },
    data: function data() {
        return {
            assignment: [],
            attachments: []
        };
    },

    methods: {
        get: function get() {
            var _this = this;

            var loader = this.$loading.show();
            axios.get('/api/assignment/' + this.uuid).then(function (response) {
                _this.assignment = response.assignment;
                _this.attachments = response.attachments;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getEmployeeName: function getEmployeeName(employee) {
            return helper.getEmployeeName(employee);
        },
        getEmployeeDesignation: function getEmployeeDesignation(employee, date) {
            return helper.getEmployeeDesignation(employee, date);
        }
    },
    computed: {
        authToken: function authToken() {
            return helper.getAuthToken();
        }
    },
    filters: {
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        },
        moment: function moment(date) {
            return helper.formatDate(date);
        }
    }
};

/***/ }),

/***/ 949:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("transition", { attrs: { name: "modal" } }, [
    _c("div", { staticClass: "modal-mask" }, [
      _c("div", { staticClass: "modal-wrapper" }, [
        _c("div", { staticClass: "modal-container modal-lg" }, [
          _vm.assignment.id
            ? _c(
                "div",
                { staticClass: "modal-header" },
                [
                  _vm._t("header", [
                    _c("span", [_vm._v(_vm._s(_vm.assignment.title))]),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        staticClass: "float-right pointer",
                        on: {
                          click: function($event) {
                            _vm.$emit("close")
                          }
                        }
                      },
                      [_vm._v("x")]
                    )
                  ])
                ],
                2
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.assignment.id
            ? _c(
                "div",
                { staticClass: "modal-body" },
                [
                  _vm._t("body", [
                    _c("h6", { staticClass: "card-title" }, [
                      _c("strong", [
                        _vm._v(_vm._s(_vm.trans("academic.subject")) + ":")
                      ]),
                      _vm._v(
                        " " +
                          _vm._s(
                            _vm.assignment.subject.name +
                              " (" +
                              _vm.assignment.subject.code +
                              ")"
                          ) +
                          " \n                            "
                      ),
                      _c("br"),
                      _vm._v(" "),
                      _c("strong", [
                        _vm._v(_vm._s(_vm.trans("academic.batch")) + ":")
                      ]),
                      _vm._v(
                        " " +
                          _vm._s(
                            _vm.assignment.subject.batch.course.name +
                              " " +
                              _vm.assignment.subject.batch.name
                          ) +
                          " \n                            "
                      ),
                      _c("br"),
                      _vm._v(" "),
                      _c("strong", [
                        _vm._v(
                          _vm._s(_vm.trans("resource.date_of_assignment")) + ":"
                        )
                      ]),
                      _vm._v(
                        " " +
                          _vm._s(
                            _vm._f("moment")(_vm.assignment.date_of_assignment)
                          ) +
                          " \n                            "
                      ),
                      _c("br"),
                      _vm._v(" "),
                      _c("strong", [
                        _vm._v(
                          _vm._s(_vm.trans("resource.due_date_of_assignment")) +
                            ":"
                        )
                      ]),
                      _vm._v(
                        " " +
                          _vm._s(_vm._f("moment")(_vm.assignment.due_date)) +
                          " \n                            "
                      ),
                      _vm.assignment.employee
                        ? _c("p", { staticClass: "pull-right" }, [
                            _c("strong", [
                              _vm._v(
                                _vm._s(
                                  _vm.trans("resource.assignment_posted_by")
                                ) + ":"
                              )
                            ]),
                            _vm._v(
                              " " +
                                _vm._s(
                                  _vm.getEmployeeName(_vm.assignment.employee)
                                ) +
                                " " +
                                _vm._s(
                                  _vm.getEmployeeDesignation(
                                    _vm.assignment.employee,
                                    _vm.assignment.date_of_assignment
                                  )
                                ) +
                                "\n                            "
                            )
                          ])
                        : _vm._e()
                    ]),
                    _vm._v(" "),
                    _c("div", {
                      staticClass: "m-t-20",
                      domProps: {
                        innerHTML: _vm._s(_vm.assignment.description)
                      }
                    }),
                    _vm._v(" "),
                    _vm.attachments.length
                      ? _c("div", [
                          _c(
                            "ul",
                            {
                              staticClass: "m-t-10",
                              staticStyle: {
                                "list-style": "none",
                                padding: "0"
                              }
                            },
                            _vm._l(_vm.attachments, function(attachment) {
                              return _c("li", [
                                _c(
                                  "a",
                                  {
                                    attrs: {
                                      href:
                                        "/resource/assignment/" +
                                        _vm.assignment.uuid +
                                        "/attachment/" +
                                        attachment.uuid +
                                        "/download?token=" +
                                        _vm.authToken
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fas fa-paperclip"
                                    }),
                                    _vm._v(
                                      " " + _vm._s(attachment.user_filename)
                                    )
                                  ]
                                )
                              ])
                            })
                          )
                        ])
                      : _vm._e(),
                    _vm._v(" "),
                    _c("hr"),
                    _vm._v(" "),
                    _c("p", [
                      _c("i", { staticClass: "far fa-clock" }),
                      _vm._v(" "),
                      _c("small", [
                        _vm._v(
                          _vm._s(_vm.trans("general.created_at")) +
                            " " +
                            _vm._s(
                              _vm._f("momentDateTime")(
                                _vm.assignment.created_at
                              )
                            )
                        )
                      ]),
                      _vm._v(" "),
                      _c("span", { staticClass: "pull-right" }, [
                        _c("i", { staticClass: "far fa-clock" }),
                        _vm._v(" "),
                        _c("small", [
                          _vm._v(
                            _vm._s(_vm.trans("general.updated_at")) +
                              " " +
                              _vm._s(
                                _vm._f("momentDateTime")(
                                  _vm.assignment.updated_at
                                )
                              )
                          )
                        ])
                      ])
                    ])
                  ])
                ],
                2
              )
            : _vm._e()
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-e24c5806", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=show.js.map