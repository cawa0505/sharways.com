webpackJsonp([270],{

/***/ 251:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(957)
/* template */
var __vue_template__ = __webpack_require__(958)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/resource/lesson-plan/show.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-d2e94f80", Component.options)
  } else {
    hotAPI.reload("data-v-d2e94f80", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 957:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    props: ['uuid', 'url'],
    mounted: function mounted() {
        if (this.uuid) this.get();
    },
    data: function data() {
        return {
            lesson_plan: [],
            attachments: []
        };
    },

    methods: {
        get: function get() {
            var _this = this;

            var loader = this.$loading.show();
            axios.get('/api/lesson/plan/' + this.uuid).then(function (response) {
                _this.lesson_plan = response.lesson_plan;
                _this.attachments = response.attachments;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getEmployeeName: function getEmployeeName(employee) {
            return helper.getEmployeeName(employee);
        },
        getEmployeeDesignation: function getEmployeeDesignation(employee, date) {
            return helper.getEmployeeDesignation(employee, date);
        }
    },
    computed: {
        authToken: function authToken() {
            return helper.getAuthToken();
        }
    },
    filters: {
        momentDateTime: function momentDateTime(date) {
            return helper.formatDateTime(date);
        },
        moment: function moment(date) {
            return helper.formatDate(date);
        }
    }
};

/***/ }),

/***/ 958:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("transition", { attrs: { name: "modal" } }, [
    _c("div", { staticClass: "modal-mask" }, [
      _c("div", { staticClass: "modal-wrapper" }, [
        _c("div", { staticClass: "modal-container modal-lg" }, [
          _vm.lesson_plan.id
            ? _c(
                "div",
                { staticClass: "modal-header" },
                [
                  _vm._t("header", [
                    _c("span", [_vm._v(_vm._s(_vm.lesson_plan.topic))]),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        staticClass: "float-right pointer",
                        on: {
                          click: function($event) {
                            _vm.$emit("close")
                          }
                        }
                      },
                      [_vm._v("x")]
                    )
                  ])
                ],
                2
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.lesson_plan.id
            ? _c(
                "div",
                { staticClass: "modal-body" },
                [
                  _vm._t("body", [
                    _c("h6", { staticClass: "card-title" }, [
                      _c("strong", [
                        _vm._v(_vm._s(_vm.trans("academic.subject")) + ":")
                      ]),
                      _vm._v(
                        " " +
                          _vm._s(
                            _vm.lesson_plan.subject.name +
                              " (" +
                              _vm.lesson_plan.subject.code +
                              ")"
                          ) +
                          " \n                            "
                      ),
                      _c("br"),
                      _vm._v(" "),
                      _c("strong", [
                        _vm._v(_vm._s(_vm.trans("academic.batch")) + ":")
                      ]),
                      _vm._v(
                        " " +
                          _vm._s(
                            _vm.lesson_plan.subject.batch.course.name +
                              " " +
                              _vm.lesson_plan.subject.batch.name
                          ) +
                          " \n                            "
                      ),
                      _c("br"),
                      _vm._v(" "),
                      _c("strong", [
                        _vm._v(
                          _vm._s(_vm.trans("resource.lesson_plan_start_date")) +
                            ":"
                        )
                      ]),
                      _vm._v(
                        " " +
                          _vm._s(_vm._f("moment")(_vm.lesson_plan.start_date)) +
                          " \n                            "
                      ),
                      _c("br"),
                      _vm._v(" "),
                      _c("strong", [
                        _vm._v(
                          _vm._s(_vm.trans("resource.lesson_plan_end_date")) +
                            ":"
                        )
                      ]),
                      _vm._v(
                        " " +
                          _vm._s(_vm._f("moment")(_vm.lesson_plan.end_date)) +
                          " \n                            "
                      ),
                      _vm.lesson_plan.employee
                        ? _c("p", { staticClass: "pull-right" }, [
                            _c("strong", [
                              _vm._v(
                                _vm._s(
                                  _vm.trans("resource.lesson_plan_created_by")
                                ) + ":"
                              )
                            ]),
                            _vm._v(
                              " " +
                                _vm._s(
                                  _vm.getEmployeeName(_vm.lesson_plan.employee)
                                ) +
                                " " +
                                _vm._s(
                                  _vm.getEmployeeDesignation(
                                    _vm.lesson_plan.employee,
                                    _vm.lesson_plan.start_date
                                  )
                                ) +
                                "\n                            "
                            )
                          ])
                        : _vm._e()
                    ]),
                    _vm._v(" "),
                    _vm._l(_vm.lesson_plan.lesson_plan_details, function(
                      lesson_plan_detail
                    ) {
                      return _c("div", { staticClass: "m-t-20" }, [
                        _c("h6", { staticClass: "card-title" }, [
                          _vm._v(_vm._s(lesson_plan_detail.title))
                        ]),
                        _vm._v(" "),
                        _c("p", {
                          staticClass: "font-90pc",
                          domProps: {
                            textContent: _vm._s(lesson_plan_detail.description)
                          }
                        }),
                        _vm._v(" "),
                        !_vm.$last(
                          lesson_plan_detail,
                          _vm.lesson_plan.lesson_plan_details
                        )
                          ? _c("hr")
                          : _vm._e()
                      ])
                    }),
                    _vm._v(" "),
                    _vm.attachments.length
                      ? _c("div", [
                          _c(
                            "ul",
                            {
                              staticClass: "m-t-10",
                              staticStyle: {
                                "list-style": "none",
                                padding: "0"
                              }
                            },
                            _vm._l(_vm.attachments, function(attachment) {
                              return _c("li", [
                                _c(
                                  "a",
                                  {
                                    attrs: {
                                      href:
                                        "/resource/lesson/plan/" +
                                        _vm.lesson_plan.uuid +
                                        "/attachment/" +
                                        attachment.uuid +
                                        "/download?token=" +
                                        _vm.authToken
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fas fa-paperclip"
                                    }),
                                    _vm._v(
                                      " " + _vm._s(attachment.user_filename)
                                    )
                                  ]
                                )
                              ])
                            })
                          )
                        ])
                      : _vm._e(),
                    _vm._v(" "),
                    _c("hr"),
                    _vm._v(" "),
                    _c("p", [
                      _c("i", { staticClass: "far fa-clock" }),
                      _vm._v(" "),
                      _c("small", [
                        _vm._v(
                          _vm._s(_vm.trans("general.created_at")) +
                            " " +
                            _vm._s(
                              _vm._f("momentDateTime")(
                                _vm.lesson_plan.created_at
                              )
                            )
                        )
                      ]),
                      _vm._v(" "),
                      _c("span", { staticClass: "pull-right" }, [
                        _c("i", { staticClass: "far fa-clock" }),
                        _vm._v(" "),
                        _c("small", [
                          _vm._v(
                            _vm._s(_vm.trans("general.updated_at")) +
                              " " +
                              _vm._s(
                                _vm._f("momentDateTime")(
                                  _vm.lesson_plan.updated_at
                                )
                              )
                          )
                        ])
                      ])
                    ])
                  ])
                ],
                2
              )
            : _vm._e()
        ])
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-d2e94f80", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=show.js.map