webpackJsonp([263],{

/***/ 1215:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    data: function data() {
        return {
            email_logs: {
                total: 0,
                data: []
            },
            filter: {
                page_length: helper.getConfig('page_length'),
                sort_by: 'created_at',
                order: 'desc'
            },
            email_log: {},
            orderByOptions: [{
                value: 'created_at',
                translation: i18n.general.created_at
            }],
            showDetailModal: false
        };
    },
    mounted: function mounted() {
        if (!helper.featureAvailable('email_log')) {
            helper.featureNotAvailableMsg();
            this.$router.push('/dashboard');
        }

        if (!helper.hasPermission('access-configuration')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }

        this.getEmailLogs();
    },

    methods: {
        getEmailLogs: function getEmailLogs(page) {
            var _this = this;

            var loader = this.$loading.show();
            if (typeof page !== 'number') {
                page = 1;
            }
            var url = helper.getFilterURL(this.filter);
            axios.get('/api/email-log?page=' + page + url).then(function (response) {
                _this.email_logs = response;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        showDetailAction: function showDetailAction(email_log) {
            var _this2 = this;

            this.showDetailModal = true;
            var loader = this.$loading.show();
            axios.get('/api/email-log/' + email_log.id).then(function (response) {
                _this2.email_log = response;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        confirmDelete: function confirmDelete(email_log) {
            var _this3 = this;

            return function (dialog) {
                return _this3.deleteEmailLog(email_log);
            };
        },
        deleteEmailLog: function deleteEmailLog(email_log) {
            var _this4 = this;

            var loader = this.$loading.show();
            axios.delete('/api/email-log/' + email_log.id).then(function (response) {
                toastr.success(response.message);
                _this4.getEmailLogs();
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    },
    filters: {
        moment: function moment(date) {
            return helper.formatDateTime(date);
        }
    },
    watch: {
        filter: {
            handler: function handler(val) {
                this.getEmailLogs();
            },

            deep: true
        }
    }
};

/***/ }),

/***/ 1216:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-titles" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("h3", { staticClass: "text-themecolor" }, [
            _vm._v(
              _vm._s(_vm.trans("utility.email_log")) + "\n                    "
            ),
            _vm.email_logs.total
              ? _c(
                  "span",
                  { staticClass: "card-subtitle d-none d-sm-inline" },
                  [
                    _vm._v(
                      _vm._s(
                        _vm.trans("general.total_result_found", {
                          count: _vm.email_logs.total,
                          from: _vm.email_logs.from,
                          to: _vm.email_logs.to
                        })
                      )
                    )
                  ]
                )
              : _c(
                  "span",
                  { staticClass: "card-subtitle d-none d-sm-inline" },
                  [_vm._v(_vm._s(_vm.trans("general.no_result_found")))]
                )
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c(
            "div",
            { staticClass: "action-buttons pull-right" },
            [
              _c("sort-by", {
                attrs: {
                  "order-by-options": _vm.orderByOptions,
                  "sort-by": _vm.filter.sort_by,
                  order: _vm.filter.order
                },
                on: {
                  updateSortBy: function(value) {
                    _vm.filter.sort_by = value
                  },
                  updateOrder: function(value) {
                    _vm.filter.order = value
                  }
                }
              })
            ],
            1
          )
        ])
      ])
    ]),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "container-fluid" },
      [
        _c("div", { staticClass: "card" }, [
          _c(
            "div",
            { staticClass: "card-body" },
            [
              _vm.email_logs.total
                ? _c("div", { staticClass: "table-responsive" }, [
                    _c("table", { staticClass: "table table-hover" }, [
                      _c("thead", [
                        _c("tr", [
                          _c("th", [
                            _vm._v(_vm._s(_vm.trans("utility.email_receiver")))
                          ]),
                          _vm._v(" "),
                          _c("th", [
                            _vm._v(_vm._s(_vm.trans("utility.email_subject")))
                          ]),
                          _vm._v(" "),
                          _c("th", [
                            _vm._v(_vm._s(_vm.trans("utility.sent_at")))
                          ]),
                          _vm._v(" "),
                          _c("th", { staticClass: "table-option" }, [
                            _vm._v(_vm._s(_vm.trans("general.action")))
                          ])
                        ])
                      ]),
                      _vm._v(" "),
                      _c(
                        "tbody",
                        _vm._l(_vm.email_logs.data, function(email_log) {
                          return _c("tr", [
                            _c("td", {
                              domProps: {
                                textContent: _vm._s(email_log.to_address)
                              }
                            }),
                            _vm._v(" "),
                            _c("td", {
                              domProps: {
                                textContent: _vm._s(email_log.subject)
                              }
                            }),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(
                                _vm._s(_vm._f("moment")(email_log.created_at))
                              )
                            ]),
                            _vm._v(" "),
                            _c("td", { staticClass: "table-option" }, [
                              _c("div", { staticClass: "btn-group" }, [
                                _c(
                                  "button",
                                  {
                                    directives: [
                                      {
                                        name: "tooltip",
                                        rawName: "v-tooltip",
                                        value: _vm.trans("utility.view_email"),
                                        expression:
                                          "trans('utility.view_email')"
                                      }
                                    ],
                                    staticClass: "btn btn-info btn-sm",
                                    attrs: { type: "button" },
                                    on: {
                                      click: function($event) {
                                        _vm.showDetailAction(email_log)
                                      }
                                    }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "fas fa-arrow-circle-right"
                                    })
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "button",
                                  {
                                    directives: [
                                      {
                                        name: "confirm",
                                        rawName: "v-confirm",
                                        value: {
                                          ok: _vm.confirmDelete(email_log)
                                        },
                                        expression:
                                          "{ok: confirmDelete(email_log)}"
                                      },
                                      {
                                        name: "tooltip",
                                        rawName: "v-tooltip",
                                        value: _vm.trans(
                                          "utility.delete_email_log"
                                        ),
                                        expression:
                                          "trans('utility.delete_email_log')"
                                      }
                                    ],
                                    key: email_log.id,
                                    staticClass: "btn btn-danger btn-sm"
                                  },
                                  [_c("i", { staticClass: "fas fa-trash" })]
                                )
                              ])
                            ])
                          ])
                        })
                      )
                    ])
                  ])
                : _vm._e(),
              _vm._v(" "),
              !_vm.email_logs.total
                ? _c("module-info", {
                    attrs: {
                      module: "utility",
                      title: "email_log_module_title",
                      description: "email_log_module_description",
                      icon: "list"
                    }
                  })
                : _vm._e(),
              _vm._v(" "),
              _c("pagination-record", {
                attrs: {
                  "page-length": _vm.filter.page_length,
                  records: _vm.email_logs
                },
                on: {
                  "update:pageLength": function($event) {
                    _vm.$set(_vm.filter, "page_length", $event)
                  },
                  updateRecords: _vm.getEmailLogs
                },
                nativeOn: {
                  change: function($event) {
                    return _vm.getEmailLogs($event)
                  }
                }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _vm.showDetailModal
          ? _c("transition", { attrs: { name: "modal" } }, [
              _c("div", { staticClass: "modal-mask" }, [
                _c("div", { staticClass: "modal-wrapper" }, [
                  _c("div", { staticClass: "modal-container modal-lg" }, [
                    _c(
                      "div",
                      { staticClass: "modal-header" },
                      [
                        _vm._t("header", [
                          _vm._v(
                            "\n                                " +
                              _vm._s(_vm.trans("utility.email_log")) +
                              "\n                                "
                          ),
                          _c(
                            "span",
                            {
                              staticClass: "float-right pointer",
                              on: {
                                click: function($event) {
                                  _vm.showDetailModal = false
                                }
                              }
                            },
                            [_vm._v("x")]
                          )
                        ])
                      ],
                      2
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "modal-body" },
                      [
                        _vm._t("body", [
                          _c("h4", [
                            _vm._v(
                              _vm._s(_vm.utility.email_subject) +
                                "\n                                    "
                            ),
                            _c("span", { staticClass: "pull-right" }, [
                              _vm._v(
                                _vm._s(
                                  _vm._f("moment")(_vm.email_log.created_at)
                                )
                              )
                            ])
                          ]),
                          _vm._v(" "),
                          _c("p", [
                            _vm._v(
                              _vm._s(
                                _vm.trans("utility.email_sender") +
                                  ": " +
                                  _vm.email_log.from_address
                              )
                            )
                          ]),
                          _vm._v(" "),
                          _c("p", [
                            _vm._v(
                              _vm._s(
                                _vm.trans("utility.email_receiver") +
                                  ": " +
                                  _vm.email_log.to_address
                              )
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", {
                            domProps: { innerHTML: _vm._s(_vm.email_log.body) }
                          }),
                          _vm._v(" "),
                          _c("div", { staticClass: "clearfix" })
                        ])
                      ],
                      2
                    )
                  ])
                ])
              ])
            ])
          : _vm._e()
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-becfb0f8", module.exports)
  }
}

/***/ }),

/***/ 361:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1215)
/* template */
var __vue_template__ = __webpack_require__(1216)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/utility/email-log/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-becfb0f8", Component.options)
  } else {
    hotAPI.reload("data-v-becfb0f8", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ })

});
//# sourceMappingURL=index.js.map