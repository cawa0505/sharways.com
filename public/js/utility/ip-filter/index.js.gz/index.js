webpackJsonp([151],{

/***/ 1207:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _form = __webpack_require__(800);

var _form2 = _interopRequireDefault(_form);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: { ipFilterForm: _form2.default },
    data: function data() {
        return {
            ip_filters: {
                total: 0,
                data: []
            },
            filter: {
                page_length: helper.getConfig('page_length')
            },
            showCreatePanel: false,
            help_topic: ''
        };
    },
    mounted: function mounted() {
        if (!helper.hasPermission('access-configuration')) {
            helper.notAccessibleMsg();
            this.$router.push('/dashboard');
        }

        if (!helper.featureAvailable('ip_filter')) {
            helper.featureNotAvailableMsg();
            this.$router.push('/dashboard');
        }

        this.getIpFilters();
    },

    methods: {
        getIpFilters: function getIpFilters(page) {
            var _this = this;

            var loader = this.$loading.show();
            if (typeof page !== 'number') {
                page = 1;
            }
            var url = helper.getFilterURL(this.filter);
            axios.get('/api/ip-filter?page=' + page + url).then(function (response) {
                _this.ip_filters = response;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        editIpFilter: function editIpFilter(ip_filter) {
            this.$router.push('/utility/ip-filter/' + ip_filter.id + '/edit');
        },
        confirmDelete: function confirmDelete(ip_filter) {
            var _this2 = this;

            return function (dialog) {
                return _this2.deleteIpFilter(ip_filter);
            };
        },
        deleteIpFilter: function deleteIpFilter(ip_filter) {
            var _this3 = this;

            var loader = this.$loading.show();
            axios.delete('/api/ip-filter/' + ip_filter.id).then(function (response) {
                toastr.success(response.message);
                _this3.getIpFilters();
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1208:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("div", { staticClass: "page-titles" }, [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c("h3", { staticClass: "text-themecolor" }, [
              _vm._v(
                _vm._s(_vm.trans("utility.ip_filter")) +
                  "\n                    "
              ),
              _vm.ip_filters.total
                ? _c(
                    "span",
                    { staticClass: "card-subtitle d-none d-sm-inline" },
                    [
                      _vm._v(
                        _vm._s(
                          _vm.trans("general.total_result_found", {
                            count: _vm.ip_filters.total,
                            from: _vm.ip_filters.from,
                            to: _vm.ip_filters.to
                          })
                        )
                      )
                    ]
                  )
                : _c(
                    "span",
                    { staticClass: "card-subtitle d-none d-sm-inline" },
                    [_vm._v(_vm._s(_vm.trans("general.no_result_found")))]
                  )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-12 col-sm-6" }, [
            _c(
              "div",
              { staticClass: "action-buttons pull-right" },
              [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info btn-sm",
                    on: {
                      click: function($event) {
                        _vm.showCreatePanel = !_vm.showCreatePanel
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "fas fa-plus" }),
                    _vm._v(" "),
                    _c("span", { staticClass: "d-none d-sm-inline" }, [
                      _vm._v(_vm._s(_vm.trans("utility.add_new_ip_filter")))
                    ])
                  ]
                ),
                _vm._v(" "),
                _c("help-button", {
                  on: {
                    clicked: function($event) {
                      _vm.help_topic = "utility.ip-filter"
                    }
                  }
                })
              ],
              1
            )
          ])
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "container-fluid" },
        [
          _c("transition", { attrs: { name: "fade" } }, [
            _vm.showCreatePanel
              ? _c("div", { staticClass: "card card-form" }, [
                  _c(
                    "div",
                    { staticClass: "card-body" },
                    [
                      _c("h4", { staticClass: "card-title" }, [
                        _vm._v(_vm._s(_vm.trans("utility.add_new_ip_filter")))
                      ]),
                      _vm._v(" "),
                      _c("show-tip", {
                        attrs: { module: "utility", tip: "tip_ip_filter" }
                      }),
                      _vm._v(" "),
                      _c("ip-filter-form", {
                        on: {
                          completed: _vm.getIpFilters,
                          cancel: function($event) {
                            _vm.showCreatePanel = !_vm.showCreatePanel
                          }
                        }
                      })
                    ],
                    1
                  )
                ])
              : _vm._e()
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "card" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _vm.ip_filters.total
                  ? _c("div", { staticClass: "table-responsive" }, [
                      _c("table", { staticClass: "table table-sm" }, [
                        _c("thead", [
                          _c("tr", [
                            _c("th", [
                              _vm._v(_vm._s(_vm.trans("utility.start_ip")))
                            ]),
                            _vm._v(" "),
                            _c("th", [
                              _vm._v(_vm._s(_vm.trans("utility.end_ip")))
                            ]),
                            _vm._v(" "),
                            _c("th", [
                              _vm._v(
                                _vm._s(
                                  _vm.trans("utility.ip_filter_description")
                                )
                              )
                            ]),
                            _vm._v(" "),
                            _c("th", { staticClass: "table-option" }, [
                              _vm._v(_vm._s(_vm.trans("general.action")))
                            ])
                          ])
                        ]),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          _vm._l(_vm.ip_filters.data, function(ip_filter) {
                            return _c("tr", [
                              _c("td", {
                                domProps: {
                                  textContent: _vm._s(ip_filter.start_ip)
                                }
                              }),
                              _vm._v(" "),
                              _c("td", {
                                domProps: {
                                  textContent: _vm._s(ip_filter.end_ip)
                                }
                              }),
                              _vm._v(" "),
                              _c("td", {
                                domProps: {
                                  textContent: _vm._s(ip_filter.description)
                                }
                              }),
                              _vm._v(" "),
                              _c("td", { staticClass: "table-option" }, [
                                _c("div", { staticClass: "btn-group" }, [
                                  _c(
                                    "button",
                                    {
                                      directives: [
                                        {
                                          name: "tooltip",
                                          rawName: "v-tooltip",
                                          value: _vm.trans(
                                            "utility.edit_ip_filter"
                                          ),
                                          expression:
                                            "trans('utility.edit_ip_filter')"
                                        }
                                      ],
                                      staticClass: "btn btn-info btn-sm",
                                      on: {
                                        click: function($event) {
                                          $event.preventDefault()
                                          _vm.editIpFilter(ip_filter)
                                        }
                                      }
                                    },
                                    [_c("i", { staticClass: "fas fa-edit" })]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "button",
                                    {
                                      directives: [
                                        {
                                          name: "confirm",
                                          rawName: "v-confirm",
                                          value: {
                                            ok: _vm.confirmDelete(ip_filter)
                                          },
                                          expression:
                                            "{ok: confirmDelete(ip_filter)}"
                                        },
                                        {
                                          name: "tooltip",
                                          rawName: "v-tooltip",
                                          value: _vm.trans(
                                            "utility.delete_ip_filter"
                                          ),
                                          expression:
                                            "trans('utility.delete_ip_filter')"
                                        }
                                      ],
                                      key: ip_filter.id,
                                      staticClass: "btn btn-danger btn-sm"
                                    },
                                    [_c("i", { staticClass: "fas fa-trash" })]
                                  )
                                ])
                              ])
                            ])
                          })
                        )
                      ])
                    ])
                  : _vm._e(),
                _vm._v(" "),
                !_vm.ip_filters.total
                  ? _c("module-info", {
                      attrs: {
                        module: "utility",
                        title: "ip_filter_module_title",
                        description: "ip_filter_module_description",
                        icon: "list"
                      }
                    })
                  : _vm._e(),
                _vm._v(" "),
                _c("pagination-record", {
                  attrs: {
                    "page-length": _vm.filter.page_length,
                    records: _vm.ip_filters
                  },
                  on: {
                    "update:pageLength": function($event) {
                      _vm.$set(_vm.filter, "page_length", $event)
                    },
                    updateRecords: _vm.getIpFilters
                  },
                  nativeOn: {
                    change: function($event) {
                      return _vm.getIpFilters($event)
                    }
                  }
                })
              ],
              1
            )
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("right-panel", { attrs: { topic: _vm.help_topic } })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-32be6f0f", module.exports)
  }
}

/***/ }),

/***/ 357:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1207)
/* template */
var __vue_template__ = __webpack_require__(1208)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/utility/ip-filter/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-32be6f0f", Component.options)
  } else {
    hotAPI.reload("data-v-32be6f0f", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 800:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(801)
/* template */
var __vue_template__ = __webpack_require__(802)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/utility/ip-filter/form.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-c98a6fd2", Component.options)
  } else {
    hotAPI.reload("data-v-c98a6fd2", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 801:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {},
    data: function data() {
        return {
            ipFilterForm: new Form({
                start_ip: '',
                end_ip: '',
                description: ''
            })
        };
    },

    props: ['id'],
    mounted: function mounted() {
        if (this.id) this.getIpFilter();
    },

    methods: {
        proceed: function proceed() {
            if (this.id) this.updateIpFilter();else this.storeIpFilter();
        },
        storeIpFilter: function storeIpFilter() {
            var _this = this;

            var loader = this.$loading.show();
            this.ipFilterForm.post('/api/ip-filter').then(function (response) {
                toastr.success(response.message);
                _this.$emit('completed');
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        getIpFilter: function getIpFilter() {
            var _this2 = this;

            var loader = this.$loading.show();
            axios.get('/api/ip-filter/' + this.id).then(function (response) {
                _this2.ipFilterForm.start_ip = response.start_ip;
                _this2.ipFilterForm.end_ip = response.end_ip;
                _this2.ipFilterForm.description = response.description;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
                _this2.$router.push('/utility/ip-filter');
            });
        },
        updateIpFilter: function updateIpFilter() {
            var _this3 = this;

            var loader = this.$loading.show();
            this.ipFilterForm.patch('/api/ip-filter/' + this.id).then(function (response) {
                toastr.success(response.message);
                loader.hide();
                _this3.$router.push('/utility/ip-filter');
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    }
};

/***/ }),

/***/ 802:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "form",
    {
      on: {
        submit: function($event) {
          $event.preventDefault()
          return _vm.proceed($event)
        },
        keydown: function($event) {
          _vm.ipFilterForm.errors.clear($event.target.name)
        }
      }
    },
    [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(_vm._s(_vm.trans("utility.start_ip")))
              ]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.ipFilterForm.start_ip,
                    expression: "ipFilterForm.start_ip"
                  }
                ],
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  name: "start_ip",
                  placeholder: _vm.trans("utility.start_ip")
                },
                domProps: { value: _vm.ipFilterForm.start_ip },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.ipFilterForm, "start_ip", $event.target.value)
                  }
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: {
                  "form-name": _vm.ipFilterForm,
                  "prop-name": "start_ip"
                }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-3" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(_vm._s(_vm.trans("utility.end_ip")))
              ]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.ipFilterForm.end_ip,
                    expression: "ipFilterForm.end_ip"
                  }
                ],
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  name: "end_ip",
                  placeholder: _vm.trans("utility.end_ip")
                },
                domProps: { value: _vm.ipFilterForm.end_ip },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.ipFilterForm, "end_ip", $event.target.value)
                  }
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: { "form-name": _vm.ipFilterForm, "prop-name": "end_ip" }
              })
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("label", { attrs: { for: "" } }, [
                _vm._v(_vm._s(_vm.trans("utility.ip_filter_description")))
              ]),
              _vm._v(" "),
              _c("textarea", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.ipFilterForm.description,
                    expression: "ipFilterForm.description"
                  }
                ],
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  rows: "1",
                  name: "description",
                  placeholder: _vm.trans("utility.ip_filter_description")
                },
                domProps: { value: _vm.ipFilterForm.description },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.ipFilterForm,
                      "description",
                      $event.target.value
                    )
                  }
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: {
                  "form-name": _vm.ipFilterForm,
                  "prop-name": "description"
                }
              })
            ],
            1
          )
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "card-footer text-right" },
        [
          _c(
            "router-link",
            {
              directives: [
                {
                  name: "show",
                  rawName: "v-show",
                  value: _vm.id,
                  expression: "id"
                }
              ],
              staticClass: "btn btn-danger waves-effect waves-light ",
              attrs: { to: "/utility/ip-filter" }
            },
            [_vm._v(_vm._s(_vm.trans("general.cancel")))]
          ),
          _vm._v(" "),
          !_vm.id
            ? _c(
                "button",
                {
                  staticClass: "btn btn-danger waves-effect waves-light ",
                  attrs: { type: "button" },
                  on: {
                    click: function($event) {
                      _vm.$emit("cancel")
                    }
                  }
                },
                [_vm._v(_vm._s(_vm.trans("general.cancel")))]
              )
            : _vm._e(),
          _vm._v(" "),
          _c(
            "button",
            {
              staticClass: "btn btn-info waves-effect waves-light",
              attrs: { type: "submit" }
            },
            [
              _vm.id
                ? _c("span", [_vm._v(_vm._s(_vm.trans("general.update")))])
                : _c("span", [_vm._v(_vm._s(_vm.trans("general.save")))])
            ]
          )
        ],
        1
      )
    ]
  )
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-c98a6fd2", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=index.js.map