webpackJsonp([311],{

/***/ 1230:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(1231)
}
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1233)
/* template */
var __vue_template__ = __webpack_require__(1234)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/utility/todo/widget.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-03af644a", Component.options)
  } else {
    hotAPI.reload("data-v-03af644a", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 1231:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(1232);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(14)("6c3519a0", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-03af644a\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./widget.vue", function() {
     var newContent = require("!!../../../../../node_modules/css-loader/index.js?sourceMap!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-03af644a\",\"scoped\":false,\"hasInlineConfig\":true}!../../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./widget.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 1232:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(8)(true);
// imports


// module
exports.push([module.i, "\n.completed{\n\ttext-decoration: line-through;\n}\n", "", {"version":3,"sources":["D:/Projects/jacob/resources/js/views/utility/todo/resources/js/views/utility/todo/widget.vue"],"names":[],"mappings":";AAkFA;CACA,8BAAA;CACA","file":"widget.vue","sourcesContent":["<template>\r\n\t<div class=\"mr-4\">\r\n\t    <form @submit.prevent=\"submit\" @keydown=\"todoForm.errors.clear($event.target.name)\">\r\n\t    \t<div class=\"px-2\">\r\n\t\t        <div class=\"form-group\">\r\n\t\t            <input class=\"form-control\" type=\"text\" v-model=\"todoForm.title\" name=\"title\" :placeholder=\"trans('utility.todo_title')\">\r\n\t\t            <show-error :form-name=\"todoForm\" prop-name=\"title\"></show-error>\r\n\t\t        </div>\r\n\t\t    </div>\r\n\t    </form>\r\n\t    <div>\r\n\t    \t<div v-bar>\r\n\t\t\t  <div style=\"max-height:200px;\" class=\"m-b-20\">\r\n\t\t    \t<div v-for=\"todo in todos\" @click=\"toggleTodo(todo)\" :class=\"['pointer','px-2', todo.status ? 'completed' : '']\">\r\n\t\t    \t\t<div class=\"checkbox checkbox-success\">\r\n\t\t                <input type=\"checkbox\" :id=\"`todo_${todo.id}`\" :checked=\"todo.status ? true : false\">\r\n\t\t                <label :for=\"`todo_${todo.id}`\">{{todo.title}}</label>\r\n\t\t            </div>\r\n\t\t    \t</div>\r\n\t\t\t  </div>\r\n\t\t\t</div>\r\n\t    </div>\r\n\t</div>\r\n</template>\r\n\r\n<script>\r\n\texport default {\r\n\t\tdata() {\r\n\t\t\treturn {\r\n\t\t\t\ttodoForm: new Form({\r\n\t\t\t\t\ttitle: '',\r\n\t\t\t\t\tdate: ''\r\n\t\t\t\t}),\r\n\t\t\t\ttodos: []\r\n\t\t\t}\r\n\t\t},\r\n\t\tmounted(){\r\n\t\t\tthis.getTodo();\r\n\t\t},\r\n\t\tmethods: {\r\n\t\t\tgetTodo(){\r\n\t\t\t\tlet loader = this.$loading.show();\r\n\t\t\t\taxios.get('/api/todo/today')\r\n\t\t\t\t\t.then(response => {\r\n\t\t\t\t\t\tthis.todos = response;\r\n\t\t\t\t\t\tloader.hide();\r\n\t\t\t\t\t})\r\n\t\t\t\t\t.catch(error => {\r\n\t\t\t\t\t\tloader.hide();\r\n\t\t\t\t\t\thelper.showErrorMsg(error);\r\n\t\t\t\t\t})\r\n\t\t\t},\r\n\t\t\tsubmit(){\r\n\t\t\t\tlet loader = this.$loading.show();\r\n\t\t\t\tthis.todoForm.date = moment().format('YYYY-MM-DD');\r\n\t\t\t\tthis.todoForm.post('/api/todo')\r\n\t\t\t\t\t.then(response => {\r\n\t\t\t\t\t\ttoastr.success(response.message);\r\n\t\t\t\t\t\tthis.getTodo();\r\n\t\t\t\t\t\tloader.hide();\r\n\t\t\t\t\t})\r\n\t\t\t\t\t.catch(error => {\r\n\t\t\t\t\t\tloader.hide();\r\n\t\t\t\t\t\thelper.showErrorMsg(error);\r\n\t\t\t\t\t})\r\n\t\t\t},\r\n\t\t\ttoggleTodo(todo){\r\n\t\t\t\tlet loader = this.$loading.show();\r\n                axios.post('/api/todo/'+todo.id+'/status')\r\n                    .then(response => {\r\n                        this.getTodo();\r\n\t\t\t\t\t\tloader.hide();\r\n                    })\r\n                    .catch(error => {\r\n                    \tloader.hide();\r\n                    });\r\n\t\t\t}\r\n\t\t}\r\n\t}\r\n</script>\r\n\r\n<style>\r\n\t.completed{\r\n\t\ttext-decoration: line-through;\r\n\t}\r\n</style>"],"sourceRoot":""}]);

// exports


/***/ }),

/***/ 1233:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
	data: function data() {
		return {
			todoForm: new Form({
				title: '',
				date: ''
			}),
			todos: []
		};
	},
	mounted: function mounted() {
		this.getTodo();
	},

	methods: {
		getTodo: function getTodo() {
			var _this = this;

			var loader = this.$loading.show();
			axios.get('/api/todo/today').then(function (response) {
				_this.todos = response;
				loader.hide();
			}).catch(function (error) {
				loader.hide();
				helper.showErrorMsg(error);
			});
		},
		submit: function submit() {
			var _this2 = this;

			var loader = this.$loading.show();
			this.todoForm.date = moment().format('YYYY-MM-DD');
			this.todoForm.post('/api/todo').then(function (response) {
				toastr.success(response.message);
				_this2.getTodo();
				loader.hide();
			}).catch(function (error) {
				loader.hide();
				helper.showErrorMsg(error);
			});
		},
		toggleTodo: function toggleTodo(todo) {
			var _this3 = this;

			var loader = this.$loading.show();
			axios.post('/api/todo/' + todo.id + '/status').then(function (response) {
				_this3.getTodo();
				loader.hide();
			}).catch(function (error) {
				loader.hide();
			});
		}
	}
};

/***/ }),

/***/ 1234:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "mr-4" }, [
    _c(
      "form",
      {
        on: {
          submit: function($event) {
            $event.preventDefault()
            return _vm.submit($event)
          },
          keydown: function($event) {
            _vm.todoForm.errors.clear($event.target.name)
          }
        }
      },
      [
        _c("div", { staticClass: "px-2" }, [
          _c(
            "div",
            { staticClass: "form-group" },
            [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.todoForm.title,
                    expression: "todoForm.title"
                  }
                ],
                staticClass: "form-control",
                attrs: {
                  type: "text",
                  name: "title",
                  placeholder: _vm.trans("utility.todo_title")
                },
                domProps: { value: _vm.todoForm.title },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.todoForm, "title", $event.target.value)
                  }
                }
              }),
              _vm._v(" "),
              _c("show-error", {
                attrs: { "form-name": _vm.todoForm, "prop-name": "title" }
              })
            ],
            1
          )
        ])
      ]
    ),
    _vm._v(" "),
    _c("div", [
      _c("div", { directives: [{ name: "bar", rawName: "v-bar" }] }, [
        _c(
          "div",
          { staticClass: "m-b-20", staticStyle: { "max-height": "200px" } },
          _vm._l(_vm.todos, function(todo) {
            return _c(
              "div",
              {
                class: ["pointer", "px-2", todo.status ? "completed" : ""],
                on: {
                  click: function($event) {
                    _vm.toggleTodo(todo)
                  }
                }
              },
              [
                _c("div", { staticClass: "checkbox checkbox-success" }, [
                  _c("input", {
                    attrs: { type: "checkbox", id: "todo_" + todo.id },
                    domProps: { checked: todo.status ? true : false }
                  }),
                  _vm._v(" "),
                  _c("label", { attrs: { for: "todo_" + todo.id } }, [
                    _vm._v(_vm._s(todo.title))
                  ])
                ])
              ]
            )
          })
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-03af644a", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=todo-widget.js.map