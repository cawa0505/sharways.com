webpackJsonp([162],{

/***/ 1240:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _product = __webpack_require__(638);

var _product2 = _interopRequireDefault(_product);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: { product: _product2.default },
    data: function data() {
        return {
            support_tips: '',
            product: {},
            supportForm: new Form({
                help_topic: '',
                body: '',
                purchase_code: '',
                product_name: '',
                date_of_support_expiry: '',
                subject: ''
            })
        };
    },
    mounted: function mounted() {
        if (!helper.hasRole('admin') || !helper.getConfig('pb')) {
            this.$router.push('/');
        }

        this.getPreRequisite();
    },

    methods: {
        getPreRequisite: function getPreRequisite() {
            var _this = this;

            var loader = this.$loading.show();
            axios.get('/api/support').then(function (response) {
                _this.support_tips = response.support_tips;
                _this.product = response.product;
                _this.supportForm.purchase_code = _this.product.purchase_code;
                _this.supportForm.product_name = _this.product.name;
                _this.supportForm.date_of_support_expiry = _this.product.date_of_support_expiry;
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        },
        submit: function submit() {
            var loader = this.$loading.show();
            this.supportForm.post('/api/support').then(function (response) {
                toastr.success(response.message);
                loader.hide();
            }).catch(function (error) {
                loader.hide();
                helper.showErrorMsg(error);
            });
        }
    },
    filters: {
        moment: function moment(date) {
            return helper.formatDate(date);
        }
    },
    computed: {
        checkSupportValidity: function checkSupportValidity() {
            if (moment().format('YYYY-MM-DD') <= this.product.date_of_support_expiry) return true;else return false;
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1241:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "page-titles" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("h3", { staticClass: "text-themecolor" }, [
            _vm._v(_vm._s(_vm.trans("general.support")))
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("div", { staticClass: "action-buttons pull-right" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-danger btn-sm",
                on: {
                  click: function($event) {
                    _vm.$router.push("/dashboard")
                  }
                }
              },
              [
                _c("i", { staticClass: "fas fa-home" }),
                _vm._v(" "),
                _c("span", { staticClass: "d-none d-sm-inline" }, [
                  _vm._v(_vm._s(_vm.trans("general.home")))
                ])
              ]
            )
          ])
        ])
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "container-fluid p-4" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("div", { staticClass: "card" }, [
            _c("div", { staticClass: "card-body" }, [
              _c("h4", { staticClass: "card-title" }, [
                _vm._v(_vm._s(_vm.trans("general.support")))
              ]),
              _vm._v(" "),
              _vm.product.name && !_vm.checkSupportValidity
                ? _c("div", { staticClass: "alert alert-danger" }, [
                    _vm._v(
                      "Your support is expired. Please renew your support."
                    )
                  ])
                : _c("div", [
                    _c("div", {
                      domProps: { innerHTML: _vm._s(_vm.support_tips) }
                    }),
                    _vm._v(" "),
                    _c(
                      "form",
                      {
                        on: {
                          submit: function($event) {
                            $event.preventDefault()
                            return _vm.submit($event)
                          },
                          keydown: function($event) {
                            _vm.supportForm.errors.clear($event.target.name)
                          }
                        }
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "form-group" },
                          [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.supportForm.subject,
                                  expression: "supportForm.subject"
                                }
                              ],
                              staticClass: "form-control",
                              attrs: {
                                type: "text",
                                name: "subject",
                                placeholder: "Subject"
                              },
                              domProps: { value: _vm.supportForm.subject },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.supportForm,
                                    "subject",
                                    $event.target.value
                                  )
                                }
                              }
                            }),
                            _vm._v(" "),
                            _c("show-error", {
                              attrs: {
                                "form-name": _vm.supportForm,
                                "prop-name": "subject"
                              }
                            })
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "div",
                          { staticClass: "form-group" },
                          [
                            _c("autosize-textarea", {
                              staticClass: "form-control",
                              attrs: {
                                rows: "5",
                                placeholder: "Body",
                                name: "body"
                              },
                              model: {
                                value: _vm.supportForm.body,
                                callback: function($$v) {
                                  _vm.$set(_vm.supportForm, "body", $$v)
                                },
                                expression: "supportForm.body"
                              }
                            }),
                            _vm._v(" "),
                            _c("show-error", {
                              attrs: {
                                "form-name": _vm.supportForm,
                                "prop-name": "body"
                              }
                            })
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _vm._m(0)
                      ]
                    )
                  ])
            ])
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-12 col-sm-6" }, [
          _c("div", { staticClass: "card" }, [
            _c(
              "div",
              { staticClass: "card-body" },
              [
                _c("h4", { staticClass: "card-title" }, [
                  _vm._v(_vm._s(_vm.trans("general.product_information")))
                ]),
                _vm._v(" "),
                _c("product", { attrs: { product: _vm.product } })
              ],
              1
            )
          ])
        ])
      ])
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "form-group" }, [
      _c(
        "button",
        {
          staticClass: "btn btn-info waves-effect waves-light m-t-10",
          attrs: { type: "submit" }
        },
        [_vm._v("Submit")]
      )
    ])
  }
]
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-53b75e80", module.exports)
  }
}

/***/ }),

/***/ 366:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(1240)
/* template */
var __vue_template__ = __webpack_require__(1241)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/product/support.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-53b75e80", Component.options)
  } else {
    hotAPI.reload("data-v-53b75e80", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 638:
/***/ (function(module, exports, __webpack_require__) {

var disposed = false
var normalizeComponent = __webpack_require__(0)
/* script */
var __vue_script__ = __webpack_require__(639)
/* template */
var __vue_template__ = __webpack_require__(640)
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "resources/js/views/product/product.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-69271ba0", Component.options)
  } else {
    hotAPI.reload("data-v-69271ba0", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

module.exports = Component.exports


/***/ }),

/***/ 639:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    props: {
        product: {
            required: true
        },
        update: {
            required: false,
            default: 0
        }
    },
    computed: {
        checkSupportValidity: function checkSupportValidity() {
            if (moment().format('YYYY-MM-DD') <= this.product.date_of_support_expiry) return true;else return false;
        }
    },
    filters: {
        moment: function moment(date) {
            return helper.formatDate(date);
        }
    }
};

/***/ }),

/***/ 640:
/***/ (function(module, exports, __webpack_require__) {

var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "table-responsive" }, [
    _vm.product.name
      ? _c("table", { staticClass: "table" }, [
          _c("tbody", [
            _c("tr", [
              _c("th", [_vm._v("Product Name")]),
              _vm._v(" "),
              _c("td", [_vm._v(_vm._s(_vm.product.name))])
            ]),
            _vm._v(" "),
            _c("tr", [
              _c("th", [_vm._v("Current Version")]),
              _vm._v(" "),
              _c("td", [_vm._v(_vm._s(_vm.product.current_version))])
            ]),
            _vm._v(" "),
            _c("tr", [
              _c("th", [_vm._v("Latest Version")]),
              _vm._v(" "),
              _c("td", [
                _vm._v(
                  "\n                        " +
                    _vm._s(_vm.product.latest_version) +
                    "\n                        "
                ),
                _vm.product.current_version != _vm.product.latest_version &&
                !_vm.update
                  ? _c(
                      "span",
                      [
                        _c("br"),
                        _c(
                          "router-link",
                          {
                            staticClass: "btn btn-info btn-sm",
                            attrs: { to: "/update" }
                          },
                          [_vm._v("Update Available")]
                        )
                      ],
                      1
                    )
                  : _vm._e(),
                _vm._v(" "),
                _vm.product.current_version == _vm.product.latest_version
                  ? _c("span", { staticClass: "btn btn-success btn-sm" }, [
                      _vm._v("Up-to-date")
                    ])
                  : _vm._e()
              ])
            ]),
            _vm._v(" "),
            _c("tr", [
              _c("th", [_vm._v("Latest Version Release")]),
              _vm._v(" "),
              _c("td", [
                _vm._v(
                  _vm._s(_vm._f("moment")(_vm.product.latest_version_release))
                )
              ])
            ]),
            _vm._v(" "),
            _c("tr", [
              _c("th", [_vm._v("Purchase Code")]),
              _vm._v(" "),
              _c("td", [_vm._v(_vm._s(_vm.product.purchase_code))])
            ]),
            _vm._v(" "),
            _c("tr", [
              _c("th", [_vm._v("Registered Email Id")]),
              _vm._v(" "),
              _c("td", [_vm._v(_vm._s(_vm.product.email))])
            ]),
            _vm._v(" "),
            _c("tr", [
              _c("th", [_vm._v("License Type")]),
              _vm._v(" "),
              _c("td", [_vm._v(_vm._s(_vm.product.license_type))])
            ]),
            _vm._v(" "),
            _c("tr", [
              _c("th", [_vm._v("Date of Purchase")]),
              _vm._v(" "),
              _c("td", [
                _vm._v(_vm._s(_vm._f("moment")(_vm.product.date_of_purchase)))
              ])
            ]),
            _vm._v(" "),
            _c("tr", [
              _c("th", [
                _vm._v("Support Validity "),
                _c("br"),
                _vm._v(" "),
                _c(
                  "a",
                  {
                    staticClass: "btn btn-info btn-sm",
                    attrs: {
                      href:
                        "http://codecanyon.net/item/x/" +
                        _vm.product.envato_code +
                        "?=ScriptMint",
                      target: "_blank"
                    }
                  },
                  [_vm._v("Renew Support")]
                )
              ]),
              _vm._v(" "),
              _c("td", [
                _vm._v(
                  _vm._s(_vm._f("moment")(_vm.product.date_of_support_expiry)) +
                    " "
                ),
                _c("br"),
                _vm._v(" "),
                _vm.checkSupportValidity
                  ? _c("span", { staticClass: "label label-success" }, [
                      _vm._v("Supported")
                    ])
                  : _c("span", { staticClass: "label label-danger" }, [
                      _vm._v("Expired")
                    ])
              ])
            ]),
            _vm._v(" "),
            _c("tr", [
              _c("th", [_vm._v("Access Code")]),
              _vm._v(" "),
              _c("td", [_vm._v(_vm._s(_vm.product.access_code))])
            ]),
            _vm._v(" "),
            _c("tr", [
              _c("th", [_vm._v("Checksum")]),
              _vm._v(" "),
              _c("td", [_vm._v(_vm._s(_vm.product.checksum))])
            ])
          ])
        ])
      : _vm._e()
  ])
}
var staticRenderFns = []
render._withStripped = true
module.exports = { render: render, staticRenderFns: staticRenderFns }
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-69271ba0", module.exports)
  }
}

/***/ })

});
//# sourceMappingURL=support.js.map